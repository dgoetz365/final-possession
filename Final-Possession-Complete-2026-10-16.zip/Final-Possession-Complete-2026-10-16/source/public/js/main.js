import {CATALOG} from './catalog.js';
import * as Engine from './engine.js';
import {renderApp} from './views.js';
import {SAVE_KEY,HISTORY_KEY,SETTINGS_KEY,loadRun,saveRun,parseSave,readHistory,recordHistory,readSettings} from './storage.js';

const app = document.querySelector('#app');
let storage;
try { storage = window.localStorage; } catch { storage = {getItem:()=>null,setItem:()=>{throw new Error('Storage unavailable');},removeItem:()=>{}}; }
const restored=loadRun(storage,Engine.MODEL_VERSION);
let availableCatalog=CATALOG;
let catalog=restored.saved?.catalog || CATALOG;
let run=restored.saved?.run || null;
let screen='home';
let notice=restored.notice;
let dialog=null;
let region='All';
let plan='move-ball';
let teamName='Your Team';
let subOut='',subIn='';
let busy=false, externalChange=false;
let history=readHistory(storage);
let settings=readSettings(storage);
let filters={search:'',role:'all',era:'all',school:'all',sort:'featured'};
let dataStatus={configured:false,canRefresh:false,source:'bundled',status:'Checking connection',updatedAt:catalog.checkedAt};
let rotationDraft=null;
let restoreFocus=null;
const phaseScreen=()=>({draft:'draft',lineup:'lineup',seeded:'tournament',playing:'game',result:'result',champion:'result',eliminated:'result'}[run?.phase] || 'home');
const announce=message=>{document.querySelector('#announcer').textContent=message;};

function persist() {
  if (!run) return;
  if (externalChange) throw new Error('This run changed in another tab. Reload this tab before continuing so you do not overwrite it.');
  try { saveRun(storage,run,catalog); history=recordHistory(storage,run,catalog); }
  catch(error) { notice=error.message; announce(notice); }
}

function model() {
  let validation=null,estimate=null,opponent=null;
  if(run){
    validation=Engine.validateRoster(run,catalog);
    if(run.roster.length) estimate=Engine.estimateTeam(run,catalog);
    if(run.bracket) opponent=Engine.nextOpponent(run);
  }
  const displayRun=rotationDraft && screen==='lineup'?{...run,...rotationDraft}:run;
  return {screen,run:displayRun,catalog,libraryCatalog:availableCatalog,validation,estimate,opponent,filters,notice,history,settings,dialog,region,plan,subOut,subIn,teamName,busy,dataStatus,availableCatalogVersion:availableCatalog.version};
}

function render({focus=false,preserveInput=false}={}) {
  const active=preserveInput?document.activeElement:null;
  const field=active?.dataset.field;
  const start=active?.selectionStart;
  const end=active?.selectionEnd;
  app.innerHTML=renderApp(model());
  document.documentElement.dataset.textSize=settings.textSize;
  document.documentElement.dataset.highContrast=String(settings.highContrast);
  document.documentElement.dataset.reducedMotion=String(settings.reducedMotion);
  document.body.classList.toggle('high-contrast',settings.highContrast);
  document.body.classList.toggle('large-text',settings.textSize==='large');
  document.body.classList.toggle('reduced-motion',settings.reducedMotion);
  const main=app.querySelector('main');
  if(main){main.id='main-content';main.tabIndex=-1;}
  if(field){const el=app.querySelector(`[data-field="${CSS.escape(field)}"]`);el?.focus();if(el?.setSelectionRange && start!==null){try{el.setSelectionRange(start,end);}catch{}}}
  else if(dialog) app.querySelector('[role="dialog"] button,dialog button')?.focus();
  else if(focus) { main?.focus({preventScroll:true}); window.scrollTo({top:0,behavior:'instant'}); }
}

function transition(nextRun,nextScreen) {
  if(externalChange) throw new Error('This run changed in another tab. Reload before continuing.');
  run=nextRun;
  rotationDraft=null;
  notice=null;
  subOut='';subIn='';
  screen=nextScreen || phaseScreen();
  persist();
  render({focus:true});
}

function go(target) {
  dialog=null;notice=null;
  if(target==='sources'&&!dataStatus.canRefresh)return;
  if(['draft','lineup','tournament','scout','game','seed','result'].includes(target)) {
    if(!run) target='home';
    else if(['draft','lineup'].includes(target) && !['draft','lineup'].includes(run.phase)) {notice='The roster is locked for this tournament. Start a new run to draft again.';target=phaseScreen();}
    else if(target==='lineup' && !Engine.validateRoster(run,catalog).valid) {notice='Finish drafting twelve players within the roster rules first.';target='draft';}
    else if(['tournament','scout','seed'].includes(target) && !run.bracket) {notice='Set your lineup and lock it to reveal your seed.';target=phaseScreen();}
    else if(target==='game' && !run.game) target=phaseScreen();
  }
  screen=target;render({focus:true});
}

function startNew() {
  const seed=crypto.getRandomValues(new Uint32Array(1))[0];
  catalog=Engine.prepareRunCatalog(availableCatalog,seed);
  const next=Engine.createRun(catalog,seed,teamName.trim().slice(0,40)||'Your Team');
  next.id=`fp-${Date.now()}-${seed}`;
  next.createdAt=new Date().toISOString();
  externalChange=false;
  filters={search:'',role:'all',era:'all',school:'all',sort:'featured'};
  transition(next,'draft');
}

function exportRun() {
  if(!run) throw new Error('Start a draft before exporting a run.');
  const blob=new Blob([JSON.stringify({format:'final-possession',version:1,run,catalog},null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob);
  const link=document.createElement('a');link.href=url;link.download=`final-possession-${run.id}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  announce('Your run has been exported.');
}

async function checkConnection(loadCatalog=false) {
  try {
    const response=await fetch('/api/data/status',{cache:'no-store',signal:AbortSignal.timeout(10000)});
    if(!response.ok) throw new Error('Connection unavailable');
    dataStatus=await response.json();
    if(loadCatalog && dataStatus.summary){const result=await fetch('/api/catalog',{cache:'no-store',signal:AbortSignal.timeout(20000)});if(result.ok){const data=await result.json();if(data?.version===dataStatus.summary.version && data?.players?.length>=CATALOG.players.length && data?.teams?.length===63) availableCatalog=data;}}
  } catch {dataStatus={...dataStatus,status:'Offline. The verified bundled snapshot is available.'};}
  if(screen==='sources') render();
}

async function refreshData() {
  busy=true;notice='Refreshing and validating historical data. Your current run stays frozen.';render();
  try {
    const response=await fetch('/api/data/refresh',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(180000)});
    const result=await response.json();if(!response.ok)throw new Error(result.error || 'The data refresh failed.');
    await checkConnection(true);
    notice=`Data refreshed: ${result.playersUpdated} player records and ${result.providerGroups} school rosters. New runs will use this pool.`;
  }catch(error){notice=error.message || 'The refresh could not finish. Your current snapshot is unchanged.';}
  finally {busy=false;render();announce(notice);}
}

app.addEventListener('click',async event=>{
  const button=event.target.closest('[data-action]');
  if(!button || button.disabled || busy) return;
  event.preventDefault();
  try{
    const action=button.dataset.action,id=button.dataset.id;
    if(action==='nav') go(button.dataset.screen);
    else if(action==='new-run' || action==='reset-run') {
      if(run && !['champion','eliminated'].includes(run.phase) && !window.confirm('Start a fresh draft? This replaces your active run. You can export it in Settings first.')) return;
      startNew();
    }
    else if(action==='resume') go(phaseScreen());
    else if(action==='help'){dialog={type:'help'};restoreFocus=button;render();}
    else if(action==='detail'){dialog={type:'player',playerId:id};restoreFocus=button.dataset;render();}
    else if(action==='close-dialog'){dialog=null;render();app.querySelector(`[data-action="detail"][data-id="${CSS.escape(restoreFocus?.id||'')}"]`)?.focus();}
    else if(action==='draft'){transition(Engine.draftPlayer(run,id,catalog),'draft');announce('Player drafted.');}
    else if(action==='reroll'){transition(Engine.rerollDraft(run,catalog),'draft');announce('A new school and season have been drawn.');}
    else if(action==='remove'){transition(Engine.removePlayer(run,id,catalog),'draft');announce('Player removed.');}
    else if(action==='auto-rotation') transition(Engine.autoRotation(run,catalog),'lineup');
    else if(action==='lock-lineup'){
      let next=run;
      if(rotationDraft) next=Engine.setRotation(run,rotationDraft,catalog);
      transition(Engine.seedTournament(next,catalog),'seed');
    }
    else if(action==='scout') go('scout');
    else if(action==='tip-off') transition(Engine.startGame(run,plan,catalog),'game');
    else if(action==='decision') transition(Engine.act(run,{type:'decision',choice:button.dataset.choice},catalog));
    else if(action==='continue') transition(Engine.act(run,{type:'continue'},catalog));
    else if(action==='timeout') transition(Engine.act(run,{type:'timeout'},catalog),'game');
    else if(action==='substitute') {
      const outId=subOut || run.game.lineup[0];
      const inId=subIn || run.roster.find(id=>!run.game.lineup.includes(id)&&run.game.players[id]?.fouls<5);
      transition(Engine.act(run,{type:'substitute',outId,inId},catalog),'game');
    }
    else if(action==='next-round') transition(Engine.advanceTournament(run,catalog));
    else if(action==='region'){region=button.dataset.region;render();}
    else if(action==='clear-history'){if(window.confirm('Delete the saved history on this device? Your current run stays available.')){storage.removeItem(HISTORY_KEY);history=[];render();}}
    else if(action==='export-save') exportRun();
    else if(action==='import-save') document.querySelector('#save-file').click();
    else if(action==='refresh-data') await refreshData();
    else if(action==='check-connection') {await checkConnection(true);render();}
    else if(action==='clear-filters'){filters={search:'',role:'all',era:'all',school:'all',sort:'featured'};render();}
  }catch(error){notice=error.message || 'That action could not be completed.';render();announce(notice);}
});

function fieldChange(event) {
  const input=event.target,field=input.dataset.field;
  if(!field)return;
  if(event.type==='input' && field!=='search' && field!=='teamName')return;
  try {
    const value=input.type==='checkbox'?input.checked:input.value;
    if(Object.hasOwn(filters,field)) {filters[field]=value;render({preserveInput:true});}
    else if(field==='teamName') teamName=String(value).slice(0,40);
    else if(field==='plan'){plan=value;render({preserveInput:true});}
    else if(field==='subOut') subOut=value;
    else if(field==='subIn') subIn=value;
    else if(['textSize','highContrast','reducedMotion'].includes(field)) {settings[field]=value;storage.setItem(SETTINGS_KEY,JSON.stringify(settings));render({preserveInput:true});}
    else if(field==='style' || field.startsWith('starter-') || field.startsWith('minute-')) {
      if(!rotationDraft)rotationDraft={starters:[...run.starters],minutes:{...run.minutes},style:run.style};
      if(field==='style')rotationDraft.style=value;
      if(field.startsWith('minute-'))rotationDraft.minutes[field.slice(7)]=Number(value);
      if(field.startsWith('starter-')){
        const index=['PG','SG','SF','PF','C'].indexOf(field.slice(8));
        const previous=rotationDraft.starters[index];
        const other=rotationDraft.starters.indexOf(value);
        if(other>=0)rotationDraft.starters[other]=previous;
        rotationDraft.starters[index]=value;
      }
      try {const next=Engine.setRotation(run,rotationDraft,catalog);run=next;rotationDraft=null;notice=null;persist();}
      catch(error){notice=error.message;}
      render({preserveInput:true});
    }
  }catch(error){notice=error.message;render();}
}
app.addEventListener('input',fieldChange);
app.addEventListener('change',fieldChange);

document.addEventListener('keydown',event=>{
  if(!dialog)return;
  if(event.key==='Escape'){dialog=null;render();}
  if(event.key==='Tab'){
    const modal=app.querySelector('[role="dialog"],dialog');
    const nodes=[...(modal?.querySelectorAll('button:not(:disabled),a[href],input,select,[tabindex="0"]')||[])];
    if(!nodes.length)return;
    const first=nodes[0],last=nodes.at(-1);
    if(event.shiftKey && document.activeElement===first){event.preventDefault();last.focus();}
    else if(!event.shiftKey && document.activeElement===last){event.preventDefault();first.focus();}
  }
});

document.querySelector('#save-file').addEventListener('change',async event=>{
  const file=event.target.files[0];if(!file)return;
  try{
    if(run && !window.confirm('Replace the active run with this saved run?'))return;
    if(file.size>2000000)throw new Error('This save file is too large.');
    const saved=parseSave(await file.text(),Engine.MODEL_VERSION);
    catalog=saved.catalog;externalChange=false;transition(saved.run);
  }catch(error){notice=error.message;render();}
  finally{event.target.value='';}
});

window.addEventListener('storage',event=>{
  if(event.key===SAVE_KEY){externalChange=true;notice='This run changed in another tab. Reload this tab before continuing.';render();}
  if(event.key===HISTORY_KEY){history=readHistory(storage);if(screen==='history')render();}
});

if(run){try{history=recordHistory(storage,run,catalog);}catch(error){notice=error.message;}}
render();
checkConnection(true);
