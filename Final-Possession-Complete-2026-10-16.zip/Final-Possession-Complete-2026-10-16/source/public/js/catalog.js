// Historical facts are transcribed from the primary sources below.
// Credits and role eligibility are original game design, not historical ratings.
// Missing observations stay null. A 0% rate requires actual attempts.
import {parseSeasonTables,SEASON_TABLES} from './season-tables.js';
const S = {
  davidson: {label: 'Davidson 2007-08 final season statistics', url: 'https://static.davidsonwildcats.com/custompages/mbball/2007-08.HTM'},
  duke16: {label: 'Duke 2015-16 final statistics, page 1', url: 'https://goduke.com/documents/download/2022/8/15/2015-16_Stats.pdf'},
  texas: {label: 'Big 12 2007-08 media guide, Texas 2006-07 overall statistics, page 73', url: 'https://s3.amazonaws.com/big12sports.com/documents/2008/7/22/133442.pdf'},
  davis: {label: 'Kentucky official Anthony Davis 2011-12 biography', url: 'https://ukathletics.com/sports/mbball/roster/player/anthony-davis/'},
  noah: {label: 'Florida official Joakim Noah career statistics, 2006-07 row', url: 'https://floridagators.com/sports/mens-basketball/roster/joakim-noah/486'},
  redick: {label: 'Duke 2005-06 final statistics, page 1', url: 'https://s3.us-east-2.amazonaws.com/sidearm.nextgen.sites/goduke.com/documents/2022/8/15/2005-06_Stats.pdf'},
  duke06: {label: 'Duke 2005-06 final statistics, page 1', url: 'https://s3.us-east-2.amazonaws.com/sidearm.nextgen.sites/goduke.com/documents/2022/8/15/2005-06_Stats.pdf'},
  purdue24: {label: 'Purdue 2023-24 final statistics, page 3, April 15 2024', url: 'https://storage.googleapis.com/purduesports-com-prod/2025/05/16/L6rE8G0Zhs8eWIxXupib7mmHA8EGq6MVOdUJvC8f.pdf#page=3'},
  purdue06: {label: 'Purdue 2005-06 final statistics, page 1, March 10 2006', url: 'https://s3.us-east-2.amazonaws.com/sidearm.nextgen.sites/purduesports.com/documents/2006/5/6/_pur_m_baskbl__0506cumulative_stats.pdf?timestamp=20180517103639'},
  green: {label: 'Michigan State official Draymond Green 2012 biography, career statistics', url: 'https://msuspartans.com/documents/download/2018/7/25/11056__m_baskbl_2011_12_misc_non_event__greenbio050912.pdf'},
  nova: {label: 'Villanova 2017-18 final cumulative statistics', url: 'https://villanova.com/sports/mens-basketball/stats/2017-18'},
  horford: {label: 'Florida official Al Horford career statistics, 2006-07 row', url: 'https://floridagators.com/sports/mens-basketball/roster/al-horford/483'},
  brewer: {label: 'Florida official Corey Brewer career statistics, 2006-07 row', url: 'https://floridagators.com/sports/mens-basketball/roster/corey-brewer/480'},
  humphrey: {label: 'Florida official Lee Humphrey career statistics, 2006-07 row', url: 'https://floridagators.com/sports/mens-basketball/roster/lee-humphrey/484'},
  edey: {label: 'Purdue official Zach Edey game-by-game statistics, 2023-24 final totals', url: 'https://storage.googleapis.com/purduesports-com-prod/2025/06/25/ZIRQDzHRqScgUrx17aOs2D8mrmbwk5ZaHYFZADkF.pdf'},
  walker: {label: 'UConn official Kemba Walker complete biography, final 2010-11 career statistics', url: 'https://uconnhuskies.com/documents/download/2018/6/14/1888__m_baskbl__Kemba_Walker.pdf'},
  bracket: {label: 'Official 2024 NCAA bracket reproduced in GCU notes, page 5; Selection Sunday records', url: 'https://rolltide.com/documents/download/2024/3/23/GCU-MBB-Notes-35-NCAAT-ALA.pdf#page=5'},
  ncaa: {label: 'NCAA official 2024 tournament bracket', url: 'https://www.ncaa.com/_flysystem/public-s3/files/2024-march-madness-bracket-mens-tournament_0.pdf'},
};

// Values: games, points/game, rebounds/game, assists/game, 3PT%, FT%,
// minutes/game, steals/game, blocks/game, season 3PT attempts.
function player(id, name, school, season, number, roles, cost, values, source) {
  const [games, ppg, rpg, apg, threePct, ftPct, mpg, spg, bpg, threeAttempts] = values;
  return {id, personId: id.replace(/-\d{4}$/, ''), name, school, season,
    year: Number(season.slice(0,4)) + 1, number, roles, cost,
    stats: {games, ppg, rpg, apg, threePct, ftPct, mpg, spg, bpg, threeAttempts},
    source: S[source], verified: true};
}

const basePlayers = [
  player('curry-2008', 'Stephen Curry', 'Davidson', '2007-08', 30, ['PG'], 22, [36,25.9,4.6,2.9,43.9,89.4,33.1,2.0,0.4,369], 'davidson'),
  player('allen-2016', 'Grayson Allen', 'Duke', '2015-16', 3, ['SG'], 12, [36,21.6,4.6,3.5,41.7,83.7,36.6,1.3,0.1,216], 'duke16'),
  player('durant-2007', 'Kevin Durant', 'Texas', '2006-07', 35, ['SF'], 18, [35,25.8,11.1,1.3,40.4,81.6,35.9,1.9,1.9,203], 'texas'),
  player('davis-2012', 'Anthony Davis', 'Kentucky', '2011-12', 23, ['PF','C'], 18, [40,14.2,10.4,null,null,null,null,null,4.7,null], 'davis'),
  player('noah-2007', 'Joakim Noah', 'Florida', '2006-07', 13, ['C'], 10, [40,12.0,8.4,2.3,100,66.3,25.9,1.1,1.8,1], 'noah'),
  player('redick-2006', 'JJ Redick', 'Duke', '2005-06', 4, ['SG'], 7, [36,26.8,2.0,2.6,42.1,86.3,37.1,1.4,0.1,330], 'redick'),
  player('green-2012', 'Draymond Green', 'Michigan State', '2011-12', 23, ['PF','SF'], 6, [37,16.2,10.6,3.8,38.8,72.3,33.2,1.5,1.0,134], 'green'),
  player('brunson-2018', 'Jalen Brunson', 'Villanova', '2017-18', 1, ['PG'], 7, [40,18.9,3.1,4.6,40.8,80.2,31.8,0.9,0.0,211], 'nova'),
  player('ingram-2016', 'Brandon Ingram', 'Duke', '2015-16', 14, ['SF','PF'], 13, [36,17.3,6.8,2.0,41.0,68.2,34.6,1.1,1.4,195], 'duke16'),
  player('kennard-2016', 'Luke Kennard', 'Duke', '2015-16', 5, ['SG'], 6, [36,11.8,3.6,1.5,32.0,88.9,26.7,0.9,0.2,172], 'duke16'),
  player('jefferson-2016', 'Amile Jefferson', 'Duke', '2015-16', 21, ['PF','C'], 7, [9,11.4,10.3,1.4,null,55.3,30.3,0.8,1.2,0], 'duke16'),
  player('jones-2016', 'Matt Jones', 'Duke', '2015-16', 13, ['SG','SF'], 5, [35,10.4,2.5,2.3,41.5,73.6,31.8,1.0,0.2,183], 'duke16'),
  player('plumlee-2016', 'Marshall Plumlee', 'Duke', '2015-16', 40, ['C'], 6, [36,8.3,8.6,1.1,null,57.5,30.5,0.8,1.6,0], 'duke16'),
  player('thornton-2016', 'Derryck Thornton', 'Duke', '2015-16', 12, ['PG'], 5, [36,7.1,1.8,2.6,32.5,69.0,26.0,0.8,0.2,83], 'duke16'),
  player('bridges-2018', 'Mikal Bridges', 'Villanova', '2017-18', 25, ['SG','SF'], 14, [40,17.7,5.3,1.9,43.5,85.1,32.1,1.5,1.1,239], 'nova'),
  player('divincenzo-2018', 'Donte DiVincenzo', 'Villanova', '2017-18', 10, ['SG','PG'], 10, [40,13.4,4.8,3.5,40.1,71.0,29.3,1.1,0.2,212], 'nova'),
  player('spellman-2018', 'Omari Spellman', 'Villanova', '2017-18', 14, ['C','PF'], 9, [40,10.9,8.0,0.8,43.3,70.0,28.1,0.7,1.5,150], 'nova'),
  player('paschall-2018', 'Eric Paschall', 'Villanova', '2017-18', 4, ['PF','SF'], 8, [38,10.6,5.3,2.2,35.6,81.3,29.8,0.9,0.6,101], 'nova'),
  player('horford-2007', 'Al Horford', 'Florida', '2006-07', 42, ['PF','C'], 11, [38,13.2,9.5,2.2,0,64.4,27.8,0.7,1.8,2], 'horford'),
  player('brewer-2007', 'Corey Brewer', 'Florida', '2006-07', 2, ['SG','SF'], 9, [37,13.2,4.7,2.9,33.6,72.3,null,1.9,0.4,119], 'brewer'),
  player('humphrey-2007', 'Lee Humphrey', 'Florida', '2006-07', 12, ['SG'], 6, [40,10.3,1.3,1.3,45.9,69.2,30.4,0.5,0.0,246], 'humphrey'),
  player('richards-2008', 'Jason Richards', 'Davidson', '2007-08', 2, ['PG'], 9, [36,12.7,3.1,8.1,31.9,74.4,35.1,1.4,0.1,182], 'davidson'),
  player('edey-2024', 'Zach Edey', 'Purdue', '2023-24', 15, ['C'], 21, [39,25.2,12.2,2.0,50.0,71.1,32.0,0.3,2.2,2], 'edey'),
  player('walker-2011', 'Kemba Walker', 'UConn', '2010-11', 15, ['PG'], 18, [41,23.5,5.4,4.5,33.0,81.9,37.6,1.9,0.2,227], 'walker'),
];

const round1=n=>Math.round((n+Number.EPSILON)*10)/10;
const percent=(made,attempted)=>attempted>0?round1(100*made/attempted):null;
const perGame=(total,games)=>total===null?null:round1(total/games);

// Original game formula, not an historical rating. The eight approved concept
// prices are explicit exceptions. All other players use the same formula.
export function seasonCreditCost(s) {
  return Math.min(22,Math.max(1,Math.round(1 + .45*(s.ppg??0) + .45*(s.rpg??0)
    + .60*(s.apg??0) + (s.spg??0) + 1.20*(s.bpg??0) + .03*(s.mpg??0))));
}
const approvedCosts=new Map(basePlayers.slice(0,8).map(p=>[p.id,p.cost]));
const byId=new Map(basePlayers.map(p=>[p.id,{...p,stats:{...p.stats,fgPct:null,tov:null,starts:null,orpg:null,drpg:null,fgAttempts:null,ftAttempts:null},costModel:approvedCosts.has(p.id)?'approved-concept':'season-box-v1'}]));

for(const row of parseSeasonTables()) {
  const {totals:t}=row;
  const id=`${row.stem}-${row.year}`;
  const original=byId.get(id);
  const calculated={games:t.games,starts:t.starts,ppg:perGame(t.points,t.games),rpg:perGame(t.offRebounds+t.defRebounds,t.games),
    apg:perGame(t.assists,t.games),mpg:perGame(t.minutes,t.games),spg:perGame(t.steals,t.games),bpg:perGame(t.blocks,t.games),
    threePct:percent(t.threeMade,t.threeAttempts),ftPct:percent(t.ftMade,t.ftAttempts),fgPct:percent(t.fgMade,t.fgAttempts),
    threeAttempts:t.threeAttempts,fgAttempts:t.fgAttempts,ftAttempts:t.ftAttempts,tov:perGame(t.turnovers,t.games),
    orpg:perGame(t.offRebounds,t.games),drpg:perGame(t.defRebounds,t.games)};
  // Retain original rounded observations for already-reviewed players, enriching
  // only the new columns. Complete totals remain independently inspectable.
  const stats=original?{...calculated,...original.stats,fgPct:calculated.fgPct,tov:calculated.tov,starts:calculated.starts,
    orpg:calculated.orpg,drpg:calculated.drpg,fgAttempts:calculated.fgAttempts,ftAttempts:calculated.ftAttempts}:calculated;
  const record={id,personId:row.stem,name:row.name,school:row.school,season:row.season,year:row.year,number:row.number,
    roles:original?.roles??row.roles,stats,seasonTotals:{...t},source:S[row.sourceKey],verified:true,
    cost:approvedCosts.get(id)??seasonCreditCost(stats),costModel:approvedCosts.has(id)?'approved-concept':'season-box-v1'};
  byId.set(id,record);
}

// These players have individual official biographies instead of an included
// full-team table. Only newly confirmed columns are added here.
const biographyExtras={
  'noah-2007':{fgMade:173,fgAttempts:285,turnovers:101,ftAttempts:199,starts:40},
  'horford-2007':{fgMade:186,fgAttempts:306,turnovers:69,ftAttempts:202,starts:36},
  'brewer-2007':{fgMade:169,fgAttempts:356,turnovers:90,ftAttempts:155,starts:37},
  'humphrey-2007':{fgMade:145,fgAttempts:305,turnovers:45,ftAttempts:13,starts:40},
  'green-2012':{fgMade:212,fgAttempts:472,turnovers:112,ftAttempts:173,starts:36,offRebounds:79,defRebounds:315},
  'walker-2011':{fgMade:316,fgAttempts:739,turnovers:93,ftAttempts:315,starts:41,offRebounds:53,defRebounds:170},
};
for(const [id,t] of Object.entries(biographyExtras)) {
  const p=byId.get(id);
  Object.assign(p.stats,{fgPct:percent(t.fgMade,t.fgAttempts),tov:perGame(t.turnovers,p.stats.games),starts:t.starts,fgAttempts:t.fgAttempts,ftAttempts:t.ftAttempts});
  if(t.offRebounds!==undefined) Object.assign(p.stats,{orpg:perGame(t.offRebounds,p.stats.games),drpg:perGame(t.defRebounds,p.stats.games)});
  p.seasonTotals={...t,games:p.stats.games};
}
const players=[...byId.values()].map(p=>({...p,cost:approvedCosts.get(p.id)??seasonCreditCost(p.stats),
  sampleNote:p.stats.games<10?'Fewer than 10 games in this season.':p.stats.mpg!==null&&p.stats.mpg<5?'Fewer than 5 minutes per game in this season.':null}));

// Seeds and regions are historical inputs. The game may create new seeding.
// All records are frozen at Selection Sunday, March 17, 2024. The four
// eventual First Four winners retain those same pre-tournament records.
const field = {
  East: [
    ['uconn','UConn',1,31,3], ['stetson','Stetson',16,22,12],
    ['florida-atlantic','Florida Atlantic',8,25,8], ['northwestern','Northwestern',9,21,11],
    ['san-diego-state','San Diego State',5,24,10], ['uab','UAB',12,23,11],
    ['auburn','Auburn',4,27,7], ['yale','Yale',13,22,9],
    ['byu','BYU',6,23,10], ['duquesne','Duquesne',11,24,11],
    ['illinois','Illinois',3,26,8], ['morehead-state','Morehead State',14,26,8],
    ['washington-state','Washington State',7,24,9], ['drake','Drake',10,28,6],
    ['iowa-state','Iowa State',2,27,7], ['south-dakota-state','South Dakota State',15,22,12],
  ],
  West: [
    ['north-carolina','North Carolina',1,27,7], ['wagner','Wagner',16,16,15],
    ['mississippi-state','Mississippi State',8,21,13], ['michigan-state','Michigan State',9,19,14],
    ['grand-canyon','Grand Canyon',12,29,4],
    ['alabama','Alabama',4,21,11], ['charleston','Charleston',13,27,7],
    ['clemson','Clemson',6,21,11], ['new-mexico','New Mexico',11,26,9],
    ['baylor','Baylor',3,23,10], ['colgate','Colgate',14,25,9],
    ['dayton','Dayton',7,24,7], ['nevada','Nevada',10,26,7],
    ['arizona','Arizona',2,25,8], ['long-beach-state','Long Beach State',15,21,14],
  ],
  South: [
    ['houston','Houston',1,30,4], ['longwood','Longwood',16,21,13],
    ['nebraska','Nebraska',8,23,10], ['texas-am','Texas A&M',9,20,14],
    ['wisconsin','Wisconsin',5,22,13], ['james-madison','James Madison',12,31,3],
    ['duke','Duke',4,24,8], ['vermont','Vermont',13,28,6],
    ['texas-tech','Texas Tech',6,23,10], ['nc-state','NC State',11,22,14],
    ['kentucky','Kentucky',3,23,9], ['oakland','Oakland',14,23,11],
    ['florida','Florida',7,24,11], ['colorado','Colorado',10,24,10],
    ['marquette','Marquette',2,25,9], ['western-kentucky','Western Kentucky',15,22,11],
  ],
  Midwest: [
    ['purdue','Purdue',1,29,4], ['grambling-state','Grambling State',16,20,14],
    ['utah-state','Utah State',8,27,6], ['tcu','TCU',9,21,12],
    ['gonzaga','Gonzaga',5,25,7], ['mcneese','McNeese',12,30,3],
    ['kansas','Kansas',4,22,10], ['samford','Samford',13,29,5],
    ['south-carolina','South Carolina',6,26,7], ['oregon','Oregon',11,23,11],
    ['creighton','Creighton',3,23,9], ['akron','Akron',14,24,10],
    ['texas','Texas',7,20,12], ['colorado-state','Colorado State',10,24,10],
    ['tennessee','Tennessee',2,24,8], ['saint-peters',"Saint Peter's",15,19,13],
  ],
};

const teams = Object.entries(field).flatMap(([region, entries]) => entries.map(([id,name,seed,wins,losses]) => ({
  id: `${id}-2024`, name, season: '2023-24', seed, region,
  stats: {wins, losses, ppg:null, oppPpg:null, pace:null, threePct:null},
  source: S.bracket,
})));

export const CATALOG = {
  version: 'verified-university-2026-10-16.3',
  checkedAt: '2026-10-16',
  sourceLabel: 'Official university statistics and the NCAA 2024 bracket',
  players,
  draftGroups: SEASON_TABLES.map(({school,season})=>({school,season})),
  teams,
  sources: [...new Map(Object.values(S).map(s=>[s.url,s])).values()],
  coverage: [
    'Random drafting uses 96 players from seven complete school-season tables. Seven additional biography records are available for research only until their full team tables are included.',
    `${players.length} hand-checked player-seasons from 2005-06 through 2023-24, including complete team tables, ordinary starters and deep reserves. This is a curated collection, not a complete historical player database.`,
    'Historical player values are final all-games season statistics. Where a source supplies totals only, per-game figures are totals divided by games and rounded to one decimal.',
    '63 real 2023-24 opponents: the Round of 64 field with Saint Mary\'s replaced by your drafted team. Records are frozen at Selection Sunday, before First Four games.',
    'Opponent points, points allowed, pace and 3PT rates are not verified in this snapshot and remain unavailable. Opponent strength estimates use original seed and win-loss record.',
    'Credits, eligible game roles, derived strengths, new seeds, shot locations and simulated outcomes belong to the game model. They are not historical statistics.',
    'Except for the eight approved concept prices, credits = round(1 + 0.45 PPG + 0.45 RPG + 0.60 APG + SPG + 1.20 BPG + 0.03 MPG), bounded to 1-22. Missing terms contribute zero to price only. Role eligibility is original game design.',
    'FG%, turnovers per game, starts, offensive and defensive rebounds per game, and shooting attempt counts are included where sourced. Season totals accompany full-table records. Tiny samples remain visible and are not projected into full seasons.',
    'Noah made 1 of 1 three-point attempts; Edey made 1 of 2. Their percentages must be interpreted with the displayed attempt counts, not as high-volume shooting ability.',
    'A null shooting percentage means no attempts or unavailable data. A verified 0% with positive attempts is a real observed value. Missing data is never replaced in the historical record.',
    'Anthony Davis has verified games, points, rebounds and blocks; other fields await a complete official season table.',
    'Corey Brewer\'s minutes are unavailable because two official Florida sources disagree (1,053 versus 1,063 season minutes). Amile Jefferson\'s 2015-16 values cover only nine games.',
    'CollegeBasketballData.com is the planned broader API. No CBBD credential or live API response is included in this bundled snapshot.',
  ],
};
