/** Final Possession: pure, deterministic game rules. All ratings are game estimates. */
export const MODEL_VERSION = 'fp-possession-3.0.0';
export const ROSTER_SIZE = 12;
export const ROUND_NAMES = ['Round of 64', 'Round of 32', 'Sweet 16', 'Elite Eight', 'National semifinals', 'Championship'];
const ROLES = ['PG', 'SG', 'SF', 'PF', 'C'];
const REGIONS = ['East', 'West', 'South', 'Midwest'];
const PAIRS = [1, 16, 8, 9, 5, 12, 4, 13, 6, 11, 3, 14, 7, 10, 2, 15];
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const copy = value => structuredClone(value);
const number = (value, fallback) => Number.isFinite(value) ? value : fallback;
const mean = values => values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
const guard = p => p.roles.some(r => r === 'PG' || r === 'SG');
const big = p => p.roles.some(r => r === 'PF' || r === 'C');
const selected = (run, catalog) => run.roster.map(id => player(catalog, id));
function draftPool(catalog) {
  if (!Array.isArray(catalog.draftGroups)) return catalog.players;
  const approved = new Set(catalog.draftGroups.map(g=>JSON.stringify([g.school,g.season])));
  return catalog.players.filter(p=>approved.has(JSON.stringify([p.school,p.season])));
}
function player(catalog, id) {
  const found = catalog.players.find(p => p.id === id);
  if (!found) throw new Error('That player is not in this data snapshot.');
  return found;
}
function checkCatalog(run, catalog) {
  if (run.catalogVersion !== catalog.version) throw new Error('This run needs its original data snapshot. Start a new run to use the new data.');
  if (run.modelVersion !== MODEL_VERSION) throw new Error('This run uses an older game model. Start a new run.');
}
function hash(value) {
  let h = 2166136261;
  for (const c of String(value)) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  return h >>> 0 || 1;
}
function random(run) {
  let x = run.rng >>> 0;
  x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
  run.rng = x >>> 0 || 1;
  return run.rng / 4294967296;
}
const pick = (run, list) => list[Math.floor(random(run) * list.length)];
function weighted(run, list, weight) {
  const weights = list.map(p => Math.max(0.01, weight(p)));
  let target = random(run) * weights.reduce((a, b) => a + b, 0);
  return list.find((p, i) => (target -= weights[i]) < 0) || list.at(-1);
}
function append(game, text) { game.log.push(text); if (game.log.length > 60) game.log.shift(); }

/** Select complete school rosters with a separate random stream before freezing a run. */
export function prepareRunCatalog(fullCatalog,seed) {
  const seedHash=hash(`cohort:${seed}`);
  if(fullCatalog.cohort?.seedHash===seedHash)return copy(fullCatalog);
  const eligible=draftPool(fullCatalog),bySchool=new Map();
  for(const p of eligible) {
    if(!bySchool.has(p.school))bySchool.set(p.school,new Set());
    bySchool.get(p.school).add(p.season);
  }
  const rng={rng:seedHash},schools=[...bySchool.keys()].sort();
  for(let i=schools.length-1;i>0;i--){const j=Math.floor(random(rng)*(i+1));[schools[i],schools[j]]=[schools[j],schools[i]];}
  const groups=schools.slice(0,16).map(school=>({school,season:pick(rng,[...bySchool.get(school)].sort())}));
  const keys=new Set(groups.map(g=>JSON.stringify([g.school,g.season])));
  const players=eligible.filter(p=>keys.has(JSON.stringify([p.school,p.season])));
  const {players:ignoredPlayers,teams:ignoredTeams,draftGroups:ignoredGroups,...metadata}=fullCatalog;
  return {...copy(metadata),version:`${fullCatalog.version}:cohort-${hash(`${seedHash}|${[...keys].sort().join('|')}`).toString(16)}`,
    parentVersion:fullCatalog.version,sourceVersion:fullCatalog.sourceVersion||fullCatalog.version,players:copy(players),teams:copy(fullCatalog.teams),draftGroups:groups,
    cohort:{seedHash,schools:groups.map(g=>g.school),groups:copy(groups),sourcePlayerCount:fullCatalog.players.length,selectedPlayerCount:players.length}};
}

export function createRun(catalog, seed, teamName = 'Your Team') {
  const n = hash(seed);
  const run = {schema: 1, id: `fp-${n.toString(36)}`, seed, rng: n,
    teamName: String(teamName).trim().slice(0, 40) || 'Your Team', phase: 'draft',
    roster: [], starters: [], minutes: {}, style: 'balanced', catalogVersion: catalog.version,
    modelVersion: MODEL_VERSION, bracket: null, game: null, wins: 0, results: [], createdAt: null,
    draft: {school: null, season: null, offers: [], round: 1, rerollsLeft: 2, seen: [],seenSchools:[]}};
  dealOffers(run, catalog);
  return run;
}

/** Finds five different players, one for each starting role. */
function roleMatch(players) {
  const result = [];
  function visit(role) {
    if (role === 5) return true;
    for (const p of players) if (p.roles.includes(ROLES[role]) && !result.includes(p.id)) {
      result.push(p.id);
      if (visit(role + 1)) return true;
      result.pop();
    }
    return false;
  }
  return visit(0) ? result : null;
}

/** Exact minimum-cost completion DP. One player-season per person; each fills at most one starting role. */
function canComplete(players, catalog) {
  if (players.length === ROSTER_SIZE) return players.reduce((n,p)=>n+p.cost,0) <= 100 && players.filter(guard).length >= 2 && players.filter(big).length >= 2 && Boolean(roleMatch(players));
  // A constructed, fully checked completion is proof of feasibility. Most large
  // pools take this inexpensive path. Difficult cases still use exact DP below.
  const available = draftPool(catalog);
  const pool = [...available].sort((a,b)=>a.cost-b.cost || a.id.localeCompare(b.id));
  const completion = [...players], assigned = new Set(), people = new Set(players.map(p=>p.personId));
  const roleOrder = [...ROLES].sort((a,b)=>pool.filter(p=>p.roles.includes(a)).length-pool.filter(p=>p.roles.includes(b)).length);
  for (const role of roleOrder) {
    const existing = completion.find(p=>p.roles.includes(role)&&!assigned.has(p.id));
    if (existing) {assigned.add(existing.id);continue;}
    const addition = pool.find(p=>p.roles.includes(role)&&!people.has(p.personId));
    if (!addition || completion.length>=ROSTER_SIZE) break;
    completion.push(addition); people.add(addition.personId); assigned.add(addition.id);
  }
  for (const p of pool) if (completion.length<ROSTER_SIZE && !people.has(p.personId)) {completion.push(p);people.add(p.personId);}
  if (completion.length===ROSTER_SIZE && completion.reduce((n,p)=>n+p.cost,0)<=100 && roleMatch(completion)) return true;
  const size = (ROSTER_SIZE+1) * 3 * 3 * 32;
  let states = new Float64Array(size).fill(Infinity); states[0] = 0;
  const encode = (count, guards, bigs, mask) => ((count * 3 + guards) * 3 + bigs) * 32 + mask;
  function transition(source, options, forced) {
    const target = forced ? new Float64Array(size).fill(Infinity) : source.slice();
    for (let key = 0; key < size; key++) {
      if (!Number.isFinite(source[key])) continue;
      const mask = key % 32, b = Math.floor(key / 32) % 3, g = Math.floor(key / 96) % 3, count = Math.floor(key / 288);
      if (count >= ROSTER_SIZE) continue;
      for (const p of options) {
        const cost = source[key] + p.cost;
        if (!Number.isFinite(cost) || cost > 100) continue;
        const ng = Math.min(2, g + Number(guard(p))), nb = Math.min(2, b + Number(big(p)));
        const masks = [mask, ...p.roles.map(r => mask | (1 << ROLES.indexOf(r))).filter(m => m !== mask)];
        for (const m of masks) {
          const k = encode(count + 1, ng, nb, m);
          if (cost < target[k]) target[k] = cost;
        }
      }
    }
    return target;
  }
  for (const p of players) states = transition(states, [p], true);
  const used = new Set(players.map(p => p.personId));
  const groups = new Map();
  for (const p of available) if (!used.has(p.personId)) {
    if (!groups.has(p.personId)) groups.set(p.personId, []);
    groups.get(p.personId).push(p);
  }
  for (const options of groups.values()) states = transition(states, options, false);
  return states[encode(ROSTER_SIZE, 2, 2, 31)] <= 100;
}

/** Draw a school-season first, uniformly among groups with a legal pick. */
function dealOffers(run, catalog, previousBucket = null) {
  const roster = selected(run, catalog), people = new Set(roster.map(p => p.personId));
  const remaining = 100 - roster.reduce((n, p) => n + p.cost, 0);
  const groups = new Map(), feasible = new Map();
  for (const p of draftPool(catalog)) {
    if (people.has(p.personId) || !Number.isFinite(p.cost) || p.cost < 0 || p.cost > remaining) continue;
    const key = JSON.stringify([p.school,p.season]);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(p);
  }
  const legal = p => {
    if (!feasible.has(p.id)) feasible.set(p.id,canComplete([...roster,p],catalog));
    return feasible.get(p.id);
  };
  let buckets = [...groups.entries()].filter(([,members]) => members.some(legal));
  if (previousBucket) buckets = buckets.filter(([key]) => key !== previousBucket);
  if (!buckets.length) throw new Error(previousBucket ? 'No different school and season can complete this roster. Keep the current group; your redraw is not spent.' : 'There are not enough eligible players to complete a 12-player roster within 100 credits.');
  const unseen=buckets.filter(([,members])=>!run.draft.seenSchools.includes(members[0].school));
  if(unseen.length)buckets=unseen;
  const bySchool=new Map();
  for(const bucket of buckets){const school=bucket[1][0].school;if(!bySchool.has(school))bySchool.set(school,[]);bySchool.get(school).push(bucket);}
  const [key,members] = pick(run,pick(run,[...bySchool.values()]));
  [run.draft.school,run.draft.season] = JSON.parse(key);
  run.draft.offers = members.filter(legal).map(p => p.id);
  run.draft.round = Math.min(ROSTER_SIZE, run.roster.length + 1);
  run.draft.seen = [...new Set([...run.draft.seen, ...run.draft.offers])];
  run.draft.seenSchools=[...new Set([...run.draft.seenSchools,run.draft.school])];
}

export function canDraft(run, playerId, catalog) {
  if (!run || run.phase !== 'draft' || run.catalogVersion !== catalog.version || run.modelVersion !== MODEL_VERSION || !run.draft?.offers?.includes(playerId)) return false;
  const p = catalog.players.find(p => p.id === playerId);
  if (!p || run.roster.length >= ROSTER_SIZE || p.school !== run.draft.school || p.season !== run.draft.season) return false;
  if (!draftPool(catalog).some(x=>x.id===playerId)) return false;
  const roster = selected(run, catalog);
  return !roster.some(x => x.personId === p.personId) && roster.reduce((n, x) => n + x.cost, 0) + p.cost <= 100;
}

export function rerollDraft(run, catalog) {
  checkCatalog(run, catalog);
  if (run.phase !== 'draft' || !run.draft?.offers?.length) throw new Error('There is no active school and season to redraw.');
  if (run.draft.rerollsLeft <= 0) throw new Error('You have used both school-season redraws. Choose a player from the current group.');
  const next = copy(run);
  dealOffers(next, catalog, JSON.stringify([next.draft.school,next.draft.season]));
  next.draft.rerollsLeft--;
  return next;
}

export function validateRoster(run, catalog) {
  const players = selected(run, catalog), errors = [];
  const spent = players.reduce((total, p) => total + p.cost, 0);
  const guards = players.filter(guard).length, bigs = players.filter(big).length;
  if (players.length !== ROSTER_SIZE) errors.push(`Draft ${ROSTER_SIZE - players.length} more player${players.length === ROSTER_SIZE-1 ? '' : 's'} to complete your 12-player roster.`);
  if (new Set(players.map(p => p.personId)).size !== players.length) errors.push('Only one season of each person can be drafted.');
  if (spent > 100) errors.push('Your roster exceeds the 100-credit budget.');
  if (guards < 2) errors.push('Include at least two guards (PG or SG).');
  if (bigs < 2) errors.push('Include at least two bigs (PF or C).');
  if (!roleMatch(players)) errors.push('Your starting five must cover PG, SG, SF, PF and C.');
  return {valid: errors.length === 0, errors, spent, remaining: 100 - spent, guards, bigs};
}

export function draftPlayer(run, playerId, catalog) {
  checkCatalog(run, catalog);
  if (!['draft', 'lineup'].includes(run.phase)) throw new Error('The draft is locked after tournament seeding.');
  if (run.roster.length >= ROSTER_SIZE) throw new Error('Your roster is full. Continue to the lineup or start a new run.');
  if (!run.draft?.offers?.includes(playerId)) throw new Error('Choose a player from the currently offered school and season. Player search and detail pages cannot bypass the draft.');
  const p = player(catalog, playerId), roster = selected(run, catalog);
  if (p.school !== run.draft.school || p.season !== run.draft.season) throw new Error('This player is not in the currently offered school and season.');
  if (!draftPool(catalog).some(x=>x.id===playerId)) throw new Error('This player is in the reference library. Only complete published school-season rosters enter the random draft.');
  if (roster.some(x => x.personId === p.personId)) throw new Error('You already drafted a season of this player.');
  if (!Number.isFinite(p.cost) || p.cost < 0) throw new Error('This player does not have a valid draft cost.');
  if (roster.reduce((n, x) => n + x.cost, 0) + p.cost > 100) throw new Error('You do not have enough draft credits.');
  if (!canComplete([...roster, p], catalog)) throw new Error('This pick would prevent a 12-player roster within 100 credits that covers every position.');
  const next = copy(run); next.roster.push(p.id); next.starters = []; next.minutes = {};
  next.draft.offers = [];
  if (next.roster.length === ROSTER_SIZE) return autoRotation({...next, phase: 'lineup'}, catalog);
  dealOffers(next, catalog);
  return next;
}

export function removePlayer(run, playerId, catalog) {
  checkCatalog(run, catalog);
  throw new Error('Draft picks are committed. Start a new run to draft a different roster.');
}

export function setRotation(run, {starters, minutes, style = 'balanced'}, catalog) {
  checkCatalog(run, catalog);
  if (!['draft', 'lineup'].includes(run.phase)) throw new Error('Set your rotation before seeding the tournament.');
  const validation = validateRoster(run, catalog);
  if (!validation.valid) throw new Error(validation.errors[0]);
  if (!Array.isArray(starters) || starters.length !== 5 || new Set(starters).size !== 5) throw new Error('Choose five different starters.');
  starters.forEach((id, i) => {
    if (!run.roster.includes(id) || !player(catalog, id).roles.includes(ROLES[i])) throw new Error(`Choose an eligible ${ROLES[i]} from your roster.`);
  });
  for (const id of run.roster) if (!Number.isInteger(minutes[id]) || minutes[id] < 0 || minutes[id] > 40) throw new Error('Each player needs a whole-number minute target between 0 and 40.');
  if (run.roster.reduce((n, id) => n + minutes[id], 0) !== 200) throw new Error('Regulation minute targets must total 200.');
  if (starters.some(id => minutes[id] === 0)) throw new Error('Each starter needs a positive minute target.');
  if (!['balanced', 'pace', 'inside', 'shooting', 'defense', 'control', 'fast', 'slow', 'spacing'].includes(style)) throw new Error('Choose a supported team style.');
  return {...copy(run), phase: 'lineup', starters: [...starters], minutes: Object.fromEntries(run.roster.map(id => [id, minutes[id]])), style};
}

function quality(p) {
  const s = p.stats || {}, per30 = 30 / clamp(number(s.mpg, 30), 15, 40), reliability = sampleReliability(p);
  const production = (key,missing,prior,max) => {
    const observed=clamp(number(s[key],missing)*per30,0,max);
    // Uncertainty can reduce a spectacular tiny sample, but it must not raise
    // a zero-production reserve above a player with demonstrated production.
    return Math.min(observed,prior+(observed-prior)*reliability);
  };
  return clamp(43 + production('ppg',12,8,35)*0.92 + production('rpg',4,3,18)*1.05 + production('apg',2,1.5,12)*1.7 + production('spg',0.8,0.5,5)*2 + production('bpg',0.4,0.25,7)*1.6 + (shootingEstimate(p)*100-33)*0.18 + (fieldGoalEstimate(p)-0.45)*8,45,98);
}
function sampleReliability(p) {
  const s = p.stats || {};
  // Unknown minutes use a conservative evidence proxy, never a factual display.
  const minutes = Math.max(0,number(p.seasonTotals?.minutes,Math.max(0,number(s.games,0))*clamp(number(s.mpg,15),0,50)));
  return Math.min(1,minutes/300);
}
function fieldGoalEstimate(p) {
  const attempts=p.stats?.fgAttempts, weight=Number.isFinite(attempts)&&attempts>=0 ? attempts/(attempts+40) : 0.5;
  return 0.45 + (clamp(number(p.stats?.fgPct,45)/100,0,1)-0.45)*sampleReliability(p)*weight;
}
function freeThrowEstimate(p) {
  const attempts=p.stats?.ftAttempts, weight=Number.isFinite(attempts)&&attempts>=0 ? attempts/(attempts+20) : 0.5;
  return 0.72 + (clamp(number(p.stats?.ftPct,72)/100,0,1)-0.72)*sampleReliability(p)*weight;
}
function shootingEstimate(p) {
  const s = p.stats || {}, attempts = s.threeAttempts;
  const weight = Number.isFinite(attempts) && attempts >= 0 ? attempts / (attempts + 60) : 0.5;
  return clamp((33 + (number(s.threePct, 33) - 33) * weight * sampleReliability(p)) / 100, 0.18, 0.50);
}
export function autoRotation(run, catalog) {
  checkCatalog(run, catalog);
  if (!['draft', 'lineup'].includes(run.phase)) throw new Error('The rotation is locked for this tournament.');
  const v = validateRoster(run, catalog);
  if (!v.valid) throw new Error(v.errors[0]);
  const starters = roleMatch(selected(run, catalog).sort((a, b) => quality(b) - quality(a) || a.id.localeCompare(b.id)));
  const bench=run.roster.filter(id=>!starters.includes(id));
  const benchBase=Math.floor(50/bench.length),extra=50%bench.length;
  const minutes = Object.fromEntries(run.roster.map(id => [id, starters.includes(id) ? 30 : benchBase+Number(bench.indexOf(id)<extra)]));
  return setRotation(run, {starters, minutes, style: run.style}, catalog);
}

function opponentStrength(team) {
  const s = team.stats || {}, wins = number(s.wins, 0), losses = number(s.losses, 0);
  const winRate = wins + losses ? wins / (wins + losses) : 0.5;
  // Tournament seed anchors schedule context; record is a small independent modifier.
  const seedEstimate = 91 - (clamp(number(team.seed, 8), 1, 16) - 1) * 2.15 + (winRate - 0.70) * 10;
  if (Number.isFinite(s.adjustedMargin)) return clamp(65 + s.adjustedMargin * 0.95, 48, 98);
  if (Number.isFinite(s.ppg) && Number.isFinite(s.oppPpg)) return clamp(seedEstimate * 0.5 + (66 + (s.ppg - s.oppPpg) * 1.15) * 0.5, 48, 98);
  return clamp(seedEstimate, 48, 95);
}
function opponentBasis(team) {
  if (Number.isFinite(team.stats?.adjustedMargin)) return 'Adjusted efficiency margin: 65 + 0.95 × margin, bounded 48–98.';
  if (Number.isFinite(team.stats?.ppg) && Number.isFinite(team.stats?.oppPpg)) return 'Equal blend of seed/record estimate and 66 + 1.15 × points-per-game margin; scoring margin is not schedule adjusted.';
  return 'Tournament seed and win-loss record: 91 − 2.15 × (seed − 1) + 10 × (win rate − 0.70). Detailed efficiency unavailable.';
}
export function estimateTeam(run, catalog) {
  const ps = selected(run, catalog);
  const total = ps.reduce((n, p) => n + number(run.minutes[p.id], 25), 0) || 1;
  const production = ps.reduce((n, p) => n + quality(p) * number(run.minutes[p.id], 25) / total, 0);
  const creation = mean(ps.map(p => number(p.stats?.apg, 2)));
  const rebounding = mean(ps.map(p => number(p.stats?.rpg, 4)));
  const spacing = mean(ps.filter(p => guard(p) || p.roles.includes('SF')).map(p => shootingEstimate(p) * 100));
  const bench=ps.filter(p=>!run.starters.includes(p.id));
  const benchMinutes=run.starters.length?bench.reduce((n,p)=>n+number(run.minutes[p.id],0),0):0;
  const depth = Math.min(3,Math.max(0,benchMinutes/20));
  const fit = roleMatch(ps) ? 2.5 : -7;
  const strength = Math.round(clamp(production + fit + depth * 0.4, 40, 98) * 10) / 10;
  const rank = 1 + catalog.teams.filter(t => opponentStrength(t) > strength || (opponentStrength(t) === strength && t.id.localeCompare('user') < 0)).length;
  const strengths = [], weaknesses = [];
  (creation >= 3 ? strengths : weaknesses).push(creation >= 3 ? 'Multiple passing options' : 'Limited secondary creation');
  (rebounding >= 5.5 ? strengths : weaknesses).push(rebounding >= 5.5 ? 'Strong rebounding production' : 'Protect the defensive glass');
  (spacing >= 37 ? strengths : weaknesses).push(spacing >= 37 ? 'Perimeter shooting' : 'Spacing needs care');
  if (depth >= 2) strengths.push('Bench minutes available');
  return {strength, seed: Math.min(16, Math.ceil(rank / 4)), factors: [
    {label: 'Production', value: Math.round(production * 10) / 10, detail: 'Weighted by your minute targets. Points, rebounds and assists are adjusted to 30 minutes where minutes are available.'},
    {label: 'Role coverage', value: fit, detail: 'Five distinct eligible starters support lineup balance.'},
    {label: 'Bench support', value: depth * 0.4, detail: 'Scheduled bench minutes support the rotation. Extra roster slots alone add no strength.'}], strengths, weaknesses,
    method: 'Original, uncalibrated game estimate. Minute normalization uses at least 15 MPG. Bounded production above role-player baselines is reduced until 300 recorded season minutes; uncertainty never boosts low production. Missing MPG uses 15 only for evidence weight. Missing production inputs: 12 points, 4 rebounds, 2 assists, 0.8 steals, 0.4 blocks. Three-point rates shrink toward 33% by attempts/(attempts+60), or 50% when attempts are missing, and by minute reliability. Available FG% has a small reliability-weighted effect. Opponents use available efficiency or scoring margin before seed/record fallback. Pace, schedule and era are not fully normalized.'};
}

export function seedTournament(run, catalog) {
  checkCatalog(run, catalog);
  if (run.bracket && !['draft', 'lineup'].includes(run.phase)) return copy(run);
  if (!['draft', 'lineup'].includes(run.phase)) throw new Error('This tournament has already started.');
  let next = copy(run);
  if (!next.starters.length) next = autoRotation(next, catalog);
  next = setRotation(next, next, catalog);
  if (catalog.teams.length !== 63 || new Set(catalog.teams.map(t => t.id)).size !== 63 || catalog.teams.some(t => t.id === 'user')) throw new Error('The tournament needs exactly 63 unique opponents.');
  const entrants = catalog.teams.map(t => ({...copy(t), originalSeed: t.seed, originalRegion: t.region, strength: opponentStrength(t), strengthBasis: opponentBasis(t)}));
  entrants.push({id: 'user', name: next.teamName, season: 'Mixed era', strength: estimateTeam(next, catalog).strength});
  entrants.sort((a, b) => b.strength - a.strength || a.id.localeCompare(b.id));
  entrants.forEach((t, i) => {t.seed = Math.floor(i / 4) + 1; t.region = REGIONS[Math.floor(i / 4) % 2 ? 3 - i % 4 : i % 4];});
  const first = [];
  for (const region of REGIONS) for (let i = 0; i < 16; i += 2) first.push({id: `r0-g${first.length}`, round: 0, region,
    teamA: entrants.find(t => t.region === region && t.seed === PAIRS[i]).id,
    teamB: entrants.find(t => t.region === region && t.seed === PAIRS[i + 1]).id, scoreA: null, scoreB: null, winner: null});
  const rounds = [first];
  for (let r = 1; r < 6; r++) rounds.push(Array.from({length: 32 / 2 ** r}, (_, i) => ({id: `r${r}-g${i}`, round: r, region: r < 4 ? REGIONS[Math.floor(i / (8 / 2 ** r))] : 'National', teamA: null, teamB: null, scoreA: null, scoreB: null, winner: null})));
  next.bracket = {entrants, rounds, policy: '63 teams from the 2024 field plus your roster. Saint Mary’s is replaced. All 64 teams are reseeded by the game model.'};
  next.phase = 'seeded';
  return next;
}

function activeMatch(run) { return run.bracket?.rounds.flat().find(g => !g.winner && (g.teamA === 'user' || g.teamB === 'user')); }
export function nextOpponent(run) {
  const match = activeMatch(run);
  if (!match) return null;
  return run.bracket.entrants.find(t => t.id === (match.teamA === 'user' ? match.teamB : match.teamA)) || null;
}
const teamStats = () => ({fieldGoalsMade: 0, fieldGoalsAttempted: 0, threesMade: 0, threesAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, rebounds: 0, assists: 0, turnovers: 0});
const playerStats = () => ({points: 0, rebounds: 0, assists: 0, fouls: 0, minutes: 0, fatigue: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threesMade: 0, threesAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, turnovers: 0});

export function startGame(run, plan = 'move-ball', catalog) {
  checkCatalog(run, catalog);
  if (run.phase === 'playing') return copy(run);
  if (run.phase !== 'seeded') throw new Error('Seed your tournament before starting a game.');
  if (!['move-ball', 'attack-inside', 'control-tempo'].includes(plan)) throw new Error('Choose a supported scouting plan.');
  const next = copy(run), match = activeMatch(next), opponent = nextOpponent(next);
  if (!match || !opponent) throw new Error('Your next opponent has not been determined.');
  next.phase = 'playing';
  next.game = {matchId: match.id, round: match.round, opponentId: opponent.id, period: 1, clock: 1200, shotClock: 30,
    possession: random(next) < 0.5 ? 'user' : 'opponent', score: {user: 0, opponent: 0}, timeouts: {user: 4, opponent: 4},
    teamFouls: {user: 0, opponent: 0}, lineup: [...next.starters], players: Object.fromEntries(next.roster.map(id => [id, playerStats()])),
    teamStats: {user: teamStats(), opponent: teamStats()}, moment: null, log: [], shots: [], status: 'moment', winner: null, plan,
    lastConsequence: '', decisions: [], elapsed: 0, stage: 0, lastRotation: 0, manualUntil: 0,
    scoringRun: {side: null, points: 0}, tactic: plan === 'attack-inside' ? 'inside' : plan === 'control-tempo' ? 'control' : 'balanced', defense: 'balanced'};
  append(next.game, `${next.teamName} vs ${opponent.name}. Every possession begins from 0–0.`);
  return simulateToMoment(next, catalog);
}

function livePlayers(run, catalog) { return run.game.lineup.map(id => player(catalog, id)); }
function rotate(run, catalog, force = false) {
  const g = run.game;
  const available = run.roster.filter(id => g.players[id].fouls < 5);
  const scheduled = available.filter(id => run.minutes[id] > 0);
  const eligible = scheduled.length >= 5 ? scheduled : available;
  if (!force && (g.elapsed < g.manualUntil || g.elapsed - g.lastRotation < 90)) return;
  const duration = g.period <= 2 ? 2400 : 2400 + (g.period - 2) * 300;
  const desirability = id => number(run.minutes[id], 25) * Math.min(g.elapsed + 90, duration) / 2400 - g.players[id].minutes - g.players[id].fatigue / 18 + (g.elapsed < 90 && run.starters.includes(id) ? 10 : 0);
  eligible.sort((a, b) => desirability(b) - desirability(a) || a.localeCompare(b));
  const old = [...g.lineup];
  g.lineup = eligible.slice(0, 5); g.lastRotation = g.elapsed;
  if (force && old.some(id => g.players[id].fouls >= 5)) append(g, 'The rotation replaces a fouled-out player with an eligible teammate.');
}
function tick(run, seconds) {
  const g = run.game; g.clock = Math.max(0, g.clock - seconds); g.elapsed += seconds;
  for (const id of run.roster) {
    const p = g.players[id];
    if (g.lineup.includes(id)) {p.minutes += seconds / 60; p.fatigue = clamp(p.fatigue + seconds * (g.defense === 'press' ? 0.073 : 0.047), 0, 100);}
    else p.fatigue = Math.max(0, p.fatigue - seconds * 0.095);
  }
}
function addPoints(run, side, amount, id) {
  const g = run.game; g.score[side] += amount;
  if (side === 'user' && id) g.players[id].points += amount;
  if (g.scoringRun.side === side) g.scoringRun.points += amount;
  else g.scoringRun = {side, points: amount};
}
function shotLog(run, side, id, type, made) {
  const g = run.game;
  // Original diagram coordinates, not historical tracking data.
  const x = type === 3 ? 8 + random(run) * 84 : 35 + random(run) * 30;
  const y = type === 3 ? 38 + random(run) * 25 : type === 'FT' ? 29 : 13 + random(run) * 23;
  g.shots.push({side, playerId: id || null, type, made, x: Math.round(x), y: Math.round(y), period: g.period, clock: g.clock});
}
function freeThrow(run, side, shooter, probability) {
  const g = run.game, box = g.teamStats[side], pbox = side === 'user' ? g.players[shooter.id] : null;
  box.freeThrowsAttempted++; if (pbox) pbox.freeThrowsAttempted++;
  const made = random(run) < probability;
  if (made) {box.freeThrowsMade++; if (pbox) pbox.freeThrowsMade++; addPoints(run, side, 1, shooter?.id);}
  shotLog(run, side, shooter?.id, 'FT', made);
  return made;
}
function rebound(run, side, catalog) {
  const g = run.game; g.teamStats[side].rebounds++;
  if (side === 'user' && g.lineup.length) {
    const rebounder = weighted(run, livePlayers(run, catalog), p => number(p.stats?.rpg, 4));
    g.players[rebounder.id].rebounds++;
  }
}

function possession(run, catalog) {
  const g = run.game, side = g.possession, other = side === 'user' ? 'opponent' : 'user';
  rotate(run, catalog);
  if (!g.lineup.length) {g.forfeit = 'Your team has no eligible players remaining.'; finishGame(run, catalog, 'opponent'); return;}
  const opponent = run.bracket.entrants.find(t => t.id === g.opponentId), own = run.bracket.entrants.find(t => t.id === 'user');
  const diff = (side === 'user' ? own.strength - opponent.strength : opponent.strength - own.strength) * 0.0029;
  const fast = side === 'user' && (['push', 'quick-three'].includes(g.tactic) || ['fast', 'pace'].includes(run.style));
  const slow = side === 'user' && (g.tactic === 'control' || ['slow', 'control'].includes(run.style));
  const intentional = side === 'opponent' && g.defense === 'foul' && g.period >= 2 && g.clock < 120 && g.score.user <= g.score.opponent;
  // Steps include rebounds and non-shooting fouls that retain possession. A neutral
  // 15-second step therefore produces approximately 68 completed possessions/side.
  const paceScale = 68 / clamp((68 + number(opponent.stats?.pace, 68)) / 2, 54, 84);
  let seconds = Math.min(29, Math.max(3, Math.floor(((fast ? 7 : slow ? 20 : 8) + random(run) * (fast ? 11 : slow ? 9 : 14)) * paceScale)));
  if (intentional) seconds = 2 + Math.floor(random(run) * 4);
  if (g.period >= 2 && g.clock < 60 && g.score[side] < g.score[other]) seconds = Math.min(seconds, 6 + Math.floor(random(run) * 7));
  seconds = Math.min(seconds, g.clock); tick(run, seconds); g.shotClock = Math.max(0, 30 - seconds);
  const live = livePlayers(run, catalog);
  const shooter = side === 'user' ? weighted(run, live, p => number(p.stats?.ppg, 12) * (g.tactic === 'inside' && big(p) ? 1.8 : 1)) : null;
  const fatigue = side === 'user' ? mean(live.map(p => g.players[p.id].fatigue)) : 26 + g.elapsed / 150;
  const box = g.teamStats[side], pbox = shooter ? g.players[shooter.id] : null;
  const creation = side === 'user' ? mean(live.map(p => number(p.stats?.apg, 2))) : 2.5;
  let turnover = clamp(0.17 - creation * 0.008 - diff * 0.35 + fatigue * 0.0005, 0.06, 0.27);
  if (side === 'opponent' && g.defense === 'press') turnover += 0.05;
  if (side === 'user' && fast) turnover += 0.025;
  if (side === 'user' && slow) turnover -= 0.015;
  if (random(run) < turnover) {
    box.turnovers++; if (pbox) pbox.turnovers++; g.possession = other; g.shotClock = 30; return;
  }
  const foulChance = 0.14 + (side === 'opponent' && g.defense === 'press' ? 0.055 : 0);
  if (intentional || random(run) < foulChance) {
    g.teamFouls[other]++;
    if (other === 'user') {
      const offender = pick(run, live); g.players[offender.id].fouls++;
      if (g.players[offender.id].fouls === 5) {append(g, `${offender.name} fouls out.`); rotate(run, catalog, true);}
    }
    const shooting = !intentional && random(run) < 0.65;
    const double = shooting || g.teamFouls[other] >= 10;
    const bonus = g.teamFouls[other] >= 7;
    if (shooting || bonus) {
      const pct = side === 'user' ? clamp(freeThrowEstimate(shooter), 0.35, 0.98) : 0.72;
      const first = freeThrow(run, side, shooter, pct);
      const lastMade = double || first ? freeThrow(run, side, shooter, pct) : first;
      const offensive = !lastMade && g.clock > 0 && random(run) < 0.15;
      if (!lastMade) rebound(run, offensive ? side : other, catalog);
      g.possession = offensive ? side : other;
    }
    // Non-shooting, pre-bonus fouls retain possession and restart the shot clock.
    g.shotClock = 30; return;
  }
  let threeShare = side === 'user' ? guard(shooter) || shooter.roles.includes('SF') ? 0.45 : 0.15 : 0.36;
  if (side === 'user') threeShare += g.tactic === 'quick-three' ? 0.45 : g.tactic === 'inside' ? -0.17 : 0;
  if (side === 'user' && ['shooting', 'spacing'].includes(run.style)) threeShare += 0.10;
  if (side === 'user' && run.style === 'inside') threeShare -= 0.08;
  const three = random(run) < clamp(threeShare, 0.05, 0.90), points = three ? 3 : 2;
  let probability = three ? side === 'user' ? shootingEstimate(shooter) : number(opponent.stats?.threePct, 33) / 100 : 0.49;
  probability += diff - Math.max(0, fatigue - 35) * 0.0017;
  if (side === 'user') {
    if (g.tactic === 'balanced') probability += 0.013;
    if (g.tactic === 'inside' && !three) probability += 0.04;
    if (!three) probability += clamp((fieldGoalEstimate(shooter)-0.45)*0.25,-0.05,0.05);
    if (run.style === 'inside' && !three) probability += 0.015;
    if (run.style === 'defense') probability -= 0.01;
    if (g.tactic === 'push') probability += 0.017;
    probability -= Math.max(0, 5 - live.length) * 0.075;
  } else {
    if (run.style === 'defense') probability -= 0.015;
    if (g.defense === 'paint') probability += three ? 0.035 : -0.04;
    if (g.defense === 'perimeter') probability += three ? -0.035 : 0.025;
    if (g.defense === 'press') probability += 0.025;
  }
  box.fieldGoalsAttempted++; if (pbox) pbox.fieldGoalsAttempted++;
  if (three) {box.threesAttempted++; if (pbox) pbox.threesAttempted++;}
  const made = random(run) < clamp(probability, three ? 0.16 : 0.24, three ? 0.58 : 0.73);
  shotLog(run, side, shooter?.id, points, made);
  if (made) {
    box.fieldGoalsMade++; if (pbox) pbox.fieldGoalsMade++;
    if (three) {box.threesMade++; if (pbox) pbox.threesMade++;}
    addPoints(run, side, points, shooter?.id);
    if (random(run) < (g.tactic === 'balanced' && side === 'user' ? 0.66 : 0.54)) {
      box.assists++;
      if (side === 'user' && live.length > 1) {const helper = weighted(run, live.filter(p => p.id !== shooter.id), p => number(p.stats?.apg, 2)); g.players[helper.id].assists++;}
    }
    g.possession = other;
  } else {
    const offensive = random(run) < clamp(0.25 + diff * 0.5, 0.16, 0.34);
    rebound(run, offensive ? side : other, catalog); g.possession = offensive ? side : other;
  }
  g.shotClock = 30;
}

const displayNumber = value => Number.isFinite(value) ? String(Math.round(value*10)/10) : 'unavailable';
const displayClock = seconds => `${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
function contextEvidence(run,catalog) {
  const g=run.game, active=livePlayers(run,catalog), opponent=run.bracket.entrants.find(t=>t.id===g.opponentId);
  const own=g.teamStats.user, other=g.teamStats.opponent;
  const shooting=[...active].sort((a,b)=>number(b.stats?.threeAttempts,0)-number(a.stats?.threeAttempts,0));
  const shooters=shooting.filter(p=>Number.isFinite(p.stats?.threePct));
  const shootingLine=shooters.length ? shooters.slice(0,2).map(p=>`${p.name} (${p.season}): ${displayNumber(p.stats.threePct)}% from three on ${Number.isFinite(p.stats.threeAttempts)?p.stats.threeAttempts:'unknown'} season attempts${number(p.stats.threeAttempts,0)<30?' (limited shooting record)':''}`).join('; ') : 'Three-point percentages are unavailable for the five players on court.';
  const exposure=[...active].sort((a,b)=>(g.players[b.id].fouls*15+g.players[b.id].fatigue)-(g.players[a.id].fouls*15+g.players[a.id].fatigue)).slice(0,2);
  const riskLine=exposure.map(p=>`${p.name}: ${g.players[p.id].fouls} fouls, ${Math.round(g.players[p.id].fatigue)}/100 fatigue`).join('; ');
  const leader=[...active].sort((a,b)=>number(b.stats?.apg,-1)-number(a.stats?.apg,-1))[0];
  const interior=[...active].filter(big).sort((a,b)=>number(b.stats?.rpg,0)-number(a.stats?.rpg,0))[0];
  const passingLine=leader&&Number.isFinite(leader.stats?.apg)?`${leader.name} averaged ${displayNumber(leader.stats.apg)} assists in ${leader.season}.`:'Season assist numbers are unavailable for the five players on court.';
  const interiorLine=interior?`${interior.name}: ${displayNumber(interior.stats?.ppg)} points and ${displayNumber(interior.stats?.rpg)} rebounds/game; ${Number.isFinite(interior.stats?.fgPct)?`${displayNumber(interior.stats.fgPct)}% FG on ${displayNumber(interior.stats?.fgAttempts)} season attempts`:'shooting percentage unavailable'}.`:'No primary PF/C is currently on the floor.';
  const bench=run.roster.filter(id=>!g.lineup.includes(id)&&g.players[id].fouls<5).sort((a,b)=>g.players[a].fatigue-g.players[b].fatigue);
  const benchLine=bench.length?bench.slice(0,2).map(id=>`${player(catalog,id).name}: ${Math.round(g.players[id].fatigue)}/100 fatigue, ${g.players[id].fouls} fouls`).join('; '):'No eligible bench player remains.';
  const os=opponent?.stats||{}, known=[],missing=[];
  if(Number.isFinite(os.wins)&&Number.isFinite(os.losses))known.push(`${os.wins}-${os.losses} record`);
  if(Number.isFinite(os.threePct))known.push(`${displayNumber(os.threePct)}% team three-point shooting`);else missing.push('team three-point shooting');
  if(Number.isFinite(os.adjustedMargin))known.push(`${displayNumber(os.adjustedMargin)} adjusted efficiency margin`);
  else if(Number.isFinite(os.ppg)&&Number.isFinite(os.oppPpg))known.push(`${displayNumber(os.ppg)} scored / ${displayNumber(os.oppPpg)} allowed per game`);
  else missing.push('efficiency/scoring margin');
  if(Number.isFinite(os.pace))known.push(`${displayNumber(os.pace)} pace`);else missing.push('pace');
  const opponentLine=`${opponent?.name||'Opponent'} this season: ${known.join('; ')||'detailed season numbers are unavailable'}.${missing.length?` Unavailable: ${missing.join(', ')}.`:''}`;
  const scoreLine=`${run.teamName} ${g.score.user}, ${opponent?.name||'opponent'} ${g.score.opponent}; ${displayClock(g.clock)} left in ${g.period===1?'the first half':g.period===2?'the second half':`overtime ${g.period-2}`}.`;
  const gameLine=`This game: ${own.turnovers} turnovers, ${own.assists} assists, ${own.rebounds} rebounds. Opponent: ${other.turnovers} turnovers, ${other.assists} assists, ${other.rebounds} rebounds.`;
  return {active,opponent,shootingLine,riskLine,passingLine,interiorLine,benchLine,opponentLine,scoreLine,gameLine,
    tired:active.some(p=>g.players[p.id].fatigue>=55),trouble:active.some(p=>g.players[p.id].fouls>=(g.period===1?2:4))};
}
function choices(type,run,catalog,context) {
  const g=run.game,c=context||contextEvidence(run,catalog),own=g.teamStats.user,other=g.teamStats.opponent;
  const all={
    'move-ball':{label:'Move the ball',detail:'Seek an assisted shot at a balanced pace.',evidence:[c.passingLine,`${own.turnovers} turnovers and ${own.assists} assists in this game.`],rationale:'Work through your passers to create a cleaner look. Ball handling still matters when the defense pressures the pass.'},
    'attack-inside':{label:'Attack inside',detail:'Seek more two-point attempts, with fewer threes.',evidence:[c.interiorLine,`Rebounds in this game: your team ${own.rebounds}, opponent ${other.rebounds}.`],rationale:'Give your bigs more touches near the basket. You trade some three-point opportunities for interior attempts.'},
    'press':{label:'Press the ball',detail:'Seek turnovers while accepting extra fouls and fatigue.',evidence:[`Opponent turnovers in this game: ${other.turnovers}.`,c.riskLine],rationale:'Pressure seeks a turnover but adds foul and fatigue risk and may leave open shots.',risk:c.tired||c.trouble?'Your active lineup is tired or in foul trouble. Pressure compounds that exposure.':'Pressure costs energy and can concede fouls or open shots.'},
    'control-tempo':{label:type==='endgame'?'Use the clock':'Settle the offense',detail:'Slow the pace and protect the ball.',evidence:[c.scoreLine,`Your team has ${own.turnovers} turnovers in this game.`],rationale:'Longer possessions reduce remaining chances for both teams. This is more useful when protecting a lead than when chasing one.',risk:g.score.user<g.score.opponent?'You are trailing; spending more clock leaves fewer chances to recover.':undefined},
    'fresh-legs':{label:'Use fresh legs',detail:'Favor eligible players with lower fatigue and foul exposure.',evidence:[`On court: ${c.riskLine}.`,`Bench: ${c.benchLine}.`],rationale:'Use less tired players with fewer fouls. Keep that group together for two minutes unless someone fouls out.'},
    'push':{label:'Score quickly',detail:'Create more possessions, accepting extra turnover risk.',evidence:[c.scoreLine,`${own.turnovers} turnovers so far; opponent has ${g.timeouts.opponent} timeouts.`],rationale:'A shorter possession preserves comeback time, but a hurried attack can turn the ball over.'},
    'quick-three':{label:'Create a three',detail:'Look for a quick perimeter attempt.',evidence:[c.shootingLine,c.scoreLine],rationale:'A quick three can close the gap, but a miss leaves fewer chances. A limited shooting record is less reliable.'},
    'protect-paint':{label:'Protect the paint',detail:'Reduce interior shot quality while allowing better outside looks.',evidence:[`Opponent two-pointers this game: ${other.fieldGoalsMade-other.threesMade}/${other.fieldGoalsAttempted-other.threesAttempted}.`,c.opponentLine],rationale:'Pack the paint to contest twos. That leaves more room for outside shots.',risk:!Number.isFinite(c.opponent?.stats?.threePct)?'The opponent’s season three-point percentage is unavailable. Leaving shooters open carries uncertainty.':undefined},
    'protect-perimeter':{label:'Stay with shooters',detail:'Reduce perimeter quality while accepting more interior space.',evidence:[`Opponent threes this game: ${other.threesMade}/${other.threesAttempted}.`,c.opponentLine],rationale:'Stay close to the perimeter threats. Be ready to give up more space near the basket.',risk:'Staying outside makes two-point attempts more dangerous.'},
    'intentional-foul':{label:'Extend the game',detail:'Foul to stop the next opponent possession quickly.',evidence:[c.scoreLine,`Your team has ${g.teamFouls.user} fouls this half. Opponent free throws this game: ${other.freeThrowsMade}/${other.freeThrowsAttempted}.`],rationale:'This preserves time at the cost of bonus free throws once your team reaches seven fouls.',risk:'Made free throws can increase the deficit.'}
  };
  let ids;
  if(type==='endgame') {
    if(g.score.user>=g.score.opponent) ids=['control-tempo','move-ball',other.threesMade>=3||number(c.opponent?.stats?.threePct,0)>=35?'protect-perimeter':c.tired||c.trouble?'fresh-legs':'protect-paint'];
    else ids=['push','quick-three',g.clock<=45?'intentional-foul':c.tired||c.trouble?'fresh-legs':'press'];
  } else if(type==='fatigue'||type==='foul-trouble') ids=['fresh-legs','control-tempo','move-ball'];
  else {
    ids=['move-ball',other.threesMade>=4&&other.threesMade/Math.max(1,other.threesAttempted)>=0.4?'protect-perimeter':'attack-inside',c.tired||c.trouble?'fresh-legs':own.turnovers>=4||(g.score.user-g.score.opponent>=6&&g.period>=2)?'control-tempo':'press'];
  }
  return ids.map(id=>({id,...Object.fromEntries(Object.entries(all[id]).filter(([,value])=>value!==undefined))}));
}
function pause(run,catalog,type,title,description) {
  const g=run.game,c=contextEvidence(run,catalog);g.status='moment';
  g.lastPauseElapsed=g.elapsed;
  g.moment={type,title,description,evidence:[c.scoreLine,c.gameLine,c.riskLine,c.shootingLine,c.opponentLine],choices:choices(type,run,catalog,c)};
  return run;
}

function simulateToMoment(run, catalog) {
  const g = run.game;
  for (let step = 0; step < 3000; step++) {
    if (g.status === 'final') return run;
    if (g.clock <= 0) {
      if (g.period === 1) {
        g.stage = 2;
        return pause(run,catalog,'halftime','Make your halftime adjustment',`The score is ${g.score.user}–${g.score.opponent}. Review the first-half numbers and player energy before choosing your next approach.`);
      }
      if (g.score.user !== g.score.opponent) {finishGame(run, catalog); return run;}
      g.period++; g.clock = 300; g.stage = 5;
      // Second-half fouls carry into overtime in this game ruleset.
      g.timeouts.user++; g.timeouts.opponent++;
      for (const p of Object.values(g.players)) p.fatigue = Math.max(0, p.fatigue - 8);
      append(g, `Tied ${g.score.user}–${g.score.opponent}. Five-minute overtime ${g.period - 2}.`);
      return pause(run,catalog,'overtime','Five more minutes','The tie is settled by another timed period of possessions. Each team receives one extra timeout.');
    }
    const margin=Math.abs(g.score.user-g.score.opponent);
    const foulRisk=g.lineup.filter(id=>g.players[id].fouls>=(g.period===1?2:4));
    const fatigueRisk=g.lineup.filter(id=>g.players[id].fatigue>=60);
    const swing=g.scoringRun.points>=8&&margin<=16;
    const turnovers=g.teamStats.user.turnovers>=(g.period===1?5:10)&&margin<=12;
    if(g.period===1&&g.stage===0&&g.elapsed>=120&&g.clock>120&&(foulRisk.length||swing||turnovers)) {
      g.stage = 1;
      const trouble=foulRisk.length>0;
      const reason=trouble?`${foulRisk.map(id=>`${player(catalog,id).name} has ${g.players[id].fouls} fouls`).join('; ')}. Your active rotation is exposed.`:swing?`${g.scoringRun.side==='opponent'?'Your opponent':'Your team'} has scored the last ${g.scoringRun.points} points. The margin is ${margin}.`:`Your team has committed ${g.teamStats.user.turnovers} turnovers. The margin is ${margin}.`;
      return pause(run,catalog,trouble?'foul-trouble':'momentum',trouble?'An early foul decision':'Respond to the swing',reason);
    }
    const competitiveStretch=margin<=Math.max(8,Math.ceil(g.clock/60)*2);
    if(g.period===2&&g.stage===2&&g.clock>180&&g.clock<=900&&competitiveStretch&&(g.elapsed-(g.lastPauseElapsed||0)>=120)&&(foulRisk.length||fatigueRisk.length||swing||turnovers)) {
      g.stage = 3;
      const trouble=foulRisk.length>0,tired=fatigueRisk.length>0;
      const reason=trouble?`${foulRisk.map(id=>`${player(catalog,id).name}: ${g.players[id].fouls} fouls`).join('; ')}. Decide who should close the game.`:tired?`${fatigueRisk.map(id=>`${player(catalog,id).name}: ${Math.round(g.players[id].fatigue)}/100 fatigue`).join('; ')}. Tired legs make clean shots harder.`:swing?`${g.scoringRun.side==='opponent'?'Your opponent':'Your team'} has scored ${g.scoringRun.points} unanswered points with a ${margin}-point margin.`:`Your team has ${g.teamStats.user.turnovers} turnovers in a ${margin}-point game.`;
      return pause(run,catalog,trouble?'foul-trouble':tired?'fatigue':'momentum',trouble?'Protect your closing lineup':tired?'Manage player energy':'Shape the final stretch',reason);
    }
    const closeLate=margin<=(g.clock>60?8:g.clock>20?6:3);
    if(g.period===2&&g.stage>=2&&g.stage<=3&&g.clock<=120&&closeLate) {
      g.stage = 4;
      return pause(run,catalog,'endgame','Every possession matters',`${displayClock(g.clock)} remains in a ${margin}-point game. Match the pace and shot choice to the score and the players on court.`);
    }
    possession(run, catalog);
  }
  throw new Error('Simulation exceeded its possession limit. Your saved run has not been changed.');
}

const effectText = {
  'move-ball': 'Balanced ball movement improves assisted shot quality. The outcome still depends on shot results.',
  'attack-inside': 'The offense seeks more interior attempts, with a two-point quality boost and fewer threes.',
  'control-tempo': 'Longer possessions reduce turnover risk and the number of remaining scoring chances.',
  press: 'Ball pressure increases opponent turnover chances, at the cost of extra fouls, fatigue and open shots.',
  'protect-paint': 'Interior defense lowers two-point quality while conceding more accurate perimeter looks.',
  'protect-perimeter': 'Perimeter defense lowers three-point quality while conceding more dangerous interior attempts.',
  'fresh-legs': 'Five eligible players are selected by current fatigue and foul exposure for the next two minutes.',
  push: 'Your offense plays faster, creating additional chances and accepting more turnover risk.',
  'quick-three': 'Your offense uses a quick possession to seek a three-point attempt.',
  'intentional-foul': 'Your defense fouls when trailing late. Bonus free throws can extend the deficit.'
};

export function act(run, action, catalog) {
  checkCatalog(run, catalog);
  if (run.game?.status === 'final') return copy(run);
  if (run.phase !== 'playing' || !run.game?.moment) throw new Error('There is no active coaching decision.');
  const next = copy(run), g = next.game;
  if (action.type === 'timeout') {
    if (g.timeouts.user <= 0) throw new Error('You have no timeouts remaining.');
    g.timeouts.user--; for (const p of Object.values(g.players)) p.fatigue = Math.max(0, p.fatigue - 10);
    g.lastConsequence = 'Timeout taken. Players recover 10 fatigue points; the game clock does not change.';
    append(g, g.lastConsequence);
    return pause(next,catalog,g.moment.type,g.moment.title,'Timeout taken. Check player energy and the score before making the call.');
  }
  if (action.type === 'substitute') {
    if (!g.lineup.includes(action.outId) || !next.roster.includes(action.inId) || g.lineup.includes(action.inId)) throw new Error('Choose one player on court and one player on the bench.');
    if (g.players[action.inId].fouls >= 5) throw new Error('A fouled-out player cannot return.');
    g.lineup[g.lineup.indexOf(action.outId)] = action.inId; g.manualUntil = g.elapsed + 120;
    g.lastConsequence = `${player(catalog, action.inId).name} replaces ${player(catalog, action.outId).name}. Your change is held for the next two minutes unless a player fouls out.`;
    append(g, g.lastConsequence);
    return pause(next,catalog,g.moment.type,g.moment.title,'Lineup updated. Make the call with your new five on the floor.');
  }
  if (!['decision', 'continue'].includes(action.type)) throw new Error('Choose an available coaching action.');
  const choice = action.type === 'continue' ? g.moment.choices[0].id : action.choice;
  const selectedChoice=g.moment.choices.find(c=>c.id===choice);
  if (!selectedChoice) throw new Error('That choice is not available at this moment.');
  g.decisions.push({choice, type: g.moment.type, period: g.period, clock: g.clock, score: {...g.score}, explanation: effectText[choice],evidence:copy(selectedChoice.evidence||[]),rationale:selectedChoice.rationale||''});
  g.lastConsequence = effectText[choice]; append(g, g.lastConsequence);
  if (choice === 'move-ball') {g.tactic = 'balanced'; g.defense = 'balanced';}
  if (choice === 'attack-inside') {g.tactic = 'inside'; g.defense = 'balanced';}
  if (choice === 'control-tempo') {g.tactic = 'control'; g.defense = 'balanced';}
  if (choice === 'press') {g.defense = 'press'; g.tactic = 'balanced';}
  if (choice === 'protect-paint') g.defense = 'paint';
  if (choice === 'protect-perimeter') g.defense = 'perimeter';
  if (choice === 'push' || choice === 'quick-three') {g.tactic = choice; g.defense = 'balanced';}
  if (choice === 'intentional-foul') {g.defense = 'foul'; g.tactic = 'push';}
  if (choice === 'fresh-legs') {
    const exposure=id=>g.players[id].fatigue+Math.max(0,g.players[id].fouls-2)*20;
    g.lineup = next.roster.filter(id => g.players[id].fouls < 5).sort((a, b) => exposure(a)-exposure(b) || a.localeCompare(b)).slice(0, 5);
    g.manualUntil = g.elapsed + 120; g.defense = 'balanced';
  }
  if (g.moment.type === 'halftime') {
    g.period = 2; g.clock = 1200; g.teamFouls = {user: 0, opponent: 0};
    for (const p of Object.values(g.players)) p.fatigue = Math.max(0, p.fatigue - 25);
    rotate(next, catalog);
  }
  g.moment = null;
  return simulateToMoment(next, catalog);
}

function genericGame(run, a, b) {
  let scoreA = 0, scoreB = 0;
  function segment(possessions) {
    for (let i = 0; i < possessions; i++) for (const side of ['a', 'b']) {
      const diff = (side === 'a' ? a.strength - b.strength : b.strength - a.strength) * 0.0029;
      if (random(run) < clamp(0.15 - diff * 0.35, 0.07, 0.24)) continue;
      const three = random(run) < 0.36;
      const offense = side === 'a' ? a : b;
      let points = random(run) < clamp((three ? number(offense.stats?.threePct, 33) / 100 : 0.49) + diff, three ? 0.16 : 0.24, three ? 0.58 : 0.73) ? three ? 3 : 2 : 0;
      if (random(run) < 0.14) points += Number(random(run) < 0.72) + Number(random(run) < 0.72);
      if (side === 'a') scoreA += points; else scoreB += points;
    }
  }
  const pace = Math.round(clamp((number(a.stats?.pace, 68) + number(b.stats?.pace, 68)) / 2, 54, 84));
  segment(pace); let periods = 2;
  while (scoreA === scoreB) {segment(9); periods++;}
  return {scoreA, scoreB, winner: scoreA > scoreB ? a.id : b.id, periods};
}
function fillNextRound(run, round) {
  if (round >= 5) return;
  run.bracket.rounds[round + 1].forEach((m, i) => {m.teamA = run.bracket.rounds[round][i * 2].winner; m.teamB = run.bracket.rounds[round][i * 2 + 1].winner;});
}
function finishGame(run, catalog, forcedWinner) {
  const g = run.game;
  if (g.status === 'final') return;
  g.status = 'final'; g.moment = null;
  g.winner = forcedWinner || (g.score.user > g.score.opponent ? 'user' : 'opponent');
  const match = run.bracket.rounds[g.round].find(m => m.id === g.matchId), won = g.winner === 'user';
  match.scoreA = match.teamA === 'user' ? g.score.user : g.score.opponent;
  match.scoreB = match.teamB === 'user' ? g.score.user : g.score.opponent;
  match.winner = won ? 'user' : g.opponentId; match.periods = g.period;
  for (const m of run.bracket.rounds[g.round]) if (!m.winner) {
    const a = run.bracket.entrants.find(t => t.id === m.teamA), b = run.bracket.entrants.find(t => t.id === m.teamB);
    Object.assign(m, genericGame(run, a, b));
  }
  fillNextRound(run, g.round);
  const opponent = run.bracket.entrants.find(t => t.id === g.opponentId);
  if (!run.results.some(r => r.id === match.id)) run.results.push({id: match.id, round: g.round, roundName: ROUND_NAMES[g.round], opponentId: opponent.id, opponentName: opponent.name,
    score: {...g.score}, won, periods: g.period, decisions: copy(g.decisions), boxScore: copy(g.players), teamStats: copy(g.teamStats), forfeit: g.forfeit || null});
  run.wins = run.results.filter(r => r.won).length;
  run.phase = won ? g.round === 5 ? 'champion' : 'result' : 'eliminated';
  append(g, `${won ? 'Win' : 'Loss'}: ${run.teamName} ${g.score.user}, ${opponent.name} ${g.score.opponent}${g.period > 2 ? ` (${g.period - 2} OT)` : ''}.`);
  if (!won) {
    // Finish the entire field so the bracket has a coherent champion even after elimination.
    for (let round = g.round + 1; round < 6; round++) {
      for (const m of run.bracket.rounds[round]) if (!m.winner) Object.assign(m, genericGame(run, run.bracket.entrants.find(t => t.id === m.teamA), run.bracket.entrants.find(t => t.id === m.teamB)));
      fillNextRound(run, round);
    }
  }
}

export function advanceTournament(run, catalog) {
  checkCatalog(run, catalog);
  if (['seeded', 'champion', 'eliminated'].includes(run.phase)) return copy(run);
  if (run.phase !== 'result' || run.game?.winner !== 'user') throw new Error('Finish and win your current game before advancing.');
  const next = copy(run); next.game = null; next.phase = 'seeded';
  if (!nextOpponent(next)) throw new Error('The next-round bracket is incomplete.');
  return next;
}
