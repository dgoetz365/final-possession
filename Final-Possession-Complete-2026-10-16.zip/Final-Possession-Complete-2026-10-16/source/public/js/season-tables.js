// Manually transcribed factual observations from official final all-games tables.
// No TEAM aggregate, conference-only row, or zero-appearance roster entry is a player.
// Columns: id stem | name | jersey | game roles | GP GS MIN FGM FGA 3PM 3PA FTM FTA OREB DREB AST TO BLK STL PTS
// Roles are original game eligibility, not a claim about an official position.
export const SEASON_TABLES = [
  {school:'Duke',season:'2015-16',sourceKey:'duke16',rows:`
allen|Grayson Allen|3|SG|36 35 1317 239 513 90 216 211 252 24 141 127 72 5 47 779
ingram|Brandon Ingram|14|SF,PF|36 34 1246 214 484 80 195 116 170 67 177 71 72 49 40 624
kennard|Luke Kennard|5|SG|36 11 961 141 335 55 172 88 99 35 94 54 28 6 34 425
jefferson|Amile Jefferson|21|PF,C|9 9 273 41 60 0 0 21 38 43 50 13 14 11 7 103
jones|Matt Jones|13|SG,SF|35 35 1113 124 304 76 183 39 53 36 52 80 39 7 36 363
plumlee|Marshall Plumlee|40|C|36 36 1099 106 154 0 0 88 153 119 189 38 39 59 29 300
thornton|Derryck Thornton|12|PG|36 20 935 94 241 27 83 40 58 10 56 93 59 8 27 255
jeter|Chase Jeter|2|PF,C|32 0 254 21 38 0 0 20 37 25 36 4 19 9 3 62
vrankovic|Antonio Vrankovic|30|C|5 0 14 2 2 0 0 0 0 2 5 0 3 1 1 4
obi|Sean Obi|34|PF,C|10 0 27 1 2 0 0 3 6 6 4 0 2 1 0 5
nick-pagliuca|Nick Pagliuca|45|SG|10 0 10 0 1 0 1 0 0 1 3 0 1 0 1 0
besser|Brennan Besser|53|SG,SF|1 0 1 0 1 0 1 0 0 0 0 0 0 0 0 0
`},
  {school:'Duke',season:'2005-06',sourceKey:'duke06',rows:`
redick|JJ Redick|4|SG|36 36 1336 302 643 139 330 221 256 7 64 95 90 2 52 964
shelden-williams|Shelden Williams|23|PF,C|36 36 1198 237 410 2 6 201 270 117 267 39 89 137 60 677
mcroberts|Josh McRoberts|2|PF,C|36 31 883 115 190 5 13 77 116 61 128 53 51 46 41 312
demarcus-nelson|DeMarcus Nelson|21|SG,SF|24 7 517 61 135 25 61 24 37 24 58 29 42 3 20 171
dockery|Sean Dockery|15|PG,SG|36 32 1069 93 200 34 86 36 52 29 79 94 48 4 61 256
paulus|Greg Paulus|3|PG|36 33 1163 72 193 22 70 76 97 16 85 187 118 0 56 242
melchionni|Lee Melchionni|13|SF,PF|36 5 717 64 176 40 125 38 57 27 89 33 26 5 35 206
pocius|Martynas Pocius|5|SG,SF|28 0 172 16 33 5 16 5 8 3 5 13 12 0 8 42
boykin|Jamal Boykin|34|PF|26 0 70 8 17 0 0 9 10 8 12 2 7 4 2 25
boateng|Eric Boateng|45|C|20 0 50 6 7 0 0 2 2 4 8 1 5 0 1 14
perkins|Ross Perkins|40|SG,SF|6 0 12 1 2 1 1 0 0 0 1 0 0 0 0 3
patrick-johnson|Patrick Johnson|51|C,PF|13 0 23 3 3 0 0 0 0 1 3 0 2 1 0 6
jordan-davidson|Jordan Davidson|12|PG|10 0 11 1 1 1 1 0 0 0 1 0 1 0 1 3
joe-pagliuca|Joe Pagliuca|30|SG|1 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0
`},
  {school:'Davidson',season:'2007-08',sourceKey:'davidson',rows:`
curry|Stephen Curry|30|PG|36 36 1193 317 656 162 369 135 151 28 137 104 93 14 73 931
richards|Jason Richards|2|PG|36 36 1265 153 371 58 182 93 125 17 93 293 104 4 50 457
sander|Thomas Sander|15|PF,C|35 35 820 111 191 7 27 33 65 63 105 51 47 12 27 262
meno|Boris Meno|5|PF,C|36 12 731 109 221 1 18 30 45 65 130 14 58 28 25 249
lovedale|Andrew Lovedale|41|PF,C|36 25 778 106 196 0 0 34 52 66 128 18 26 30 25 246
barr|Bryant Barr|24|SG|36 0 444 62 155 54 128 11 17 9 29 17 11 2 8 189
archambault|Will Archambault|22|SG,SF|36 2 499 67 173 26 92 20 30 22 41 28 23 5 8 180
paulhus-gosselin|Max Paulhus Gosselin|14|SG,SF|34 34 794 45 124 7 58 21 31 42 82 49 21 11 48 118
rossiter|Steve Rossiter|23|SF,PF|36 0 484 41 68 0 1 25 39 41 78 27 21 8 21 107
mckillop|Brendan McKillop|1|PG,SG|19 0 93 13 21 10 18 6 6 2 5 7 6 0 1 42
bond|Aaron Bond|4|SG,SF|6 0 14 2 6 2 4 0 0 1 4 2 2 0 1 6
civi|Can Civi|12|PG|11 0 28 3 5 1 3 0 0 1 1 4 4 0 1 7
nelms|Dan Nelms|35|C,PF|17 0 54 3 12 0 1 3 12 4 4 1 3 0 2 9
schmitt|Mike Schmitt|20|SG|3 0 3 0 0 0 0 0 0 0 1 0 1 0 0 0
`},
  {school:'Texas',season:'2006-07',sourceKey:'texas',rows:`
durant|Kevin Durant|35|SF|35 35 1255 306 647 82 203 209 256 106 284 46 99 67 66 903
abrams|A.J. Abrams|3|SG,PG|35 35 1242 175 441 120 284 73 79 25 61 52 48 4 46 543
augustin|D.J. Augustin|14|PG|35 35 1245 154 343 45 102 150 179 21 78 233 115 3 53 503
justin-mason|Justin Mason|24|SG,SF|35 31 1012 98 227 35 88 35 60 47 79 64 46 4 22 266
damion-james|Damion James|5|SF,PF|35 35 908 99 201 1 11 66 111 89 164 32 52 42 20 265
atchley|Connor Atchley|32|PF,C|35 4 626 47 105 11 36 30 57 60 76 21 28 50 13 135
pittman|Dexter Pittman|34|C|29 0 155 29 48 0 0 16 34 28 24 2 11 10 5 74
matt-hill|Matt Hill|21|PF,C|23 0 262 15 35 0 0 20 34 28 29 2 6 15 3 50
winder|Craig Winder|30|SG|30 0 222 24 50 3 17 14 19 23 26 16 7 2 21 65
jd-lewis|J.D. Lewis|4|SG|27 0 204 12 49 11 45 12 18 8 10 10 13 0 8 47
harrison-smith|Harrison Smith|23|SG,SF|8 0 45 4 12 0 6 0 1 5 2 1 3 0 4 8
mooney|Ian Mooney|22|SF,PF|6 0 24 0 6 0 0 1 2 2 4 0 1 0 1 1
`},
  {school:'Villanova',season:'2017-18',sourceKey:'nova',rows:`
brunson|Jalen Brunson|1|PG|40 40 1272 270 518 86 211 130 162 12 110 184 71 1 37 756
bridges|Mikal Bridges|25|SG,SF|40 40 1285 244 475 104 239 114 134 54 158 77 54 43 61 706
divincenzo|Donte DiVincenzo|10|SG,PG|40 10 1170 188 391 85 212 76 107 46 144 139 79 8 42 537
spellman|Omari Spellman|14|C,PF|40 39 1125 160 336 65 150 49 70 90 231 30 40 59 26 434
paschall|Eric Paschall|4|PF,SF|38 38 1133 144 270 36 101 78 96 70 130 83 64 24 35 402
booth|Phil Booth|5|PG,SG|33 31 903 108 245 55 145 60 75 12 92 95 45 6 27 331
gillespie|Collin Gillespie|2|PG|32 1 460 42 93 28 71 24 30 4 38 34 14 2 19 136
cosby-roundtree|Dhamir Cosby-Roundtree|21|PF,C|40 1 453 53 68 0 0 18 28 38 57 3 19 15 10 124
samuels|Jermaine Samuels|23|SF,PF|25 0 153 7 28 3 16 10 16 7 23 7 12 3 1 27
grace|Denny Grace|40|SG|15 0 19 1 3 1 3 0 0 1 4 0 2 0 0 3
matt-kennedy|Matt Kennedy|35|SG|12 0 16 1 1 0 0 0 0 0 3 0 0 1 0 2
delaney|Tim Delaney|34|PF,C|22 0 49 1 6 1 5 0 0 2 3 3 1 0 0 3
leibig|Tom Leibig|24|PG,SG|15 0 22 1 5 0 4 0 0 0 3 0 1 0 1 2
heck|Peyton Heck|22|SG|11 0 15 0 1 0 1 0 0 1 1 0 0 0 0 0
`},
  {school:'Purdue',season:'2023-24',sourceKey:'purdue24',rows:`
edey|Zach Edey|15|C|39 39 1248:25 336 539 1 2 310 436 181 293 79 90 84 11 983
braden-smith|Braden Smith|3|PG|39 39 1327:18 173 392 56 130 66 83 29 197 292 104 5 62 468
lance-jones|Lance Jones|55|PG,SG|39 39 1115:36 154 373 80 224 69 93 18 89 75 58 8 50 457
loyer|Fletcher Loyer|2|SG|39 39 1085:38 126 303 63 142 87 101 10 72 75 45 1 30 402
gillis|Mason Gillis|0|SF,PF|39 0 822:50 79 165 58 124 37 43 47 106 66 32 1 9 253
kaufman-renn|Trey Kaufman-Renn|4|PF,C|39 39 662:51 96 188 8 24 49 88 60 96 37 30 14 10 249
colvin|Myles Colvin|5|SG,SF|31 0 266:01 37 84 24 58 5 10 5 22 11 13 4 7 103
heide|Camden Heide|23|SF,PF|39 0 483:41 49 85 18 40 11 15 23 52 14 10 9 8 127
berg|Will Berg|44|C|14 0 52:17 15 20 0 0 7 15 11 15 1 6 0 0 37
caleb-furst|Caleb Furst|1|PF,C|36 0 324:30 26 59 3 11 23 34 29 59 20 17 6 8 78
waddell|Brian Waddell|11|SF|14 0 56:43 6 14 1 6 3 7 2 6 3 1 1 0 16
sam-king|Sam King|24|SF,PF|6 0 10:32 1 4 0 2 4 6 2 2 1 1 2 1 6
morton|Ethan Morton|25|PG,SG|37 0 370:16 8 34 4 19 4 7 6 26 42 10 7 15 24
barrett|Carson Barrett|34|SG|13 0 23:07 2 4 2 4 0 0 1 5 2 2 0 0 6
chase-martin|Chase Martin|22|PG,SG|13 0 23:07 1 8 0 2 0 0 1 3 2 3 0 1 2
josh-furst|Josh Furst|20|PF,C|1 0 1:05 0 0 0 0 0 0 0 1 0 0 0 0 0
rayl|Jace Rayl|32|SG|1 0 1:05 0 0 0 0 0 0 0 0 0 0 0 0 0
`},
  {school:'Purdue',season:'2005-06',sourceKey:'purdue06',rows:`
hartley|Chris Hartley|3|PG|28 14 515 15 49 8 37 11 12 8 32 49 17 1 9 49
lutz|Chris Lutz|4|SG|28 24 856 87 233 53 152 30 39 7 56 47 71 5 17 257
dillon|Bryant Dillon|5|PG,SG|28 26 953 76 154 19 46 22 34 18 81 84 73 9 22 193
riddell|Bobby Riddell|10|PG,SG|20 0 134 13 29 11 24 6 6 1 8 10 15 0 4 43
spates|Korey Spates|11|PG|15 3 381 53 139 14 38 31 43 9 29 26 50 1 10 151
landry|Carl Landry|14|PF,C|5 4 123 24 43 2 6 26 31 9 17 5 17 2 4 76
marcus-green|Marcus Green|20|SG,SF|28 13 539 57 136 14 63 27 31 25 46 25 52 10 19 155
marcus-white|Marcus White|23|PF|20 5 383 68 145 0 0 66 92 36 43 20 54 12 14 202
pruitt|Dwayne Pruitt|24|SG,SF|2 0 2 1 1 0 0 0 0 1 1 0 0 0 0 2
minnoy|Nate Minnoy|31|SF,PF|13 12 324 56 111 6 20 14 32 19 47 31 36 3 12 132
carroll|Matt Carroll|32|PF,C|24 0 156 12 16 0 1 1 1 9 20 2 8 1 4 25
ware|Gary Ware|33|PF,C|26 13 448 82 146 0 0 27 52 30 56 18 36 19 9 191
kiefer|Matt Kiefer|42|PF,C|28 26 811 125 282 26 78 59 95 81 128 49 55 30 27 335
`},
];

export function parseSeasonTables() {
  const rows=[];
  for(const group of SEASON_TABLES) {
    for(const line of group.rows.trim().split('\n')) {
      const [stem,name,jersey,eligibility,observations]=line.split('|');
      const values=observations.split(' ');
      if(values.length!==16)throw new Error(`Wrong column count: ${stem}`);
      const [games,starts,minuteText,...counts]=values;
      const [fgMade,fgAttempts,threeMade,threeAttempts,ftMade,ftAttempts,offRebounds,defRebounds,assists,turnovers,blocks,steals,points]=counts.map(Number);
      const [minutes,seconds=0]=minuteText.split(':').map(Number);
      rows.push({stem,name,number:Number(jersey),roles:eligibility.split(','),school:group.school,season:group.season,year:Number(group.season.slice(0,4))+1,sourceKey:group.sourceKey,
        totals:{games:Number(games),starts:Number(starts),minutes:minutes+seconds/60,fgMade,fgAttempts,threeMade,threeAttempts,ftMade,ftAttempts,offRebounds,defRebounds,assists,turnovers,blocks,steals,points}});
    }
  }
  return rows;
}
