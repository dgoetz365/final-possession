export const SAVE_KEY = 'final-possession-run-v1';
export const HISTORY_KEY = 'final-possession-history-v1';
export const SETTINGS_KEY = 'final-possession-settings-v1';
export const MAX_SAVE_BYTES = 2000000;
const PHASES = ['draft','lineup','seeded','playing','result','champion','eliminated'];
const clone = value => JSON.parse(JSON.stringify(value));

export function validateSave(value, modelVersion) {
  if (!value || value.format !== 'final-possession' || value.version !== 1 || !value.run || !value.catalog) throw new Error('This file is not a compatible Final Possession save.');
  const {run, catalog} = value;
  if (run.schema !== 1 || run.modelVersion !== modelVersion || !PHASES.includes(run.phase)) throw new Error('This run uses an older game model. Start a new draft to use this version.');
  if (!Array.isArray(catalog.players) || !Array.isArray(catalog.teams) || catalog.players.length > 1024 || catalog.players.length < 12 || catalog.teams.length !== 63 || catalog.version !== run.catalogVersion) throw new Error('The saved historical snapshot is incomplete.');
  const ids = new Set(catalog.players.map(p=>p.id));
  if (ids.size !== catalog.players.length || !Array.isArray(run.roster) || run.roster.length > 12 || new Set(run.roster).size !== run.roster.length || run.roster.some(id=>!ids.has(id))) throw new Error('The saved roster is invalid.');
  if (!Number.isFinite(run.rng) || !Number.isFinite(run.seed) || !Number.isInteger(run.wins) || run.wins < 0 || run.wins > 6 || typeof run.id !== 'string' || run.id.length > 150) throw new Error('The saved run state is invalid.');
  if (typeof run.teamName !== 'string' || run.teamName.length > 40) throw new Error('The saved team name is invalid.');
  if (!Array.isArray(run.starters) || !run.minutes || !Array.isArray(run.results) || run.results.length > 6) throw new Error('The saved rotation or results are invalid.');
  if (!run.draft || !Array.isArray(run.draft.offers) || run.draft.offers.some(id=>!ids.has(id)||run.roster.includes(id)) || !Number.isInteger(run.draft.rerollsLeft) || run.draft.rerollsLeft<0 || run.draft.rerollsLeft>2) throw new Error('The saved draft is invalid.');
  if (run.phase!=='draft' && run.roster.length!==12) throw new Error('The saved run is missing its completed roster.');
  if (['seeded','playing','result','champion','eliminated'].includes(run.phase) && !run.bracket) throw new Error('The saved run is missing its tournament.');
  for (const p of catalog.players) {
    if (typeof p.id !== 'string' || typeof p.name !== 'string' || typeof p.school !== 'string' || !Array.isArray(p.roles) || !p.roles.length || p.roles.some(role=>!['PG','SG','SF','PF','C'].includes(role)) || !Number.isFinite(p.cost) || p.cost < 1 || !p.stats || !/^https:\/\//.test(p.source?.url||'')) throw new Error('A saved player record is invalid.');
    for (const stat of Object.values(p.stats)) if (stat !== null && !Number.isFinite(stat)) throw new Error('A saved statistic is invalid.');
  }
  if (run.bracket && (run.bracket.entrants?.length !== 64 || run.bracket.rounds?.length !== 6 || run.bracket.rounds.some((round,i)=>round.length !== 32 / 2 ** i))) throw new Error('The saved tournament is invalid.');
  if (run.game && (!run.game.score || !Number.isFinite(run.game.score.user) || !Number.isFinite(run.game.score.opponent) || !Array.isArray(run.game.lineup) || !run.game.players || !Array.isArray(run.game.log) || run.game.log.length > 10000)) throw new Error('The saved game is invalid.');
  return clone(value);
}

export function parseSave(text, modelVersion) {
  if (typeof text !== 'string' || text.length > MAX_SAVE_BYTES) throw new Error('This save file is too large.');
  let data;
  try { data = JSON.parse(text); } catch { throw new Error('The save file is not valid JSON.'); }
  return validateSave(data, modelVersion);
}

export function saveRun(storage, run, catalog) {
  const text = JSON.stringify({format:'final-possession',version:1,run,catalog});
  if (text.length > MAX_SAVE_BYTES) throw new Error('This run is too large for automatic saving. Export your run to keep it.');
  try { storage.setItem(SAVE_KEY,text); } catch { throw new Error('Automatic saving is unavailable. Export your run before closing this tab.'); }
}

export function loadRun(storage, modelVersion) {
  try {
    const text=storage.getItem(SAVE_KEY);
    if (text) return {saved:parseSave(text,modelVersion),notice:null};
    const old = storage.getItem('campus-legends-run-v6');
    return {saved:null,notice:old ? 'Your earlier five-player game uses a different format. It is preserved; start a new Final Possession draft.' : null};
  } catch (error) { return {saved:null,notice:error.message || 'The saved run could not be read. Start a new draft or import an exported save.'}; }
}

export function readHistory(storage) {
  try { const items=JSON.parse(storage.getItem(HISTORY_KEY)||'[]'); return Array.isArray(items)?items.filter(x=>x&&typeof x.id==='string'&&Number.isInteger(x.wins)&&x.wins>=0&&x.wins<=6).slice(0,40):[]; } catch { return []; }
}

export function recordHistory(storage, run, catalog) {
  const history=readHistory(storage);
  if (!['champion','eliminated'].includes(run.phase) || history.some(x=>x.id===run.id)) return history;
  const entry={id:run.id,teamName:run.teamName,phase:run.phase,status:run.phase,wins:run.wins,losses:run.phase==='eliminated'?1:0,seed:run.bracket?.entrants.find(t=>t.id==='user')?.seed,createdAt:run.createdAt,completedAt:new Date().toISOString(),catalogVersion:run.catalogVersion,modelVersion:run.modelVersion,roster:run.roster.map(id=>{const p=catalog.players.find(p=>p.id===id);return {id,name:p.name,school:p.school,season:p.season};}),results:run.results};
  const updated=[entry,...history].slice(0,40);
  try { storage.setItem(HISTORY_KEY,JSON.stringify(updated)); } catch { throw new Error('Run complete. History could not be saved; export this run to keep it.'); }
  return updated;
}

export function readSettings(storage) {
  const defaults={textSize:'standard',highContrast:false,reducedMotion:false};
  try { const s=JSON.parse(storage.getItem(SETTINGS_KEY)||'{}'); return {...defaults,textSize:['large','larger'].includes(s.textSize)?s.textSize:'standard',highContrast:s.highContrast===true,reducedMotion:s.reducedMotion===true}; } catch { return defaults; }
}
