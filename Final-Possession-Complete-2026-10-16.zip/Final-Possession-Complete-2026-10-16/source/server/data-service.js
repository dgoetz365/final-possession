/** Server-only CBBD adapter. Raw responses never leave private object storage. */
import {expandProviderPool} from './provider-pool.js';
const BASE='https://api.collegebasketballdata.com';
const LATEST='final-possession/catalog/latest.json';
const finite=n=>typeof n==='number' && Number.isFinite(n);
const number=(n,min=0,max=100000)=>finite(n)&&n>=min&&n<=max?n:null;
const perGame=(n,g)=>finite(n)&&g>0?Math.round(n/g*10)/10:null;
const pct=s=>s&&Number.isInteger(s.made)&&Number.isInteger(s.attempted)&&s.attempted>0&&s.made>=0&&s.made<=s.attempted?Math.round(s.made/s.attempted*1000)/10:null;
const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
const aliases={uconn:'connecticut',byu:'brighamyoung',tcu:'texaschristian',uab:'alabamabirmingham',ncstate:'northcarolinastate',fau:'floridaatlantic',mississippistate:'mississippistate',mcneese:'mcneesestate',grambling:'gramblingstate',saintpeters:'saintpeters',charleston:'collegeofcharleston',jjredick:'jjredick'};
const identity=s=>aliases[normalize(s)]||normalize(s);
const uniqueRow=(rows,predicate)=>{const matches=rows.filter(predicate);return matches.length===1?matches[0]:{};};
const validShots=s=>s==null || (Number.isInteger(s.made)&&Number.isInteger(s.attempted)&&s.made>=0&&s.attempted>=s.made);
function consistentTotals(raw) {
  if(['fieldGoals','twoPointFieldGoals','threePointFieldGoals','freeThrows'].some(key=>!validShots(raw[key])))return false;
  const fg=raw.fieldGoals,three=raw.threePointFieldGoals,ft=raw.freeThrows,two=raw.twoPointFieldGoals;
  if(fg&&three&&(three.made>fg.made||three.attempted>fg.attempted))return false;
  if(fg&&three&&two&&(fg.made!==two.made+three.made||fg.attempted!==two.attempted+three.attempted))return false;
  if(fg&&three&&ft&&finite(raw.points)&&raw.points!==2*fg.made+three.made+ft.made)return false;
  const reb=raw.rebounds;
  if(reb&&[reb.total,reb.offensive,reb.defensive].every(finite)&&reb.total!==reb.offensive+reb.defensive)return false;
  return true;
}

export function normalizePlayer(raw,original) {
  if(raw.season!==original.year || identity(raw.team)!==identity(original.school) || identity(raw.name)!==identity(original.name) || !Number.isInteger(raw.games) || raw.games<1 || raw.games>50 || raw.games!==original.stats.games) return null;
  if(!consistentTotals(raw))return null;
  const g=raw.games;
  const stats={games:g,ppg:perGame(number(raw.points),g),rpg:perGame(number(raw.rebounds?.total),g),apg:perGame(number(raw.assists),g),threePct:pct(raw.threePointFieldGoals),threeAttempts:number(raw.threePointFieldGoals?.attempted),ftPct:pct(raw.freeThrows),mpg:perGame(number(raw.minutes),g),spg:perGame(number(raw.steals),g),bpg:perGame(number(raw.blocks),g),fgPct:pct(raw.fieldGoals),tov:perGame(number(raw.turnovers),g),starts:number(raw.starts,0,g),orpg:perGame(number(raw.rebounds?.offensive),g),drpg:perGame(number(raw.rebounds?.defensive),g),fgAttempts:number(raw.fieldGoals?.attempted),ftAttempts:number(raw.freeThrows?.attempted)};
  if(stats.ppg===null || stats.ppg>60 || stats.mpg>60 || Object.keys(stats).some(key=>original.stats[key]!=null&&stats[key]===null))return null;
  const seasonTotals={points:number(raw.points),minutes:number(raw.minutes),rebounds:number(raw.rebounds?.total),assists:number(raw.assists),steals:number(raw.steals),blocks:number(raw.blocks),turnovers:number(raw.turnovers)};
  return {...original,stats,seasonTotals,source:{label:'CollegeBasketballData.com',url:`${BASE}/api/stats`,season:original.year},verified:true};
}

export function normalizeTeam(raw,original,rating) {
  if(raw.season!==2024 || identity(raw.team)!==identity(original.name) || !Number.isInteger(raw.games) || raw.games<1 || raw.games>50 || !Number.isInteger(raw.wins)||!Number.isInteger(raw.losses)|| number(raw.wins,0,50)===null || number(raw.losses,0,50)===null || raw.wins+raw.losses!==raw.games) return null;
  const stats={wins:raw.wins,losses:raw.losses,ppg:perGame(number(raw.teamStats?.points?.total),raw.games),oppPpg:perGame(number(raw.opponentStats?.points?.total),raw.games),pace:number(raw.pace,30,120),threePct:pct(raw.teamStats?.threePointFieldGoals),adjustedMargin:rating?.season===2024&&identity(rating.team)===identity(original.name)?number(rating.netRating,-60,60):null};
  if(stats.ppg>150||stats.oppPpg>150)return null;
  return {...original,stats,bracketSource:original.bracketSource||original.source,ratingSource:stats.adjustedMargin!==null?{label:'CBBD adjusted efficiency',url:`${BASE}/api/ratings`}:null,source:{label:'CollegeBasketballData.com, full 2023-24 season',url:`${BASE}/api/stats`},recordAsOf:'Full season'};
}

async function readObject(bucket,key) {
  if(!bucket)return null;
  try {const item=await bucket.get(key);return item?await item.json():null;} catch {return null;}
}

export async function readCatalog(env,bundled) {
  const current=await readObject(env.BUCKET,LATEST);
  return validCatalog(current,bundled)?current:bundled;
}

function validCatalog(current,bundled){
  if(!current||typeof current.version!=='string'||!Array.isArray(current.teams)||!Array.isArray(current.players)||current.teams.length!==63||current.players.length<bundled.players.length||current.players.length>12000)return false;
  if(!Array.isArray(current.draftGroups)||current.draftGroups.some(g=>!g||typeof g.school!=='string'||typeof g.season!=='string'||!current.players.some(p=>p.school===g.school&&p.season===g.season)))return false;
  if(bundled.players.some(p=>!current.players.some(item=>item?.id===p.id)))return false;
  return ['teams','players'].every(group=>new Set(current[group].map(x=>x?.id)).size===current[group].length&&current[group].every(item=>{
    const original=item&&bundled[group].find(x=>x.id===item.id);
    if(!item||!item.stats||!/^https:\/\//.test(item.source?.url||''))return false;
    if(original&&item.name!==original.name)return false;
    if(group==='teams'&&!original)return false;
    if(group==='players'&&original&&(item.school!==original.school||item.year!==original.year||item.cost!==original.cost||JSON.stringify(item.roles)!==JSON.stringify(original.roles)))return false;
    if(group==='players'&&!original&&(!/^cbbd-\d+-2024$/.test(item.id)||!item.name||!item.school||item.year!==2024||!Array.isArray(item.roles)||!item.roles.length||item.roles.some(r=>!['PG','SG','SF','PF','C'].includes(r))||!finite(item.cost)||item.cost<1||item.cost>22))return false;
    const schema=original?.stats||bundled.players[0].stats;
    if(Object.keys(schema).some(key=>!Object.hasOwn(item.stats,key)||(original&&schema[key]!==null&&item.stats[key]===null)))return false;
    if(Object.entries(item.stats).some(([key,v])=>v!==null&&(!finite(v)||(key!=='adjustedMargin'&&v<0))))return false;
    if(['threePct','ftPct','fgPct'].some(key=>item.stats[key]>100)||item.stats.ppg>150||item.stats.mpg>60)return false;
    if(group==='players'&&(!Number.isInteger(item.stats.games)||item.stats.games<1||item.stats.games>50||(original&&item.stats.games!==original.stats.games)))return false;
    return true;
  }));
}

export async function dataStatus(env,userEmail,bundled) {
  const current=await readCatalog(env,bundled);
  const meta=current.importSummary;
  return {configured:!!env.CBBD_API_KEY,canRefresh:!!userEmail&&typeof env.DATA_ADMIN_EMAIL==='string'&&userEmail.toLowerCase()===env.DATA_ADMIN_EMAIL.toLowerCase(),source:meta?'CBBD + verified historical records':'Verified university and NCAA records',status:meta?'Imported snapshot ready':env.CBBD_API_KEY?'Key configured. Refresh to validate and import.':'API key not configured. Verified historical snapshot active.',updatedAt:meta?.updatedAt||bundled.checkedAt,summary:meta||null};
}

async function requestData(path,key,fetcher) {
  let response;
  try {response=await fetcher(BASE+path,{headers:{Authorization:`Bearer ${key}`,Accept:'application/json'},signal:AbortSignal.timeout(20000)});} catch {throw new Error('The data provider could not be reached. Try again later.');}
  if(!response.ok) throw new Error(`The data provider returned HTTP ${response.status}. Check the API key and endpoint access.`);
  if(Number(response.headers.get('content-length'))>24_000_000)throw new Error('Provider response exceeds the safe import limit.');
  const text=await response.text();if(text.length>24_000_000)throw new Error('Provider response exceeds the safe import limit.');
  let records;try{records=JSON.parse(text);}catch{throw new Error('The provider returned invalid JSON.');}
  if(!Array.isArray(records)||records.length>50000)throw new Error('The provider response has an unexpected format.');
  return records;
}

let inFlight=null;
export async function refreshCatalog(env,bundled,fetcher=fetch) {
  if(!env.CBBD_API_KEY)throw new Error('Add CBBD_API_KEY as a secret in this Site’s runtime settings, then check the connection.');
  if(!env.BUCKET)throw new Error('Private snapshot storage is unavailable.');
  if(inFlight)return inFlight;
  inFlight=importCatalog(env,bundled,fetcher).finally(()=>{inFlight=null;});
  return inFlight;
}

async function importCatalog(env,bundled,fetcher) {
  const previous=await readCatalog(env,bundled);
  const stamp=new Date().toISOString();
  const pathRoot=`final-possession/raw/${stamp.replace(/[:.]/g,'-')}`;
  const rawTeams=await requestData('/stats/team/season?season=2024',env.CBBD_API_KEY,fetcher);
  await env.BUCKET.put(`${pathRoot}/teams.json`,JSON.stringify(rawTeams));
  const rawPlayers=await requestData('/stats/player/season?season=2024',env.CBBD_API_KEY,fetcher);
  await env.BUCKET.put(`${pathRoot}/players-2024.json`,JSON.stringify(rawPlayers));
  let ratings=[],games=[];const warnings=[];
  for(const [label,path] of [['ratings','/ratings/adjusted?season=2024'],['games','/games?season=2024']]) {
    try {const records=await requestData(path,env.CBBD_API_KEY,fetcher);await env.BUCKET.put(`${pathRoot}/${label}.json`,JSON.stringify(records));if(label==='ratings')ratings=records;else games=records;}
    catch {warnings.push(`${label} unavailable; validated season statistics remain usable.`);}
  }
  let teamsUpdated=0;
  const teams=previous.teams.map(team=>{const converted=normalizeTeam(uniqueRow(rawTeams,row=>identity(row.team)===identity(team.name)&&row.season===2024),team,uniqueRow(ratings,row=>identity(row.team)===identity(team.name)&&row.season===2024));if(converted)teamsUpdated++;return converted||team;});
  let playersUpdated=0;
  const players=[];
  const groups=new Map();
  const historicalPlayers=bundled.players.map(player=>previous.players.find(p=>p.id===player.id)||player);
  for(const player of historicalPlayers){if(player.year===2024){players.push(player);continue;}const key=`${player.year}/${player.school}`;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(player);}
  for(const [group,list] of groups){
    const {year,school}=list[0];let raw=[];
    const providerSchool=rawTeams.find(row=>identity(row.team)===identity(school))?.team||({UConn:'Connecticut'}[school])||school;
    try {raw=await requestData(`/stats/player/season?season=${year}&team=${encodeURIComponent(providerSchool)}`,env.CBBD_API_KEY,fetcher);await env.BUCKET.put(`${pathRoot}/players-${year}-${normalize(school)}.json`,JSON.stringify(raw));}
    catch {warnings.push(`${school} ${year} unavailable; verified university records retained.`);}
    for(const original of list){const converted=normalizePlayer(uniqueRow(raw,row=>identity(row.name)===identity(original.name)&&row.season===original.year&&identity(row.team)===identity(original.school)),original);if(converted)playersUpdated++;players.push(converted||original);}
  }
  const pool=expandProviderPool(rawPlayers,rawTeams,{...bundled,players,teams});
  warnings.push(...pool.warnings);
  const providerGroups=pool.draftGroups.filter(g=>g.source==='cbbd').length;
  if(teamsUpdated<50 || providerGroups<20) throw new Error(`Import validation found only ${teamsUpdated}/63 opponents and ${providerGroups} complete 2023-24 school rosters. The prior snapshot is unchanged. Check provider coverage and retry.`);
  playersUpdated+=pool.players.filter(p=>p.year===2024&&p.providerAthleteId).length;
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify({teams,players:pool.players,draftGroups:pool.draftGroups})));
  const hash=[...new Uint8Array(digest)].map(n=>n.toString(16).padStart(2,'0')).join('').slice(0,16);
  const summary={version:`cbbd-${hash}`,updatedAt:stamp,playersUpdated,teamsUpdated,playersAdded:pool.playersAdded,groupsAdded:pool.groupsAdded,providerGroups,gamesFetched:games.length,warnings};
  const catalog={...bundled,version:summary.version,checkedAt:stamp,sourceLabel:'CBBD + verified university records',players:pool.players,draftGroups:pool.draftGroups,teams,sources:[...bundled.sources,{label:'CollegeBasketballData.com season statistics',title:'CollegeBasketballData.com season statistics',url:`${BASE}/api/stats`}],coverage:[`${playersUpdated} player records and ${teamsUpdated} team records validated from CBBD on ${stamp.slice(0,10)}.`,`${providerGroups} full 2023-24 school rosters accepted after player totals reconcile to the team's season scoring.`,`Historical player imports must match the complete season games count; incomplete rows retain their previously verified source.`,`Teams imported from CBBD use full-season records. Retained university/NCAA records retain their original as-of date.`,`Missing pace, shooting or adjusted efficiency stays unavailable and uses a neutral game estimate.`,...warnings],importSummary:summary};
  // Publish only the completed, validated, curated snapshot. Raw storage has no public route.
  if(!validCatalog(catalog,bundled))throw new Error('The completed import failed snapshot validation. The prior snapshot is unchanged.');
  await env.BUCKET.put(`final-possession/catalog/${catalog.version}.json`,JSON.stringify(catalog));
  await env.BUCKET.put(LATEST,JSON.stringify(catalog));
  return summary;
}
