/** Pure, fail-closed expansion of complete CBBD 2023-24 school rosters. */
import {seasonCreditCost} from '../public/js/catalog.js';

const YEAR=2024,SEASON='2023-24';
const normalize=value=>typeof value==='string'?value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,''):'';
const aliases={uconn:'connecticut',byu:'brighamyoung',tcu:'texaschristian',uab:'alabamabirmingham',ncstate:'northcarolinastate',fau:'floridaatlantic',mcneese:'mcneesestate',grambling:'gramblingstate',charleston:'collegeofcharleston'};
const schoolKey=value=>aliases[normalize(value)]||normalize(value);
const groupKey=(school,season)=>schoolKey(school)+'/'+season;
const nameValid=value=>typeof value==='string'&&value.trim().length>0&&value.length<=160&&!/[\u0000-\u001f]/.test(value)&&normalize(value).length>0;
const count=value=>Number.isSafeInteger(value)&&value>=0&&value<=100000;
const gamesValid=value=>Number.isInteger(value)&&value>=1&&value<=50;
const round=value=>Math.round((value+Number.EPSILON)*10)/10;
const rate=(made,attempted)=>attempted===0?null:round(100*made/attempted);
const athleteKey=value=>(Number.isSafeInteger(value)||typeof value==='string'&&/^\d+$/.test(value))&&Number.isSafeInteger(Number(value))&&Number(value)>0?String(Number(value)):null;
const shots=value=>value&&count(value.made)&&count(value.attempted)&&value.made<=value.attempted;

function rolesFor(position) {
  if(typeof position!=='string')return null;
  const names={'POINT GUARD':'PG','SHOOTING GUARD':'SG','SMALL FORWARD':'SF','POWER FORWARD':'PF','GUARD':'G','FORWARD':'F','CENTER':'C'};
  let normalized=position.trim().toUpperCase();
  for(const [name,short] of Object.entries(names))normalized=normalized.replaceAll(name,short);
  const mapping={PG:['PG'],SG:['SG'],SF:['SF'],PF:['PF'],C:['PF','C'],G:['PG','SG'],F:['SF','PF']};
  const tokens=normalized.split(/[\s/,-]+/).filter(Boolean);
  if(!tokens.length||tokens.some(token=>!mapping[token]))return null;
  const found=new Set(tokens.flatMap(token=>mapping[token]));
  return ['PG','SG','SF','PF','C'].filter(role=>found.has(role));
}

function convert(raw,team,original,school) {
  const id=athleteKey(raw.athleteId),roles=rolesFor(raw.position);
  if(!id||!nameValid(raw.name)||raw.season!==YEAR||!gamesValid(raw.games)||raw.games>team.games||!roles)return null;
  if(original&&raw.games!==original.stats.games)return null;
  if(original?.providerAthleteId&&String(original.providerAthleteId)!==id)return null;
  const g=raw.games,fg=raw.fieldGoals,three=raw.threePointFieldGoals,ft=raw.freeThrows,reb=raw.rebounds;
  if(!['points','assists','steals','blocks','turnovers'].every(key=>count(raw[key])))return null;
  if(typeof raw.minutes!=='number'||!Number.isFinite(raw.minutes)||raw.minutes<0||raw.minutes>60*g)return null;
  if(raw.points>60*g||!shots(fg)||!shots(three)||!shots(ft)||three.made>fg.made||three.attempted>fg.attempted)return null;
  if(raw.twoPointFieldGoals!=null&&(!shots(raw.twoPointFieldGoals)||fg.made!==raw.twoPointFieldGoals.made+three.made||fg.attempted!==raw.twoPointFieldGoals.attempted+three.attempted))return null;
  if(raw.points!==2*fg.made+three.made+ft.made)return null;
  if(!reb||!['total','offensive','defensive'].every(key=>count(reb[key]))||reb.total!==reb.offensive+reb.defensive)return null;
  if(raw.starts!=null&&(!count(raw.starts)||raw.starts>g))return null;
  const stats={games:g,ppg:round(raw.points/g),rpg:round(reb.total/g),apg:round(raw.assists/g),
    threePct:rate(three.made,three.attempted),threeAttempts:three.attempted,ftPct:rate(ft.made,ft.attempted),
    mpg:round(raw.minutes/g),spg:round(raw.steals/g),bpg:round(raw.blocks/g),fgPct:rate(fg.made,fg.attempted),
    tov:round(raw.turnovers/g),starts:raw.starts??null,orpg:round(reb.offensive/g),drpg:round(reb.defensive/g),
    fgAttempts:fg.attempted,ftAttempts:ft.attempted};
  if(original&&Object.keys(original.stats).some(key=>original.stats[key]!=null&&stats[key]===null))return null;
  const seasonTotals={games:g,starts:stats.starts,minutes:raw.minutes,points:raw.points,rebounds:reb.total,
    offRebounds:reb.offensive,defRebounds:reb.defensive,assists:raw.assists,steals:raw.steals,blocks:raw.blocks,
    turnovers:raw.turnovers,fgMade:fg.made,fgAttempts:fg.attempted,threeMade:three.made,threeAttempts:three.attempted,
    ftMade:ft.made,ftAttempts:ft.attempted};
  return {id:original?.id??`cbbd-${id}-${YEAR}`,personId:original?.personId??`cbbd-${id}`,providerAthleteId:id,
    name:original?.name??raw.name.trim(),school,season:SEASON,year:YEAR,
    number:original?.number??(count(raw.jersey)&&raw.jersey<=99?raw.jersey:null),
    roles:original?.roles??roles,cost:original?.cost??seasonCreditCost(stats),
    costModel:original?.costModel??'season-box-v1',stats,seasonTotals,
    source:{label:'CollegeBasketballData.com',url:'https://api.collegebasketballdata.com/stats/player/season?season=2024',season:YEAR},
    verified:true,sampleNote:g<10?'Fewer than 10 games in this season.':stats.mpg<5?'Fewer than 5 minutes per game in this season.':null};
}

export function expandProviderPool(rawPlayers,rawTeams,bundled) {
  const basePlayers=bundled.players;
  const baseGroups=bundled.draftGroups??[...new Map(basePlayers.map(p=>[groupKey(p.school,p.season),{school:p.school,season:p.season}])).values()];
  const unchanged=warnings=>({players:[...basePlayers],draftGroups:[...baseGroups],groupsAdded:0,playersAdded:0,warnings});
  if(!Array.isArray(rawPlayers)||!Array.isArray(rawTeams))return unchanged(['Provider pool was not expanded: expected player and team arrays.']);
  const groups=new Map(),teams=new Map(),athletes=new Map(),warnings=[];
  for(const row of rawTeams) {
    if(!row||row.season!==YEAR||!nameValid(row.team))continue;
    const key=schoolKey(row.team);if(!teams.has(key))teams.set(key,[]);teams.get(key).push(row);
  }
  for(const row of rawPlayers) {
    if(row?.games===0)continue;
    if(!row||!nameValid(row.team))return unchanged(['Provider pool was not expanded: a player with appearances has no usable team identity.']);
    const key=schoolKey(row.team);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(row);
    const id=athleteKey(row.athleteId);
    if(id){if(!athletes.has(id))athletes.set(id,[]);athletes.get(id).push(key);}
  }
  const duplicateGroups=new Set([...athletes.values()].filter(keys=>keys.length>1).flat());
  const originals=new Map(),canonicalSchools=new Map(),originalIds=new Map(basePlayers.map(p=>[p.id,p]));
  for(const p of basePlayers) {
    const key=groupKey(p.school,p.season)+'/'+normalize(p.name);
    if(!originals.has(key))originals.set(key,[]);originals.get(key).push(p);
    canonicalSchools.set(groupKey(p.school,p.season),p.school);
  }
  const accepted=[],replaced=new Set(),usedIds=new Set();
  for(const [key,rows] of [...groups.entries()].sort(([a],[b])=>a.localeCompare(b))) {
    const matches=teams.get(key)??[],team=matches[0],group=key+'/'+SEASON;
    const school=canonicalSchools.get(group)??team?.team?.trim()??rows[0].team.trim();
    const reject=reason=>warnings.push(`${school} ${SEASON} was not imported: ${reason}.`);
    if(matches.length!==1||!gamesValid(team?.games)||!count(team?.teamStats?.points?.total)||team.teamStats.points.total>150*team.games){reject('missing, ambiguous or invalid team totals');continue;}
    if(rows.length<5||rows.length>30){reject('a complete group needs 5 to 30 players with appearances');continue;}
    if(duplicateGroups.has(key)||new Set(rows.map(row=>normalize(row.name))).size!==rows.length){reject('duplicate or ambiguous player identities');continue;}
    const converted=[];
    for(const row of rows) {
      const originalMatches=originals.get(group+'/'+normalize(row.name))??[];
      const p=originalMatches.length>1?null:convert(row,team,originalMatches[0],school);
      if(!p){converted.length=0;break;}converted.push(p);
    }
    if(converted.length!==rows.length){reject('an appearing player has incomplete, contradictory or unsupported data');continue;}
    const retainedIds=new Set(converted.map(p=>p.id));
    if(basePlayers.some(p=>groupKey(p.school,p.season)===group&&!retainedIds.has(p.id))){reject('the response omits a previously verified appearing player');continue;}
    if(converted.reduce((sum,p)=>sum+p.seasonTotals.points,0)!==team.teamStats.points.total){reject('player points do not reconcile with the full team season');continue;}
    if(converted.some(p=>usedIds.has(p.id)||(originalIds.has(p.id)&&(groupKey(originalIds.get(p.id).school,originalIds.get(p.id).season)!==group||normalize(originalIds.get(p.id).name)!==normalize(p.name))))||new Set(converted.map(p=>p.id)).size!==converted.length){reject('duplicate resulting player IDs');continue;}
    converted.sort((a,b)=>a.id.localeCompare(b.id));
    converted.forEach(p=>usedIds.add(p.id));
    accepted.push({group:{school,season:SEASON,source:'cbbd'},players:converted});replaced.add(group);
  }
  const existingIds=new Set(basePlayers.map(p=>p.id)),existingGroups=new Set(baseGroups.map(g=>groupKey(g.school,g.season)));
  const addedPlayers=accepted.flatMap(g=>g.players);
  return {players:[...basePlayers.filter(p=>!replaced.has(groupKey(p.school,p.season))),...addedPlayers],
    draftGroups:[...baseGroups.filter(g=>!replaced.has(groupKey(g.school,g.season))),...accepted.map(g=>g.group)],
    groupsAdded:accepted.filter(g=>!existingGroups.has(groupKey(g.group.school,g.group.season))).length,
    playersAdded:addedPlayers.filter(p=>!existingIds.has(p.id)).length,warnings};
}
