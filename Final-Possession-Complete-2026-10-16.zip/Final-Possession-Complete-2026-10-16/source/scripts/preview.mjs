// Lightweight local preview of the same public modules and data service.
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {CATALOG} from '../public/js/catalog.js';
import {dataStatus} from '../server/data-service.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../public');
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.ttf':'font/ttf','.woff2':'font/woff2','.json':'application/json','.txt':'text/plain'};
http.createServer(async(req,res)=>{
  try {
    const url=new URL(req.url,'http://127.0.0.1:4317');
    if(url.pathname==='/api/catalog'){res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(CATALOG));return;}
    if(url.pathname==='/api/data/status'){res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(await dataStatus({},null,CATALOG)));return;}
    const pathname=['/','/play'].includes(url.pathname)?'/play.html':decodeURIComponent(url.pathname);
    const file=path.resolve(root,'.'+pathname);
    if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
    const body=await readFile(file);res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(body);
  }catch{res.writeHead(404);res.end('Not found');}
}).listen(4317,'127.0.0.1',()=>console.log('Final Possession preview: http://127.0.0.1:4317'));
