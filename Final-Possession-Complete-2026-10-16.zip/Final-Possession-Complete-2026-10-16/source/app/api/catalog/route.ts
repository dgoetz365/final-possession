import { env } from 'cloudflare:workers';
import { CATALOG } from '../../../public/js/catalog.js';
import { readCatalog } from '../../../server/data-service.js';
export async function GET() {
  return Response.json(await readCatalog(env,CATALOG),{headers:{'Cache-Control':'private, no-store'}});
}
