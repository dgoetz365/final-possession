import { env } from 'cloudflare:workers';
import { CATALOG } from '../../../../public/js/catalog.js';
import { refreshCatalog } from '../../../../server/data-service.js';
export async function POST(request:Request) {
  const bindings=env as typeof env & {DATA_ADMIN_EMAIL?:string};
  const email=request.headers.get('oai-authenticated-user-email');
  if(!request.headers.get('oai-authenticated-user-id') || !bindings.DATA_ADMIN_EMAIL || !email || email.toLowerCase()!==bindings.DATA_ADMIN_EMAIL.toLowerCase()) return Response.json({error:'Only the Site owner can refresh the data.'},{status:403});
  if(request.headers.get('origin')!==new URL(request.url).origin) return Response.json({error:'Use the refresh control in Final Possession.'},{status:403});
  try {return Response.json(await refreshCatalog(env,CATALOG),{headers:{'Cache-Control':'no-store'}});}
  catch(error) {return Response.json({error:error instanceof Error?error.message:'The data refresh failed.'},{status:502});}
}
