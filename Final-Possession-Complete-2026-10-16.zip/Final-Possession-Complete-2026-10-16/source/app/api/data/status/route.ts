import { env } from 'cloudflare:workers';
import { CATALOG } from '../../../../public/js/catalog.js';
import { dataStatus } from '../../../../server/data-service.js';
export async function GET(request:Request) {
  const email=request.headers.get('oai-authenticated-user-id')?request.headers.get('oai-authenticated-user-email'):null;
  return Response.json(await dataStatus(env,email,CATALOG),{headers:{'Cache-Control':'private, no-store'}});
}
