# Final Possession

A college basketball game with random school-season drafting, twelve committed picks, a 100-credit budget, a five-player lineup, and a 64-team single-elimination tournament. Routine possessions resolve automatically; the player coaches consequential moments.

## Run locally

Use Node.js 22.13 or newer. Install with `node scripts/install-ci.mjs`, then use `npm run dev` for the full application. `node scripts/preview.mjs` starts a lightweight interface preview at http://127.0.0.1:4317 with the bundled historical data. That preview does not test Cloudflare authentication, storage or live imports.

Run checks with `node --test --experimental-test-isolation=none --test-concurrency=1 tests/*.test.mjs`. Build with `node scripts/run-framework.mjs build`. `npm start` serves the built Cloudflare Worker locally.

## Code

- `public/js/engine.js`: deterministic drafting, rotation, possession simulation and tournament state.
- `public/js/catalog.js` and `season-tables.js`: historical records and their primary sources.
- `public/js/views.js` and `public/styles.css`: responsive game screens.
- `public/js/main.js` and `storage.js`: interface actions, browser saves and run history.
- `server/data-service.js` and `provider-pool.js`: server-only CollegeBasketballData.com validation and complete-roster imports.
- `app/api/`: catalog, connection status and owner-only refresh routes.

## Historical data and estimates

The bundled library contains 103 player-seasons. Random draws use 96 players from seven complete school-season tables across five schools. Seven biography records remain available for research. Official source references are retained in the catalog and documentation, outside the player-facing experience. The opponent pool uses the 2024 NCAA Round of 64, with Saint Mary's replaced by the user's team.

A successful provider import expands the library with complete 2024 school rosters, including reserves. A new run samples up to sixteen distinct schools and one season per school. Draws prefer schools not yet offered while feasible alternatives remain. The run keeps this compact cohort in its browser save.

Historical statistics are distinct from game credits, position eligibility, strength ratings and simulated results. The game model is original and uncalibrated. Missing facts remain unavailable. Read `DATA-SOURCES.md` for evidence and `ENGINE-NOTES.md` for rules, assumptions and limitations.

## Private Site configuration

`.openai/hosting.json` stores the Site identifier and declares private R2 storage as `BUCKET`. Set `CBBD_API_KEY` and `DATA_ADMIN_EMAIL` as secrets in the Site's runtime environment. Never put the API key in browser code, this repository or a saved game. Deploy the saved version after runtime environment changes to apply them.

Only the owner can open Settings > Data connection to refresh the catalog. Imports validate player identity, full-season games, roster completeness and totals before publishing one complete snapshot. Provider failures preserve the prior snapshot. Raw API responses stay in private storage. Existing runs retain their original catalog and random state; refreshed data applies to new runs.

Local browser saves are unranked and editable by their owner. Export saves before clearing browser storage.

