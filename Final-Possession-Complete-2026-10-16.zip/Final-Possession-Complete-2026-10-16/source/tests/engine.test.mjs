import test from 'node:test';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import * as E from '../public/js/engine.js';

// These are explicit synthetic fixtures. They are never part of the player catalog.
function fixture() {
  const roles = ['PG', 'SG', 'SF', 'PF', 'C'];
  const players = Array.from({length: 25}, (_, i) => ({
    id: `p${i}`, personId: `person${i}`, name: `Synthetic ${i}`, school: `Synthetic School ${Math.floor(i/5)}`, season: '2000-01', year: 2001,
    roles: [roles[i % 5]], cost: i < 5 ? 13 : 5,
    stats: {games: 30, ppg: 18 + i % 4, rpg: 4 + i % 5, apg: 2 + (i % 5 === 0 ? 4 : 0), mpg: 30, threePct: 38, threeAttempts: 120, ftPct: 79, spg: 1, bpg: i % 5 === 4 ? 2 : 0.4}}));
  const teams = Array.from({length: 63}, (_, i) => ({id: `t${i}`, name: `Synthetic Opponent ${i}`, seed: Math.floor(i / 4) + 1, region: ['East', 'West', 'South', 'Midwest'][i % 4], season: '2023-24', stats: {wins: 30 - Math.floor(i / 7), losses: 4 + Math.floor(i / 8), threePct: null}}));
  return {version: 'synthetic-v1', players, teams};
}
const C = fixture();
function drafted(seed = 'test', catalog = C) {
  // Fixed roster fixtures isolate gameplay tests from offer randomness.
  const run = E.createRun(catalog, seed);
  run.roster = ['p0', 'p1', 'p2', 'p3', 'p4', 'p5', 'p8', 'p9','p10','p11','p12','p13'];
  run.draft.offers = []; run.draft.round = E.ROSTER_SIZE;
  return E.autoRotation({...run, phase: 'lineup'}, catalog);
}
function ready(seed = 'test', catalog = C) { return E.seedTournament(drafted(seed, catalog), catalog); }
function finish(run, catalog = C, choice) {
  let count = 0;
  while (run.phase === 'playing') {
    if (++count > 24) throw new Error('Moment loop did not finish.');
    const chosen = run.game.moment.choices.find(c => c.id === choice)?.id || run.game.moment.choices[0].id;
    run = E.act(run, {type: 'decision', choice: chosen}, catalog);
  }
  return run;
}
function runTournament(seed, catalog = C) {
  let run = ready(seed, catalog);
  for (let round = 0; round < 6; round++) {
    run = finish(E.startGame(run, 'move-ball', catalog), catalog);
    if (['champion', 'eliminated'].includes(run.phase)) return run;
    run = E.advanceTournament(run, catalog);
  }
  throw new Error('Tournament failed to terminate.');
}

test('draft enforces offers, one person, budget, committed picks and roster capacity', () => {
  let run = E.createRun(C, 1);
  const original = structuredClone(run);
  const offered = run.draft.offers[0], outside = C.players.find(p => !run.draft.offers.includes(p.id));
  assert.equal(run.draft.offers.length, 5);
  assert.ok(run.draft.offers.every(id => C.players.find(p => p.id===id).school === run.draft.school));
  assert.equal(E.canDraft(run, offered, C), true);
  assert.equal(E.canDraft(run, outside.id, C), false);
  assert.throws(() => E.draftPlayer(run, outside.id, C), /currently offered/);
  run = E.draftPlayer(run, offered, C);
  assert.deepEqual(original, E.createRun(C, 1));
  assert.throws(() => E.draftPlayer(run, offered, C), /currently offered/);
  const picked = C.players.find(p => p.id === offered);
  const alternate = {...C, players: [...C.players, {...picked, id: 'other-season'}]};
  assert.throws(() => E.draftPlayer({...run,draft:{...run.draft,school:picked.school,offers:['other-season']}}, 'other-season', alternate), /already drafted/);
  const expensive = {...C, players: [...C.players, {...C.players[1], id: 'expensive', personId: 'expensive', cost: 96}]};
  assert.throws(() => E.draftPlayer({...run,draft:{...run.draft,school:C.players[1].school,offers:['expensive']}}, 'expensive', expensive), /enough draft credits/);
  assert.ok(!E.createRun(expensive, 1).draft.offers.includes('expensive'));
  const full = drafted();
  assert.equal(E.validateRoster(full, C).spent, 100);
  assert.equal(E.validateRoster(full, C).valid, true);
  assert.equal(full.phase, 'lineup');
  assert.throws(() => E.draftPlayer(full, 'p10', C), /roster is full/);
  assert.throws(() => E.removePlayer(run, offered, C), /committed/);
  assert.throws(() => E.removePlayer(full, 'p0', C), /committed/);
});

test('draft rejects affordable choices that exhaust all remaining position slots', () => {
  const catalog = fixture(); catalog.players.forEach(p => p.cost = 1);
  for(let i=0;i<4;i++)catalog.players.push({...catalog.players[0],id:`extra-${i}`,personId:`extra-${i}`});
  const guardsOnly = ['p0', 'p5', 'p10', 'p15', 'p20','extra-0','extra-1','extra-2','extra-3'];
  const run = E.createRun(catalog, 2);
  run.roster = guardsOnly.slice(0,8); run.draft.offers = [guardsOnly[8]]; run.draft.school = catalog.players[0].school;
  assert.throws(() => E.draftPlayer(run, guardsOnly[8], catalog), /prevent a 12-player/);
});

test('randomized deals are seeded, reload-stable and different across seeds', () => {
  const a = E.createRun(C, 'deals-a'), b = E.createRun(C, 'deals-a');
  assert.deepEqual(a, b);
  assert.ok(new Set(Array.from({length:8},(_,i)=>E.createRun(C,`groups-${i}`).draft.school)).size > 1);
  const reloaded = JSON.parse(JSON.stringify(a));
  const first = a.draft.offers[0];
  assert.deepEqual(E.draftPlayer(a, first, C), E.draftPlayer(reloaded, first, C));
  assert.equal(a.roster.length, 0);
});

test('two deterministic rerolls replace offers without changing picks or granting undo', () => {
  const original = E.createRun(C, 'rerolls');
  const once = E.rerollDraft(original, C);
  assert.equal(once.draft.rerollsLeft, 1); assert.equal(original.draft.rerollsLeft, 2);
  assert.ok(once.draft.offers.every(id => !original.draft.offers.includes(id)));
  assert.deepEqual(once, E.rerollDraft(JSON.parse(JSON.stringify(original)), C));
  assert.deepEqual(once.roster, original.roster);
  const twice = E.rerollDraft(once, C);
  assert.equal(twice.draft.rerollsLeft, 0);
  assert.throws(() => E.rerollDraft(twice, C), /used both/);
  const picked = E.draftPlayer(twice, twice.draft.offers[0], C);
  assert.equal(picked.draft.rerollsLeft, 0);
  assert.equal(picked.draft.round, 2);
  assert.throws(() => E.removePlayer(picked, picked.roster[0], C), /committed/);
});

test('random offer choices always lead to a complete legal twelve-player roster', () => {
  const draftedPeople = new Set();
  for (let seed = 0; seed < 10; seed++) {
    let run = E.createRun(C, `real-draft-${seed}`);
    for (let pick = 0; pick < E.ROSTER_SIZE; pick++) {
      assert.equal(run.draft.round, pick + 1);
      assert.ok(run.draft.offers.length > 0 && run.draft.offers.length <= 5);
      assert.ok(run.draft.offers.every(id => C.players.find(p=>p.id===id).school===run.draft.school && C.players.find(p=>p.id===id).season===run.draft.season));
      if (pick < 2) {
        try {run = E.rerollDraft(run, C);} catch(error) {assert.match(error.message, /No different school/);}
      }
      const id = run.draft.offers[(seed + pick) % run.draft.offers.length];
      draftedPeople.add(id);
      run = E.draftPlayer(run, id, C);
    }
    assert.equal(run.phase, 'lineup'); assert.equal(run.roster.length, E.ROSTER_SIZE);
    assert.deepEqual(run.draft.offers, []);
    assert.equal(E.validateRoster(run, C).valid, true);
    assert.equal(E.canDraft(run, run.roster[0], C), false);
  }
  assert.ok(draftedPeople.size > 16, 'Random offers should draw broadly from the catalog');
});

test('a redraw is not spent when only one feasible school-season remains', () => {
  const catalog=fixture(); catalog.players.forEach(p=>p.school='Only School');
  const run=E.createRun(catalog,'only-one-group');
  assert.throws(()=>E.rerollDraft(run,catalog),/No different school/);
  assert.equal(run.draft.rerollsLeft,2);
  assert.equal(run.draft.offers.length,25);
});

test('published draft-group policy excludes biography-only stars and infeasible reference help', () => {
  const catalog=fixture();
  catalog.draftGroups=[{school:'Synthetic School 0',season:'2000-01'},{school:'Synthetic School 1',season:'2000-01'},{school:'Synthetic School 2',season:'2000-01'}];
  for(let seed=0;seed<5;seed++) {
    const run=E.createRun(catalog,`approved-${seed}`);
    assert.ok(['Synthetic School 0','Synthetic School 1','Synthetic School 2'].includes(run.draft.school));
    assert.ok(run.draft.offers.every(id=>Number(id.slice(1))<15));
    assert.equal(E.canDraft(run,'p20',catalog),false);
  }
  const run=E.createRun(catalog,'reference');
  run.draft.school='Synthetic School 4';run.draft.offers=['p20'];
  assert.throws(()=>E.draftPlayer(run,'p20',catalog),/reference library/);
  const invalid=fixture();
  invalid.draftGroups=[{school:'Synthetic School 0',season:'2000-01'}];
  assert.throws(()=>E.createRun(invalid,'too-small'),/not enough/);
});

test('rotation requires eligible, distinct starters and exactly 200 minutes', () => {
  const run = drafted();
  assert.equal(E.ROSTER_SIZE, 12);
  assert.equal(run.starters.length, 5);
  assert.equal(run.roster.filter(id => !run.starters.includes(id)).length, 7);
  assert.ok(run.starters.every(id => run.minutes[id] === 30));
  assert.deepEqual(run.roster.filter(id => !run.starters.includes(id)).map(id => run.minutes[id]).sort((a,b)=>a-b), [7,7,7,7,7,7,8]);
  assert.equal(Object.values(run.minutes).reduce((a, b) => a + b), 200);
  assert.throws(() => E.setRotation(run, {starters: Array(5).fill('p0'), minutes: run.minutes}, C), /different starters/);
  const wrong = [...run.starters]; [wrong[0], wrong[1]] = [wrong[1], wrong[0]];
  assert.throws(() => E.setRotation(run, {starters: wrong, minutes: run.minutes}, C), /eligible/);
  assert.throws(() => E.setRotation(run, {starters: run.starters, minutes: {...run.minutes, p0: 29}}, C), /total 200/);
});

test('extra bench slots give no free strength when the bench has no minutes', () => {
  const run = drafted();
  const startersOnly = E.setRotation(run, {starters:run.starters,minutes:Object.fromEntries(run.roster.map(id => [id,run.starters.includes(id)?40:0]))}, C);
  assert.equal(E.estimateTeam(startersOnly,C).factors.find(f=>f.label==='Bench support').value, 0);
  assert.equal(E.estimateTeam(run,C).factors.find(f=>f.label==='Bench support').value, 1);
});

test('a 5000-player library becomes a deterministic complete 16-school cohort and a legal 12-pick run', () => {
  const full = {...fixture(),version:'synthetic-library-5000',draftGroups:[],players:[]};
  for(let school=0;school<100;school++) for(const season of ['2000-01','2001-02']) {
    full.draftGroups.push({school:`College ${school}`,season});
    for(let p=0;p<25;p++) full.players.push({...C.players[p],id:`${school}-${season}-${p}`,personId:`${school}-${p}`,school:`College ${school}`,season,cost:5});
  }
  const before=JSON.stringify(full),start=performance.now(),catalog=E.prepareRunCatalog(full,'library-audit');
  const prepared=performance.now();
  assert.equal(full.players.length,5000);
  assert.equal(catalog.players.length,400);
  assert.equal(catalog.draftGroups.length,16);
  assert.equal(new Set(catalog.draftGroups.map(g=>g.school)).size,16);
  assert.equal(catalog.parentVersion,full.version);
  assert.equal(catalog.cohort.sourcePlayerCount,5000);
  assert.match(catalog.version,/synthetic-library-5000:cohort-[0-9a-f]+$/);
  assert.deepEqual(catalog.teams,full.teams);
  for(const g of catalog.draftGroups) assert.deepEqual(catalog.players.filter(p=>p.school===g.school),full.players.filter(p=>p.school===g.school&&p.season===g.season));
  assert.deepEqual(catalog,E.prepareRunCatalog(full,'library-audit'));
  assert.deepEqual(catalog,E.prepareRunCatalog(catalog,'library-audit'));
  assert.notEqual(catalog.version,E.prepareRunCatalog(full,'different-library-audit').version);
  let run=E.createRun(catalog,'library-audit');
  const offeredSchools=[];
  for(let redraw=0;redraw<2;redraw++) {
    offeredSchools.push(run.draft.school);
    run=E.rerollDraft(run,catalog);
  }
  for(let pick=0;pick<E.ROSTER_SIZE;pick++) {
    offeredSchools.push(run.draft.school);
    const restored=JSON.parse(JSON.stringify(run));
    assert.deepEqual(restored.draft,run.draft);
    assert.ok(run.draft.offers.every(id=>E.canDraft(run,id,catalog)));
    run=E.draftPlayer(restored,restored.draft.offers[0],catalog);
  }
  const draftedAt=performance.now();
  assert.equal(new Set(offeredSchools).size,14);
  assert.equal(run.draft.rerollsLeft,0);
  assert.equal(E.validateRoster(run,catalog).valid,true);
  assert.equal(E.validateRoster(run,catalog).spent,60);
  assert.equal(JSON.stringify(full),before);
  console.log(`5000-player audit: prepare ${(prepared-start).toFixed(1)}ms; full draft plus validation ${(draftedAt-prepared).toFixed(1)}ms; cohort ${catalog.players.length} players.`);
});

test('schools repeat only after unseen feasible schools are exhausted', () => {
  const catalog=fixture();catalog.players.forEach(p=>p.cost=1);
  let run=E.createRun(catalog,'small-library');
  const seen=[];
  for(let pick=0;pick<E.ROSTER_SIZE;pick++) {
    if(pick<5) assert.ok(!seen.includes(run.draft.school));
    else assert.ok(seen.includes(run.draft.school));
    seen.push(run.draft.school);
    run=E.draftPlayer(run,run.draft.offers[0],catalog);
  }
  assert.equal(E.validateRoster(run,catalog).valid,true);
});

test('64-team strength-based seeding is coherent and draft quality changes its estimate', () => {
  const run = ready(), ids = run.bracket.entrants.map(t => t.id);
  assert.equal(ids.length, 64); assert.equal(new Set(ids).size, 64);
  assert.deepEqual(run.bracket.rounds.map(r => r.length), [32, 16, 8, 4, 2, 1]);
  for (const region of ['East', 'West', 'South', 'Midwest']) assert.deepEqual(run.bracket.entrants.filter(t => t.region === region).map(t => t.seed).sort((a, b) => a - b), Array.from({length: 16}, (_, i) => i + 1));
  const firstIds = run.bracket.rounds[0].flatMap(g => [g.teamA, g.teamB]);
  assert.equal(new Set(firstIds).size, 64);
  assert.equal(E.estimateTeam(run, C).seed, run.bracket.entrants.find(t => t.id === 'user').seed);
  const better = fixture(); better.players.forEach(p => {p.stats.ppg += 8; p.stats.apg += 2;});
  assert.ok(E.estimateTeam(drafted('x', better), better).strength > E.estimateTeam(drafted(), C).strength);
  assert.ok(E.estimateTeam(drafted('x', better), better).seed <= E.estimateTeam(drafted(), C).seed);
  assert.throws(() => E.removePlayer(run, 'p0', C), /committed/);
  assert.deepEqual(E.seedTournament(run, C), run);
});

test('entire simulation is deterministic, immutable, serializable and has bounded moments', () => {
  const initial = ready('determinism'), before = JSON.stringify(initial);
  const a = finish(E.startGame(initial, 'move-ball', C));
  const b = finish(E.startGame(JSON.parse(before), 'move-ball', C));
  assert.deepEqual(a, b); assert.equal(JSON.stringify(initial), before);
  assert.notEqual(a.game.score.user, a.game.score.opponent);
  assert.ok(a.game.decisions.length >= 1 && a.game.decisions.length <= 8);
  assert.ok(a.game.elapsed >= 2400);
  assert.ok(a.game.shots.length > 70);
  assert.equal(a.game.status, 'final');
  assert.deepEqual(JSON.parse(JSON.stringify(a)), a);
  assert.deepEqual(E.act(a, {type: 'continue'}, C), a);
  assert.equal(a.results.length, 1);
});

test('box score totals come from simulated events and regulation minutes add to 200', () => {
  const run = finish(E.startGame(ready('boxscore'), 'move-ball', C));
  const game = run.game;
  assert.equal(Object.values(game.players).reduce((n, p) => n + p.points, 0), game.score.user);
  assert.ok(Math.abs(Object.values(game.players).reduce((n, p) => n + p.minutes, 0) - game.elapsed * 5 / 60) < 1e-6);
  for (const side of ['user', 'opponent']) {
    const b = game.teamStats[side];
    assert.equal(b.fieldGoalsMade * 2 + b.threesMade + b.freeThrowsMade, game.score[side]);
    assert.ok(b.threesMade <= b.threesAttempted && b.fieldGoalsMade <= b.fieldGoalsAttempted);
    assert.equal(game.shots.filter(s => s.side === side && s.type !== 'FT').length, b.fieldGoalsAttempted);
  }
  assert.ok(Object.values(game.players).every(p => p.fouls <= 5 && p.fatigue >= 0 && p.fatigue <= 100));
});

test('timeouts recover fatigue, cannot go negative, and substitutions are real lineup changes', () => {
  let run = E.startGame(ready('subs'), 'move-ball', C);
  const time = run.game.clock, fatigue = Object.values(run.game.players).reduce((n, p) => n + p.fatigue, 0);
  for (let i = 0; i < 4; i++) run = E.act(run, {type: 'timeout'}, C);
  assert.equal(run.game.clock, time); assert.equal(run.game.timeouts.user, 0);
  assert.ok(Object.values(run.game.players).reduce((n, p) => n + p.fatigue, 0) < fatigue);
  assert.throws(() => E.act(run, {type: 'timeout'}, C), /no timeouts/);
  const outId = run.game.lineup[0], inId = run.roster.find(id => !run.game.lineup.includes(id));
  const next = E.act(run, {type: 'substitute', outId, inId}, C);
  assert.ok(!next.game.lineup.includes(outId) && next.game.lineup.includes(inId));
  assert.ok(run.game.lineup.includes(outId));
  const fouled = structuredClone(run); fouled.game.players[inId].fouls = 5;
  assert.throws(() => E.act(fouled, {type: 'substitute', outId, inId}, C), /fouled-out/);
});

test('foul-outs trigger eligible-player recovery; halftime resets period fouls', () => {
  let run = E.startGame(ready('foulout'), 'move-ball', C);
  const id = run.game.lineup[0]; run.game.players[id].fouls = 5; run.game.manualUntil = 0; run.game.lastRotation = -100;
  run = E.act(run, {type: 'continue'}, C);
  assert.ok(!run.game.lineup.includes(id));
  assert.equal(run.game.moment.type, 'halftime');
  run = E.act(run, {type: 'decision', choice: 'move-ball'}, C);
  assert.equal(run.game.period, 2);
  assert.ok(!run.game.lineup.includes(id));
  assert.equal(run.game.players[id].fouls, 5);
});

test('a tied regulation clock produces real overtime and a non-tied result', () => {
  let run = E.startGame(ready('forced-ot'), 'move-ball', C);
  run.game.period = 2; run.game.clock = 0; run.game.stage = 4;
  run.game.score = {user: 60, opponent: 60};
  run = E.act(run, {type: 'continue'}, C);
  assert.equal(run.game.period, 3); assert.equal(run.game.clock, 300);
  assert.equal(run.game.moment.type, 'overtime');
  const shots = run.game.shots.length;
  run = finish(run);
  assert.ok(run.game.shots.length > shots);
  assert.notEqual(run.game.score.user, run.game.score.opponent);
});

test('decisions alter actual simulation inputs and outcomes across a fixed seed batch', () => {
  let differences = 0;
  for (let i = 0; i < 12; i++) {
    const initial = E.startGame(ready(`tactics-${i}`), 'move-ball', C);
    const a = finish(initial, C, 'move-ball');
    let b=initial;
    while(b.phase==='playing') b=E.act(b,{type:'decision',choice:b.game.moment.choices.at(-1).id},C);
    if (a.game.score.user !== b.game.score.user || a.game.score.opponent !== b.game.score.opponent) differences++;
  }
  assert.ok(differences >= 9);
});

test('moment and choice evidence quote the actual source and current game state', () => {
  let run=E.startGame(ready('evidence'),'move-ball',C),checks=0;
  while(run.phase==='playing') {
    const g=run.game,m=g.moment;
    assert.ok(m.evidence.length>=4);
    assert.ok(m.evidence[0].includes(String(g.score.user))&&m.evidence[0].includes(String(g.score.opponent)));
    assert.ok(m.evidence.some(text=>text.includes(`${g.teamStats.user.turnovers} turnovers`)));
    assert.ok(m.evidence.some(text=>text.includes('Unavailable:')&&text.includes('pace')));
    const active=g.lineup.map(id=>C.players.find(p=>p.id===id));
    assert.ok(active.some(p=>m.evidence.some(text=>text.includes(`${p.name} (${p.season}): ${p.stats.threePct}% from three on ${p.stats.threeAttempts}`))));
    for(const option of m.choices) {
      assert.ok(option.evidence.length>=2&&option.rationale.length>15);
      assert.ok(option.evidence.every(text=>typeof text==='string'&&!text.includes('undefined')));
    }
    const visible=[m.title,m.description,...m.evidence,...m.choices.flatMap(c=>[c.label,c.detail,c.rationale,c.risk,...c.evidence])].filter(Boolean).join(' ');
    assert.doesNotMatch(visible,/\b(source|snapshot|model|fallback|API|provider)\b|https?:/i);
    checks++;
    run=E.act(run,{type:'continue'},C);
  }
  assert.ok(checks>=1);
  assert.ok(run.game.decisions.every(d=>d.evidence.length>=2&&d.rationale));
});

test('a ten-point lead with eleven seconds left resolves without a needless decision', () => {
  let run=E.startGame(ready('decided-game'),'move-ball',C);
  run.game.period=2;run.game.clock=11;run.game.stage=3;run.game.score={user:70,opponent:60};
  run.game.moment.type='momentum';
  const decisions=run.game.decisions.length;
  run=E.act(run,{type:'continue'},C);
  assert.equal(run.game.status,'final');assert.equal(run.game.moment,null);
  assert.equal(run.game.decisions.length,decisions+1);
});

test('a tied eleven-second game gets an endgame choice, without requiring earlier quota stops', () => {
  let run=E.startGame(ready('close-game'),'move-ball',C);
  run.game.period=2;run.game.clock=11;run.game.stage=2;run.game.score={user:70,opponent:70};run.game.moment.type='momentum';
  run=E.act(run,{type:'continue'},C);
  assert.equal(run.game.moment.type,'endgame');assert.equal(run.game.clock,11);
  assert.ok(run.game.moment.choices.some(c=>c.id==='control-tempo'));
});

test('clock expiry alone does not force an extra pre-halftime coaching stop', () => {
  let run=E.startGame(ready('no-clock-quota'),'move-ball',C);
  run.game.period=1;run.game.clock=1;run.game.stage=0;run.game.score={user:20,opponent:0};run.game.moment.type='momentum';
  run=E.act(run,{type:'continue'},C);
  assert.equal(run.game.moment.type,'halftime');assert.equal(run.game.clock,0);
});

test('timeout and substitution refresh evidence, and high-risk lineups do not get a casual press option', () => {
  let run=E.startGame(ready('risk-evidence'),'move-ball',C);
  run.game.moment.type='momentum';
  for(const id of run.game.lineup){run.game.players[id].fatigue=80;run.game.players[id].fouls=4;}
  run=E.act(run,{type:'timeout'},C);
  assert.ok(!run.game.moment.choices.some(c=>c.id==='press'));
  assert.ok(run.game.moment.choices.some(c=>c.id==='fresh-legs'));
  assert.ok(run.game.moment.evidence.some(text=>text.includes('70/100 fatigue')));
  const outId=run.game.lineup[0],inId=run.roster.find(id=>!run.game.lineup.includes(id));
  const incoming=C.players.find(p=>p.id===inId);
  run=E.act(run,{type:'substitute',outId,inId},C);
  assert.ok(run.game.lineup.includes(incoming.id));
  assert.match(run.game.moment.description,/updated/);
});

test('tiny-sample 100% three-point shooting does not make a big man an elite shooter', () => {
  const baseline = fixture(), tiny = fixture();
  baseline.players[4].stats.threePct = 33; baseline.players[4].stats.threeAttempts = 1;
  tiny.players[4].stats.threePct = 100; tiny.players[4].stats.threeAttempts = 1;
  const difference = E.estimateTeam(drafted('base', tiny), tiny).strength - E.estimateTeam(drafted('base', baseline), baseline).strength;
  assert.ok(difference >= 0 && difference <= 0.1);
});

test('tiny-minute production is regressed, bounded and weaker than sustained elite production', () => {
  const tiny=fixture(), elite=fixture(), ordinary=fixture();
  tiny.players.forEach(p=>{p.stats={games:1,mpg:0.5,ppg:1,rpg:0.5,apg:0.2,spg:0.1,bpg:0.1,threePct:100,threeAttempts:1,fgPct:100,fgAttempts:1};});
  ordinary.players.forEach(p=>{p.stats={...p.stats,ppg:10,rpg:3,apg:2};});
  elite.players.forEach(p=>{p.stats={...p.stats,ppg:28,rpg:9,apg:6,fgPct:52,fgAttempts:450};});
  const low=E.estimateTeam(drafted('reliability',tiny),tiny).strength;
  const normal=E.estimateTeam(drafted('reliability',ordinary),ordinary).strength;
  const high=E.estimateTeam(drafted('reliability',elite),elite).strength;
  assert.ok(Number.isFinite(low)&&Number.isFinite(normal)&&Number.isFinite(high));
  assert.ok(low<normal && normal<high && high<=98);
  const extreme=fixture(); extreme.players.forEach(p=>{p.stats={...p.stats,ppg:1e6,rpg:1e6,apg:1e6};});
  assert.ok(E.estimateTeam(drafted('extreme',extreme),extreme).strength<=98);
});

test('improving sustained production is monotonic across a wide input range', () => {
  let previous=0;
  for(const points of [0,2,5,10,15,20,25,30,40,100]) {
    const catalog=fixture(); catalog.players.forEach(p=>p.stats.ppg=points);
    const strength=E.estimateTeam(drafted('monotonic',catalog),catalog).strength;
    assert.ok(Number.isFinite(strength)&&strength>=previous);previous=strength;
  }
});

test('full tournaments terminate, conserve bracket winners, and include a six-win champion', () => {
  const started = performance.now(); let champion = null, eliminated = null;
  const strong = fixture(); strong.players.forEach(p => {p.stats.ppg += 10; p.stats.rpg += 3; p.stats.apg += 2;});
  for (let i = 0; i < 60 && (!champion || !eliminated); i++) {
    const run = runTournament(`tournament-${i}`, i % 2 ? strong : C);
    if (run.phase === 'champion') champion = run; else eliminated = run;
    assert.equal(run.results.length, run.wins + (run.phase === 'eliminated' ? 1 : 0));
    assert.equal(run.bracket.rounds.flat().filter(g => g.winner).length, 63);
    for (let r = 0; r < 6; r++) for (const m of run.bracket.rounds[r]) {
      assert.ok(m.winner === m.teamA || m.winner === m.teamB);
      assert.notEqual(m.scoreA, m.scoreB);
      if (r > 0) {
        const i = run.bracket.rounds[r].indexOf(m);
        assert.equal(m.teamA, run.bracket.rounds[r - 1][i * 2].winner);
        assert.equal(m.teamB, run.bracket.rounds[r - 1][i * 2 + 1].winner);
      }
    }
    assert.deepEqual(E.advanceTournament(run, C), run);
  }
  assert.ok(champion, 'A champion should be reachable without a forced result');
  assert.ok(eliminated, 'Elimination should be reachable');
  assert.equal(champion.wins, 6); assert.equal(champion.results.length, 6);
  assert.equal(champion.bracket.rounds[5][0].winner, 'user');
  console.log(`Full tournament verification: ${Math.round(performance.now() - started)} ms.`);
});

test('verified efficiency and scoring margin replace missing-data opponent estimates', () => {
  const c = fixture();
  c.teams[62].stats.adjustedMargin = 30;
  c.teams[61].stats.ppg = 80; c.teams[61].stats.oppPpg = 65;
  const run = ready('efficiency', c);
  const adjusted = run.bracket.entrants.find(t => t.id === 't62');
  assert.equal(adjusted.strength, 93.5);
  assert.match(adjusted.strengthBasis, /Adjusted efficiency/);
  assert.match(run.bracket.entrants.find(t => t.id === 't61').strengthBasis, /Equal blend/);
});

test('catalog and model version drift cannot silently change a saved run', () => {
  const run = drafted();
  assert.throws(() => E.seedTournament(run, {...C, version: 'other'}), /original data snapshot/);
  assert.throws(() => E.seedTournament({...run, modelVersion: 'old'}, C), /older game model/);
});

