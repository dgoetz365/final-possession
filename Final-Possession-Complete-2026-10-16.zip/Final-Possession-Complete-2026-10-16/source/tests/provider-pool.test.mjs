import test from 'node:test';
import assert from 'node:assert/strict';
import {expandProviderPool} from '../server/provider-pool.js';
import {CATALOG,seasonCreditCost} from '../public/js/catalog.js';

// Synthetic API records only. Different production levels deliberately exercise
// starters, ordinary reserves and a zero-scoring walk-on with an appearance.
function schoolFixture(team='Synthetic College',startId=1000) {
  const players=Array.from({length:8},(_,i)=>{
    const games=i===7?1:20,fg=7-i,three=i<4?1:0,ft=i<6?2:0;
    return {athleteId:startId+i,name:'Synthetic Player '+(startId+i),team,season:2024,
      position:['PG','SG','SF','PF','C','G','F','C'][i],games,starts:i<5?games:0,
      minutes:i===7?1:games*(32-i*4),points:games*(2*fg+three+ft),
      fieldGoals:{made:fg*games,attempted:2*fg*games},
      threePointFieldGoals:{made:three*games,attempted:three*3*games},
      freeThrows:{made:ft*games,attempted:ft*2*games},
      rebounds:{total:games*(7-i),offensive:games*(i<7?1:0),defensive:games*Math.max(0,6-i)},
      assists:games*Math.max(0,4-i),turnovers:games,steals:games,blocks:games};
  });
  const row={team,season:2024,games:20,teamStats:{points:{total:players.reduce((n,p)=>n+p.points,0)}}};
  return {players,teams:[row]};
}
const expand=f=>expandProviderPool(f.players,f.teams,CATALOG);

test('many complete schools include every ability level and preserve all historic groups',()=>{
  const fixtures=Array.from({length:25},(_,i)=>schoolFixture('Synthetic College '+i,1000+i*10));
  const result=expand({players:fixtures.flatMap(f=>f.players),teams:fixtures.flatMap(f=>f.teams)});
  assert.equal(result.groupsAdded,25);assert.equal(result.playersAdded,200);
  assert.equal(result.players.length,CATALOG.players.length+200);
  assert.equal(result.draftGroups.filter(g=>g.source==='cbbd').length,25);
  assert.equal(result.warnings.length,0);
  for(const p of CATALOG.players)assert.ok(result.players.includes(p));
  const added=result.players.filter(p=>p.id.startsWith('cbbd-'));
  assert.equal(added.filter(p=>p.stats.ppg===0).length,25);
  assert.ok(added.some(p=>p.cost<=3));assert.ok(added.some(p=>p.stats.ppg>=15));
  for(const p of added) {
    assert.equal(p.cost,seasonCreditCost(p.stats));
    assert.equal(p.season,'2023-24');assert.equal(p.verified,true);
    assert.ok(p.source.url.includes('/stats/player/season?season=2024'));
    assert.equal(p.seasonTotals.points,2*p.seasonTotals.fgMade+p.seasonTotals.threeMade+p.seasonTotals.ftMade);
  }
});

test('known positions map explicitly and zero-attempt rates remain null',()=>{
  const result=expand(schoolFixture()),added=result.players.filter(p=>p.id.startsWith('cbbd-'));
  const roles=id=>added.find(p=>p.providerAthleteId===String(id)).roles;
  assert.deepEqual(roles(1000),['PG']);assert.deepEqual(roles(1001),['SG']);
  assert.deepEqual(roles(1002),['SF']);assert.deepEqual(roles(1003),['PF']);
  assert.deepEqual(roles(1004),['PF','C']);assert.deepEqual(roles(1005),['PG','SG']);
  assert.deepEqual(roles(1006),['SF','PF']);
  const walkOn=added.find(p=>p.providerAthleteId==='1007');
  assert.equal(walkOn.stats.ppg,0);assert.equal(walkOn.stats.games,1);
  assert.equal(walkOn.stats.fgPct,null);assert.equal(walkOn.stats.threePct,null);assert.equal(walkOn.stats.ftPct,null);
  assert.equal(walkOn.number,null);
});

test('same school-season is replaced as a group with matched identities and costs retained',()=>{
  const original=CATALOG.players.find(p=>p.id==='edey-2024');
  const f=schoolFixture('Purdue');
  f.teams[0].games=39;
  f.players=CATALOG.players.filter(p=>p.school==='Purdue'&&p.year===2024).map((p,i)=>{
    const row=structuredClone(f.players[i%8]),g=p.stats.games,factor=g/row.games;
    for(const key of ['starts','minutes','points','assists','turnovers','steals','blocks'])row[key]=Math.round(row[key]*factor);
    for(const key of ['fieldGoals','threePointFieldGoals','freeThrows','rebounds'])for(const field of Object.keys(row[key]))row[key][field]=Math.round(row[key][field]*factor);
    // Preserve positive attempt denominators when an original rate is known.
    if(p.stats.threePct!==null&&row.threePointFieldGoals.attempted===0)row.threePointFieldGoals.attempted=g;
    if(p.stats.fgPct!==null&&row.fieldGoals.attempted===0)row.fieldGoals.attempted=g;
    if(p.stats.ftPct!==null&&row.freeThrows.attempted===0)row.freeThrows.attempted=g;
    return {...row,name:p.name,games:g,athleteId:5000+i};
  });
  f.teams[0].teamStats.points.total=f.players.reduce((n,p)=>n+p.points,0);
  const result=expand(f),p=result.players.find(p=>p.id===original.id);
  assert.ok(p);assert.equal(p.personId,original.personId);assert.equal(p.cost,original.cost);
  assert.deepEqual(p.roles,original.roles);assert.equal(p.number,original.number);
  assert.equal(p.stats.games,39);assert.notEqual(p.stats.ppg,original.stats.ppg);
  assert.equal(result.players.filter(p=>p.school==='Purdue'&&p.year===2024).length,17);
  assert.ok(result.players.some(p=>p.school==='Purdue'&&p.year===2006));
  assert.equal(result.groupsAdded,0);assert.equal(result.playersAdded,0);
  assert.equal(result.draftGroups.filter(g=>g.school==='Purdue'&&g.season==='2023-24').length,1);
  const missingStarts=structuredClone(f);delete missingStarts.players[0].starts;
  assert.ok(!expand(missingStarts).draftGroups.some(g=>g.school==='Purdue'&&g.source==='cbbd'));
  const missingZeroScorer=structuredClone(f);
  const zeroIndex=missingZeroScorer.players.findIndex(p=>p.points===0);
  assert.ok(zeroIndex>=0);
  missingZeroScorer.players.splice(zeroIndex,1);
  assert.ok(!expand(missingZeroScorer).draftGroups.some(g=>g.school==='Purdue'&&g.source==='cbbd'));
});

test('matching an existing player requires their exact complete-season games count',()=>{
  const f=schoolFixture('Purdue');f.players[0].name='Zach Edey';
  const result=expand(f);assert.equal(result.playersAdded,0);
  assert.ok(result.players.includes(CATALOG.players.find(p=>p.id==='edey-2024')));
});

test('one malformed appearing reserve rejects that entire school but not other schools',()=>{
  const bad=schoolFixture('Bad College'),good=schoolFixture('Good College',2000);
  bad.players[7].position='Unknown';
  const result=expand({players:[...bad.players,...good.players],teams:[...bad.teams,...good.teams]});
  assert.equal(result.groupsAdded,1);assert.equal(result.playersAdded,8);
  assert.ok(result.warnings.some(w=>w.includes('Bad College')));
  assert.ok(!result.players.some(p=>p.school==='Bad College'));
});

test('missing reserves or mismatched point totals reject an incomplete star-only group',()=>{
  const f=schoolFixture();f.players=f.players.slice(0,5);
  assert.equal(expand(f).playersAdded,0);
  const mismatch=schoolFixture();mismatch.teams[0].teamStats.points.total++;
  assert.equal(expand(mismatch).playersAdded,0);
});

test('invalid identities, counts, minutes, shots and reconciliations reject the whole group',()=>{
  const changes=[
    p=>{p.name='';},p=>{p.athleteId=null;},p=>{p.season=2023;},p=>{p.games=21;},
    p=>{p.minutes=-1;},p=>{p.minutes=Infinity;},p=>{p.assists=.5;},p=>{delete p.turnovers;},
    p=>{p.fieldGoals.made=p.fieldGoals.attempted+1;},p=>{p.threePointFieldGoals.attempted=.5;},
    p=>{p.freeThrows.made=-1;},p=>{p.points++;},p=>{p.rebounds.total++;},
    p=>{p.twoPointFieldGoals={made:0,attempted:0};},p=>{p.starts=21;},
  ];
  for(const change of changes) {
    const f=schoolFixture();change(f.players[0]);
    assert.equal(expand(f).playersAdded,0,change.toString());
  }
});

test('duplicate athlete, player name or team identities never get silently chosen',()=>{
  for(const change of [
    f=>{f.players[1].athleteId=f.players[0].athleteId;},
    f=>{f.players[1].name=f.players[0].name;},
    f=>{f.teams.push(structuredClone(f.teams[0]));},
  ]) {
    const f=schoolFixture();change(f);assert.equal(expand(f).playersAdded,0);
  }
  const first=schoolFixture('First'),second=schoolFixture('Second');
  assert.equal(expand({players:[...first.players,...second.players],teams:[...first.teams,...second.teams]}).playersAdded,0);
});

test('zero-appearance rows are excluded without disqualifying a complete roster',()=>{
  const f=schoolFixture();f.players.push({team:'Synthetic College',games:0,position:'Unknown'});
  const result=expand(f);assert.equal(result.playersAdded,8);assert.equal(result.warnings.length,0);
});

test('provider IDs cannot collide with retained historical identities',()=>{
  const f=schoolFixture();
  const historical={...CATALOG.players[0],id:'cbbd-1000-2024'};
  const result=expandProviderPool(f.players,f.teams,{...CATALOG,players:[...CATALOG.players,historical]});
  assert.equal(result.playersAdded,0);
  assert.ok(result.warnings.some(w=>w.includes('duplicate resulting')));
});

test('groups outside five to thirty appearing players are rejected',()=>{
  for(const length of [4,31]) {
    const f=schoolFixture();
    f.players=Array.from({length},(_,i)=>({...structuredClone(f.players[i%8]),athleteId:5000+i,name:'Synthetic '+i}));
    f.teams[0].teamStats.points.total=f.players.reduce((n,p)=>n+p.points,0);
    assert.equal(expand(f).playersAdded,0);
  }
});

test('bad collections and unassignable appearing players retain the complete bundle',()=>{
  for(const [players,teams] of [[null,[]],[[],{}],[[{games:1}],[]]]) {
    const result=expandProviderPool(players,teams,CATALOG);
    assert.deepEqual(result.players,CATALOG.players);assert.equal(result.playersAdded,0);assert.ok(result.warnings.length);
  }
});

test('expansion is deterministic under response ordering and does not mutate inputs',()=>{
  const f=schoolFixture(),before=structuredClone(f);
  const a=expand(f),b=expand({...f,players:[...f.players].reverse()});
  assert.deepEqual(a,b);assert.deepEqual(f,before);
});
