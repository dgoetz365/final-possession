import test from 'node:test';
import assert from 'node:assert/strict';
import {CATALOG} from '../public/js/catalog.js';
import {createRun,MODEL_VERSION} from '../public/js/engine.js';
import {saveRun,loadRun,parseSave,recordHistory,SAVE_KEY,HISTORY_KEY,MAX_SAVE_BYTES} from '../public/js/storage.js';
const memory=()=>{const m=new Map();return {getItem:k=>m.get(k)||null,setItem:(k,v)=>m.set(k,v),removeItem:k=>m.delete(k)};};
test('round trips frozen catalog and RNG without mutation',()=>{
  const s=memory(),r=createRun(CATALOG,18);saveRun(s,r,CATALOG);
  assert.deepEqual(loadRun(s,MODEL_VERSION).saved.run,r);
  assert.equal(loadRun(s,MODEL_VERSION).saved.catalog.version,CATALOG.version);
});
test('corrupt, oversized, incompatible saves provide recovery',()=>{
  assert.throws(()=>parseSave('{bad',MODEL_VERSION),/JSON/);
  assert.throws(()=>parseSave('x'.repeat(MAX_SAVE_BYTES+1),MODEL_VERSION),/large/);
  const s=memory();s.setItem(SAVE_KEY,'bad');assert.equal(loadRun(s,MODEL_VERSION).saved,null);
  const r=createRun(CATALOG,18);saveRun(s,r,CATALOG);assert.match(loadRun(s,'future').notice,/older/);
});
test('invalid draft state and unsafe source links are rejected on import',()=>{
  const r=createRun(CATALOG,18);
  const value={format:'final-possession',version:1,run:r,catalog:structuredClone(CATALOG)};
  value.run.draft.rerollsLeft=99;
  assert.throws(()=>parseSave(JSON.stringify(value),MODEL_VERSION),/draft/);
  value.run.draft.rerollsLeft=2;
  value.catalog.players[0].source.url='javascript:alert(1)';
  assert.throws(()=>parseSave(JSON.stringify(value),MODEL_VERSION),/player record/);
});
test('terminal history is idempotent, active run is not recorded',()=>{
  const s=memory(),r=createRun(CATALOG,18);assert.equal(recordHistory(s,r,CATALOG).length,0);
  r.phase='eliminated';recordHistory(s,r,CATALOG);recordHistory(s,r,CATALOG);assert.equal(JSON.parse(s.getItem(HISTORY_KEY)).length,1);
});
test('quota failure is visible and original save is preserved',()=>{
  const s={getItem:()=>null,setItem:()=>{throw Error('quota');}};
  assert.throws(()=>saveRun(s,createRun(CATALOG,18),CATALOG),/Export your run/);
});
