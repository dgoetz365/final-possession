import assert from 'node:assert/strict';
import test from 'node:test';
import { CATALOG, seasonCreditCost } from '../public/js/catalog.js';
import { parseSeasonTables } from '../public/js/season-tables.js';

const byId = new Map(CATALOG.players.map(p => [p.id,p]));
const statKeys = ['games','ppg','rpg','apg','threePct','ftPct','mpg','spg','bpg','threeAttempts','fgPct','tov','starts','orpg','drpg','fgAttempts','ftAttempts'];
const roles = ['PG','SG','SF','PF','C'];
const approved = ['curry-2008','allen-2016','durant-2007','davis-2012','noah-2007','redick-2006','green-2012','brunson-2018'];

test('at least 100 distinct player-seasons carry complete schema and primary source provenance', () => {
  assert.ok(CATALOG.players.length >= 100);
  assert.equal(byId.size,CATALOG.players.length);
  assert.equal(new Set(CATALOG.players.map(p=>p.personId)).size,CATALOG.players.length);
  assert.ok(new Set(CATALOG.players.map(p=>p.school)).size >= 8);
  for (const p of CATALOG.players) {
    assert.equal(p.verified,true);
    assert.match(p.id,/^[a-z-]+-\d{4}$/);
    assert.match(p.season,/^\d{4}-\d{2}$/);
    assert.equal(p.year,Number(p.season.slice(0,4))+1);
    assert.equal(Number(p.id.slice(-4)),p.year);
    assert.ok(p.name && p.school && p.roles.length && Number.isInteger(p.cost) && p.cost >= 1 && p.cost <= 22);
    assert.ok(p.roles.every(r=>roles.includes(r)));
    assert.equal(new URL(p.source.url).protocol,'https:');
    assert.ok(CATALOG.sources.some(s=>s.url===p.source.url));
    for (const key of statKeys) {
      assert.ok(Object.hasOwn(p.stats,key), `${p.id} missing ${key}`);
      assert.ok(p.stats[key] === null || (Number.isFinite(p.stats[key]) && p.stats[key]>=0));
    }
    for (const key of ['threePct','ftPct','fgPct']) assert.ok(p.stats[key]===null||p.stats[key]<=100);
    if (p.stats.games!==null) assert.ok(Number.isInteger(p.stats.games)&&p.stats.games>0&&p.stats.games<50);
    if (p.stats.threeAttempts===0) assert.equal(p.stats.threePct,null);
    if (p.stats.ftAttempts===0) assert.equal(p.stats.ftPct,null);
    if (p.stats.fgAttempts===0) assert.equal(p.stats.fgPct,null);
  }
});

test('ordinary players and bench players form a substantial part of the draft pool', () => {
  assert.ok(CATALOG.players.filter(p=>p.stats.ppg!==null&&p.stats.ppg<10).length>=60);
  assert.ok(CATALOG.players.filter(p=>p.stats.mpg!==null&&p.stats.mpg<15).length>=40);
  assert.ok(CATALOG.players.filter(p=>p.cost<=5).length>=40);
  for(const p of CATALOG.players.filter(p=>!approved.includes(p.id))) {
    assert.equal(p.cost,seasonCreditCost(p.stats),p.id);
    assert.equal(p.costModel,'season-box-v1');
  }
});

test('transcribed rows reconcile scoring, shooting attempts and published team totals', () => {
  const rows=parseSeasonTables();
  assert.equal(rows.length,96);
  for(const row of rows) {
    const t=row.totals;
    assert.ok(Object.values(t).every(n=>Number.isFinite(n)&&n>=0),row.stem);
    assert.ok(t.starts<=t.games,row.stem);
    assert.ok(t.fgMade<=t.fgAttempts&&t.threeMade<=t.threeAttempts&&t.ftMade<=t.ftAttempts,row.stem);
    assert.ok(t.threeMade<=t.fgMade&&t.threeAttempts<=t.fgAttempts,row.stem);
    assert.equal(2*t.fgMade+t.threeMade+t.ftMade,t.points,row.stem);
    const p=byId.get(`${row.stem}-${row.year}`);
    assert.ok(Math.abs(p.stats.ppg-t.points/t.games)<=.051,row.stem);
    assert.ok(Math.abs(p.stats.rpg-(t.offRebounds+t.defRebounds)/t.games)<=.051,row.stem);
    assert.ok(Math.abs(p.stats.mpg-t.minutes/t.games)<=.051,row.stem);
    assert.equal(p.stats.fgAttempts,t.fgAttempts,row.stem);
  }
  // Each vector is count, points, FGM, 3PM, 3PA, FTM, FTA, assists, blocks, steals.
  // TEAM rebounds and TEAM turnovers are deliberately not attributed to players.
  const expected={
    duke16:[12,2920,983,328,851,626,866,480,156,225],
    duke06:[14,2921,979,274,709,689,905,546,202,337],
    davidson:[14,2803,1032,328,901,411,573,615,114,290],
    texas:[12,2860,963,308,792,626,850,479,197,262],
    nova:[14,3463,1220,464,1158,559,718,655,162,259],
    purdue24:[17,3211,1109,318,788,675,938,720,142,212],
    purdue06:[13,1811,669,153,465,320,468,366,93,151],
  };
  for(const [key,totals] of Object.entries(expected)) {
    const group=rows.filter(r=>r.sourceKey===key);
    const sums=['points','fgMade','threeMade','threeAttempts','ftMade','ftAttempts','assists','blocks','steals'].map(k=>group.reduce((n,r)=>n+r.totals[k],0));
    assert.deepEqual([group.length,...sums],totals,key);
  }
});

test('approved eight remain exact and can field five roles within 100 credits', () => {
  const values=approved.map(id=>byId.get(id));
  assert.ok(values.every(Boolean));
  assert.deepEqual(values.map(p=>p.cost),[22,12,18,18,10,7,6,7]);
  assert.equal(values.reduce((sum,p)=>sum+p.cost,0),100);
  assert.deepEqual(values.map(p=>p.roles),[['PG'],['SG'],['SF'],['PF','C'],['C'],['SG'],['PF','SF'],['PG']]);
  for(let i=0;i<5;i++) assert.ok(values[i].roles.includes(roles[i]));
  assert.equal(values.filter(p=>p.roles.some(r=>['PG','SG'].includes(r))).length,4);
  assert.equal(values.filter(p=>p.roles.some(r=>['PF','C'].includes(r))).length,3);
});

test('alternatives form an affordable legal roster without any approved-eight players', () => {
  const alternative=['richards-2008','kennard-2016','ingram-2016','paschall-2018','horford-2007','jeter-2016','thornton-2016','humphrey-2007'].map(id=>byId.get(id));
  assert.equal(alternative.length,8);
  assert.ok(alternative.reduce((sum,p)=>sum+p.cost,0)<=100);
  assert.ok(alternative.every(p=>!approved.includes(p.id)));
  for(let i=0;i<5;i++) assert.ok(alternative[i].roles.includes(roles[i]));
});

test('all 63 historic opponent slots occur once with only West 5 removed', () => {
  assert.equal(CATALOG.teams.length,63);
  assert.equal(new Set(CATALOG.teams.map(t=>t.id)).size,63);
  const expected=Array.from({length:16},(_,i)=>i+1);
  for(const region of ['East','West','South','Midwest']) {
    assert.deepEqual(CATALOG.teams.filter(t=>t.region===region).map(t=>t.seed).sort((a,b)=>a-b),expected.filter(seed=>!(region==='West'&&seed===5)));
  }
  assert.ok(CATALOG.teams.every(t=>t.name!=="Saint Mary's"));
  for(const t of CATALOG.teams) {
    assert.equal(t.season,'2023-24');
    assert.ok(Number.isInteger(t.stats.wins)&&t.stats.wins>0);
    assert.ok(Number.isInteger(t.stats.losses)&&t.stats.losses>0);
    assert.ok(t.stats.wins+t.stats.losses>=30 && t.stats.wins+t.stats.losses<=37);
    for(const field of ['ppg','oppPpg','pace','threePct']) assert.equal(t.stats[field],null);
    assert.ok(CATALOG.sources.some(s=>s.url===t.source.url));
  }
});

test('source-sensitive edge cases preserve facts and missing observations', () => {
  assert.deepEqual([byId.get('noah-2007').stats.threePct,byId.get('noah-2007').stats.threeAttempts],[100,1]);
  assert.deepEqual([byId.get('edey-2024').stats.threePct,byId.get('edey-2024').stats.threeAttempts],[50,2]);
  assert.equal(byId.get('horford-2007').stats.threePct,0);
  assert.equal(byId.get('jefferson-2016').stats.games,9);
  assert.equal(byId.get('brewer-2007').stats.mpg,null);
  assert.equal(byId.get('davis-2012').stats.bpg,Math.round(186/40*10)/10);
  assert.equal(byId.get('walker-2011').stats.games,41);
  assert.equal(CATALOG.teams.find(t=>t.id==='arizona-2024').stats.losses,8);
  assert.equal(CATALOG.teams.find(t=>t.id==='wagner-2024').stats.wins,16);
  assert.equal(CATALOG.teams.find(t=>t.id==='grambling-state-2024').stats.wins,20);
  assert.equal(CATALOG.teams.find(t=>t.id==='colorado-2024').stats.wins,24);
  assert.equal(CATALOG.teams.find(t=>t.id==='colorado-state-2024').stats.wins,24);
});

