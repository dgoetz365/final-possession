import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizePlayer,normalizeTeam,readCatalog,dataStatus,refreshCatalog} from '../server/data-service.js';
import {CATALOG} from '../public/js/catalog.js';

const LATEST='final-possession/catalog/latest.json';
const SECRET='fixture-secret-must-not-escape';
const byId=new Map(CATALOG.players.map(p=>[p.id,p]));
const providerTeam=school=>school==='UConn'?'Connecticut':school;

// Synthetic consistent observations, not historical claims. All real catalog
// identities and their exact complete-season game counts are exercised.
function playerRow(p) {
  const g=p.stats.games;
  return {name:p.name,team:providerTeam(p.school),season:p.year,games:g,starts:g,
    minutes:30*g,points:13*g,fieldGoals:{made:5*g,attempted:10*g},
    threePointFieldGoals:{made:g,attempted:4*g},freeThrows:{made:2*g,attempted:3*g},
    rebounds:{total:8*g,offensive:2*g,defensive:6*g},assists:3*g,turnovers:2*g,steals:g,blocks:g};
}
function teamRow(t) {
  const {wins,losses}=t.stats,games=wins+losses;
  return {team:providerTeam(t.name),season:2024,games,wins,losses,pace:68,
    teamStats:{points:{total:80*games},threePointFieldGoals:{made:100,attempted:250}},
    opponentStats:{points:{total:60*games}}};
}
function memoryBucket(initial={}) {
  const objects=new Map(Object.entries(initial)),writes=[];
  return {objects,writes,failImmutable:false,
    async get(key) {return objects.has(key)?{json:async()=>JSON.parse(objects.get(key))}:null;},
    async put(key,value) {
      writes.push({key,value});
      if(this.failImmutable&&key.startsWith('final-possession/catalog/cbbd-'))throw new Error('Immutable staging failed');
      objects.set(key,value);
    }};
}
const BULK_GROUPS=20,PLAYERS_PER_GROUP=8;
const HISTORICAL_COUNT=CATALOG.players.filter(p=>p.year!==2024).length;
function completeProvider(groupCount=BULK_GROUPS) {
  const requests=[],players=CATALOG.players.map(playerRow),teams=CATALOG.teams.map(teamRow),bulk=[];
  for(let group=0;group<groupCount;group++) {
    const school='Synthetic API School '+group,members=[];
    for(let i=0;i<PLAYERS_PER_GROUP;i++) {
      const athleteId=90000+group*100+i;
      members.push({...playerRow({name:'Synthetic Athlete '+athleteId,school,year:2024,stats:{games:20}}),athleteId,position:['PG','SG','SF','PF','C','G','F','C'][i]});
    }
    bulk.push(...members);
    teams.push({team:school,season:2024,games:20,wins:10,losses:10,teamStats:{points:{total:members.reduce((n,p)=>n+p.points,0)}}});
  }
  return {requests,async fetch(url,options) {
    requests.push(url);
    assert.equal(options.headers.Authorization,'Bearer '+SECRET);
    const r=new URL(url);let result;
    switch(r.pathname) {
      case '/stats/team/season':result=teams;break;
      case '/stats/player/season':result=r.searchParams.has('team')?players.filter(p=>p.season===Number(r.searchParams.get('season'))&&p.team===r.searchParams.get('team')):bulk;break;
      case '/ratings/adjusted':result=teams.map(t=>({team:t.team,season:2024,netRating:20}));break;
      case '/games':result=[{id:1,season:2024}];break;
      default:assert.fail('Unexpected endpoint '+r.pathname);
    }
    return new Response(JSON.stringify(result),{headers:{'content-type':'application/json'}});
  }};
}

test('all 103 identities normalize complete statistics without changing game design',()=>{
  assert.equal(CATALOG.players.length,103);
  for(const original of CATALOG.players) {
    const before=structuredClone(original),g=original.stats.games;
    const p=normalizePlayer(playerRow(original),original);
    assert.ok(p,original.id);
    assert.deepEqual(p.stats,{games:g,ppg:13,rpg:8,apg:3,threePct:25,threeAttempts:4*g,
      ftPct:66.7,mpg:30,spg:1,bpg:1,fgPct:50,tov:2,starts:g,orpg:2,drpg:6,fgAttempts:10*g,ftAttempts:3*g});
    assert.equal(p.id,original.id);assert.equal(p.cost,original.cost);assert.deepEqual(p.roles,original.roles);
    assert.ok(p.source.url.includes('collegebasketballdata.com'));
    assert.deepEqual(original,before);
  }
});

test('sparse data cannot erase previously verified statistics',()=>{
  const original=byId.get('curry-2008');
  assert.equal(normalizePlayer({name:original.name,team:original.school,season:original.year,games:36,points:468},original),null);
  for(const field of ['minutes','assists','steals','blocks','fieldGoals','threePointFieldGoals','freeThrows','rebounds','turnovers','starts']) {
    const row=playerRow(original);delete row[field];
    assert.equal(normalizePlayer(row,original),null,'missing '+field);
  }
});

test('identity, season and exact complete-season games must match',()=>{
  const original=byId.get('curry-2008'),raw=playerRow(original);
  for(const update of [{name:'Someone Else'},{team:'Another University'},{season:1900},{games:35},{games:37},{games:36.5},{games:'36'}]) {
    assert.equal(normalizePlayer({...raw,...update},original),null,JSON.stringify(update));
  }
});

test('zero attempts produce unavailable percentages rather than invented zero rates',()=>{
  const original=byId.get('rayl-2024');
  const row={...playerRow(original),points:0,fieldGoals:{made:0,attempted:0},threePointFieldGoals:{made:0,attempted:0},freeThrows:{made:0,attempted:0}};
  const result=normalizePlayer(row,original);assert.ok(result);
  for(const key of ['threePct','fgPct','ftPct'])assert.equal(result.stats[key],null);
  assert.equal(result.stats.threeAttempts,0);
});

test('impossible shooting is rejected even when the original percentage is unavailable',()=>{
  for(const id of ['curry-2008','rayl-2024','davis-2012']) {
    const original=byId.get(id);
    for(const field of ['fieldGoals','threePointFieldGoals','freeThrows']) {
      assert.equal(normalizePlayer({...playerRow(original),[field]:{made:1,attempted:0}},original),null,id+' '+field);
    }
  }
});

test('contradictory scoring and rebound totals cannot become verified records',()=>{
  const original=byId.get('curry-2008'),row=playerRow(original);
  assert.equal(normalizePlayer({...row,points:row.points+1},original),null,'points must reconcile to made shots');
  assert.equal(normalizePlayer({...row,rebounds:{...row.rebounds,total:row.rebounds.total+1}},original),null,'rebound components must reconcile');
});

test('team identifiers and actual record must agree before replacement',()=>{
  const original=CATALOG.teams.find(t=>t.name==='UConn'),r=teamRow(original);
  const t=normalizeTeam(r,original,{team:'Connecticut',season:2024,netRating:30});
  assert.equal(t.stats.ppg,80);assert.equal(t.stats.oppPpg,60);assert.equal(t.stats.adjustedMargin,30);
  assert.deepEqual(t.bracketSource,original.source);assert.equal(t.recordAsOf,'Full season');
  for(const update of [{wins:50},{losses:-1},{games:34.5},{season:2023},{team:'Another University'}])assert.equal(normalizeTeam({...r,...update},original),null);
  assert.equal(normalizeTeam(r,original,{team:'Wrong team',season:2024,netRating:30}).stats.adjustedMargin,null);
});

test('unconfigured service gives usable snapshot and does not fetch',async()=>{
  assert.equal(await readCatalog({},CATALOG),CATALOG);
  assert.equal((await dataStatus({},null,CATALOG)).configured,false);
  await assert.rejects(()=>refreshCatalog({},CATALOG,()=>assert.fail('no fetch')),/CBBD_API_KEY/);
});

test('failed provider publishes nothing and never exposes the key',async()=>{
  const bucket=memoryBucket(),env={CBBD_API_KEY:SECRET,BUCKET:bucket};
  await assert.rejects(()=>refreshCatalog(env,CATALOG,async()=>new Response('{}',{status:401})),error=>error.message.includes('401')&&!error.message.includes(SECRET));
  assert.equal(bucket.writes.length,0);
});

test('bulk import publishes twenty complete new schools alongside historical players and 63 opponents',async()=>{
  const bucket=memoryBucket(),provider=completeProvider();
  const env={CBBD_API_KEY:SECRET,BUCKET:bucket,DATA_ADMIN_EMAIL:'admin@example.test'};
  const summary=await refreshCatalog(env,CATALOG,provider.fetch);
  assert.equal(summary.playersUpdated,HISTORICAL_COUNT+BULK_GROUPS*PLAYERS_PER_GROUP);assert.equal(summary.teamsUpdated,63);assert.equal(summary.gamesFetched,1);
  assert.equal(summary.providerGroups,BULK_GROUPS);assert.equal(summary.groupsAdded,BULK_GROUPS);
  assert.equal(summary.playersAdded,BULK_GROUPS*PLAYERS_PER_GROUP);
  assert.deepEqual(summary.warnings,[]);assert.match(summary.version,/^cbbd-[a-f0-9]{16}$/);
  assert.equal(bucket.writes.at(-2).key,'final-possession/catalog/'+summary.version+'.json');
  assert.equal(bucket.writes.at(-1).key,LATEST);
  const saved=await readCatalog(env,CATALOG);
  assert.equal(saved.version,summary.version);assert.equal(saved.players.length,CATALOG.players.length+BULK_GROUPS*PLAYERS_PER_GROUP);
  assert.equal(saved.players.find(p=>p.id==='curry-2008').stats.ppg,13);
  assert.equal(new Set(saved.players.map(p=>p.id)).size,saved.players.length);
  assert.equal(saved.draftGroups.filter(g=>g.source==='cbbd').length,BULK_GROUPS);
  assert.equal(provider.requests.filter(url=>new URL(url).pathname==='/stats/player/season'&&!new URL(url).searchParams.has('team')).length,1);
  assert.equal(provider.requests.filter(url=>new URL(url).searchParams.get('season')==='2024'&&new URL(url).searchParams.has('team')).length,0);
  assert.equal(JSON.stringify([...bucket.objects.values()]).includes(SECRET),false);
  assert.equal((await dataStatus(env,'ADMIN@example.test',CATALOG)).canRefresh,true);
  assert.equal((await dataStatus(env,'viewer@example.test',CATALOG)).canRefresh,false);
  assert.equal((await dataStatus(env,null,CATALOG)).canRefresh,false);
});

test('immutable staging failure preserves latest and a subsequent refresh succeeds',async()=>{
  const previous={...structuredClone(CATALOG),version:'previous-verified-snapshot'},savedBefore=JSON.stringify(previous);
  const bucket=memoryBucket({[LATEST]:savedBefore}),provider=completeProvider();
  bucket.failImmutable=true;
  const env={CBBD_API_KEY:SECRET,BUCKET:bucket};
  await assert.rejects(()=>refreshCatalog(env,CATALOG,provider.fetch),/Immutable staging failed/);
  assert.equal(bucket.writes.some(w=>w.key===LATEST),false);
  assert.equal(bucket.objects.get(LATEST),savedBefore);
  assert.equal((await readCatalog(env,CATALOG)).version,previous.version);
  bucket.failImmutable=false;
  const summary=await refreshCatalog(env,CATALOG,provider.fetch);
  assert.equal(summary.playersUpdated,HISTORICAL_COUNT+BULK_GROUPS*PLAYERS_PER_GROUP,'rejection must clear in-flight operation');
  assert.equal((await readCatalog(env,CATALOG)).version,summary.version);
});

test('fewer than twenty complete provider schools cannot publish a replacement',async()=>{
  const bucket=memoryBucket(),provider=completeProvider(19);
  await assert.rejects(()=>refreshCatalog({CBBD_API_KEY:SECRET,BUCKET:bucket},CATALOG,provider.fetch),/19 complete/);
  assert.equal(bucket.writes.some(w=>w.key===LATEST),false);
  assert.equal(bucket.writes.some(w=>w.key.startsWith('final-possession/catalog/')),false);
});

test('unreadable, truncated, duplicated and foreign snapshots fall back to the bundle',async()=>{
  const corruptions=['not JSON','null'];
  for(const change of [
    c=>c.players.pop(),
    c=>{c.players={length:103};},
    c=>{c.teams={length:63};},
    c=>{c.players[1]=c.players[0];},
    c=>{c.teams[0].id='unknown-2024';},
    c=>{c.players[0].stats=null;},
  ]) {
    const c=structuredClone(CATALOG);change(c);corruptions.push(JSON.stringify(c));
  }
  for(const value of corruptions)assert.equal(await readCatalog({BUCKET:memoryBucket({[LATEST]:value})},CATALOG),CATALOG);
  assert.equal(await readCatalog({BUCKET:{get:async()=>{throw new Error('Storage offline');}}},CATALOG),CATALOG);
});

test('empty or negative statistics cannot pass snapshot validation',async()=>{
  for(const stats of [{},{...CATALOG.players[0].stats,ppg:-1}]) {
    const corrupted=structuredClone(CATALOG);corrupted.players[0].stats=stats;
    const actual=await readCatalog({BUCKET:memoryBucket({[LATEST]:JSON.stringify(corrupted)})},CATALOG);
    assert.ok(actual===CATALOG,'invalid snapshot must return the trusted bundle');
  }
});

