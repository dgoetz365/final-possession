# Final Possession bundled catalog evidence

Checked October 16, 2026. The catalog contains 103 manually verified player-seasons and 63 historical 2023-24 opponents. It contains selected factual observations, not copied biographies or a provider database. Sources are primary university, conference and NCAA publications. CBBD has not been contacted with a credential and is not the source of this bundled catalog.

## Verification method

I read the sources' final all-games tables, matching the exact player and season. Conference-only tables and midseason snapshots were excluded. Each record points directly to its source. When tables provide a counting total rather than a per-game figure, the catalog divides by games and rounds to one decimal. Previously reviewed rounded observations remain unchanged; newly added percentages and per-game values are calculated from the transcribed totals. Percentages use 0-100 units. Missing fields are null; every shooting percentage with zero attempts is normalized to null. `season-tables.js` preserves the full individual rows used to build the expanded pool.

Browser extraction returned the PDF text. PDF screenshot attempts returned cache errors, so no claim of visual PDF inspection is made. Source observations were corroborated with official player pages and extracted tabular totals where possible. This matters because both layout extraction and original publications can contain errors.

## Player observations

The first eight are the exact approved concept roster. Role eligibility and credit cost are game design values, not historical evaluations. All 103 are different people. Jersey numbers come from the same season table or linked official roster. The draft can build multiple legal eight-player teams below 100 credits. The table below documents the original 24; the complete expanded observations are in `season-tables.js` and each generated record's `seasonTotals`.

### Expanded pool

The pool now contains 69 seasons below 10 PPG, 48 seasons with known MPG below 15, and 48 players priced at five credits or less. Complete individual tables include regular starters, reserves and players with only a few appearances. No zero-appearance roster entries or TEAM aggregate rows are presented as players. This is a curated pool from nine schools, not a random sample of all college basketball history.

| Full individual table | Players | Primary source |
|---|---:|---|
| Duke 2015-16 | 12 | [Final all-games statistics, page 1](https://goduke.com/documents/download/2022/8/15/2015-16_Stats.pdf) |
| Duke 2005-06 | 14 | [Final all-games statistics, page 1](https://s3.us-east-2.amazonaws.com/sidearm.nextgen.sites/goduke.com/documents/2022/8/15/2005-06_Stats.pdf) |
| Davidson 2007-08 | 14 | [Final all-games statistics](https://static.davidsonwildcats.com/custompages/mbball/2007-08.HTM) |
| Texas 2006-07 | 12 | [Big 12 guide, printed page 73](https://s3.amazonaws.com/big12sports.com/documents/2008/7/22/133442.pdf) |
| Villanova 2017-18 | 14 | [Final cumulative statistics](https://villanova.com/sports/mens-basketball/stats/2017-18) |
| Purdue 2023-24 | 17 | [Final all-games statistics, PDF page 3](https://storage.googleapis.com/purduesports-com-prod/2025/05/16/L6rE8G0Zhs8eWIxXupib7mmHA8EGq6MVOdUJvC8f.pdf#page=3) |
| Purdue 2005-06 | 13 | [Final all-games statistics, page 1](https://s3.us-east-2.amazonaws.com/sidearm.nextgen.sites/purduesports.com/documents/2006/5/6/_pur_m_baskbl__0506cumulative_stats.pdf?timestamp=20180517103639) |

These 96 full-table records plus the seven existing individual-biography records produce 103 distinct player-seasons. The [Purdue official archive](https://purduesports.com/mbb-archives) links both Purdue documents. Purdue's 2005-06 team finished 9-19, adding players from a losing team as well as successful teams. [Davidson's official 2007-08 roster](https://davidsonwildcats.com/sports/mens-basketball/roster/2007-08) confirms shortened display names Max Paulhus Gosselin and Steve Rossiter. Game role eligibility is a design assignment and does not assert an official five-position classification.

Added fields are `fgPct`, `tov` (turnovers per game), `starts`, `orpg`, `drpg`, `fgAttempts` and `ftAttempts`. Attempts are season totals. Existing fields retain games, PPG, RPG, APG, MPG, SPG, BPG, 3PT%, FT% and total 3PT attempts. Every full-table record includes all 17 fields, except undefined shooting percentages where attempts are zero. Individual-biography records retain null for fields without a verified observation.

For all players except the eight approved concept prices, the consistent original game price is `clamp(1,22,round(1 + 0.45*PPG + 0.45*RPG + 0.60*APG + SPG + 1.20*BPG + 0.03*MPG))`. A missing component contributes zero only to this price formula; the stored historical value stays null. Prices are gameplay choices, not historical facts or calibrated evaluations. The approved eight retain costs 22,12,18,18,10,7,6,7. Other original-24 prices now also use the same formula as added players.

Row checks reconcile each player's points to `2*FGM + 3PM + FTM`; all seven sets reconcile individual points, field goals made, three-point makes/attempts, free-throw makes/attempts, assists, blocks and steals to the printed team totals. Team rebounds and team turnovers are excluded from individual records. Duke's 2005-06 individual FGA rows total 2,010 while the printed team total is 2,011; the individual observations are preserved. Purdue's 2023-24 individual minutes sum two seconds above the printed 7,875-minute team total; each published minute/second value is preserved. These differences are not repaired by inventing a player observation.

| Player | Season / school | Games | PPG | RPG | APG | Source |
|---|---|---:|---:|---:|---:|---|
| Stephen Curry | 2007-08 Davidson | 36 | 25.9 | 4.6 | 2.9 | [Davidson final statistics](https://static.davidsonwildcats.com/custompages/mbball/2007-08.HTM) |
| Grayson Allen | 2015-16 Duke | 36 | 21.6 | 4.6 | 3.5 | [Duke final statistics, p1](https://goduke.com/documents/download/2022/8/15/2015-16_Stats.pdf) |
| Kevin Durant | 2006-07 Texas | 35 | 25.8 | 11.1 | 1.3 | [Big 12 guide, printed p73](https://s3.amazonaws.com/big12sports.com/documents/2008/7/22/133442.pdf) |
| Anthony Davis | 2011-12 Kentucky | 40 | 14.2 | 10.4 | unavailable | [Kentucky official biography](https://ukathletics.com/sports/mbball/roster/player/anthony-davis/) |
| Joakim Noah | 2006-07 Florida | 40 | 12.0 | 8.4 | 2.3 | [Florida career table](https://floridagators.com/sports/mens-basketball/roster/joakim-noah/486) |
| JJ Redick | 2005-06 Duke | 36 | 26.8 | 2.0 | 2.6 | [Duke 2006-07 guide](https://goduke.com/documents/download/2022/8/15/2006-07_Media_Guide.pdf) |
| Draymond Green | 2011-12 Michigan State | 37 | 16.2 | 10.6 | 3.8 | [MSU official biography, p1](https://msuspartans.com/documents/download/2018/7/25/11056__m_baskbl_2011_12_misc_non_event__greenbio050912.pdf) |
| Jalen Brunson | 2017-18 Villanova | 40 | 18.9 | 3.1 | 4.6 | [Villanova final statistics](https://villanova.com/sports/mens-basketball/stats/2017-18) |
| Brandon Ingram | 2015-16 Duke | 36 | 17.3 | 6.8 | 2.0 | Duke final statistics above |
| Luke Kennard | 2015-16 Duke | 36 | 11.8 | 3.6 | 1.5 | Duke final statistics above |
| Amile Jefferson | 2015-16 Duke | 9 | 11.4 | 10.3 | 1.4 | Duke final statistics above |
| Matt Jones | 2015-16 Duke | 35 | 10.4 | 2.5 | 2.3 | Duke final statistics above |
| Marshall Plumlee | 2015-16 Duke | 36 | 8.3 | 8.6 | 1.1 | Duke final statistics above |
| Derryck Thornton | 2015-16 Duke | 36 | 7.1 | 1.8 | 2.6 | Duke final statistics above |
| Mikal Bridges | 2017-18 Villanova | 40 | 17.7 | 5.3 | 1.9 | Villanova final statistics above |
| Donte DiVincenzo | 2017-18 Villanova | 40 | 13.4 | 4.8 | 3.5 | Villanova final statistics above |
| Omari Spellman | 2017-18 Villanova | 40 | 10.9 | 8.0 | 0.8 | Villanova final statistics above |
| Eric Paschall | 2017-18 Villanova | 38 | 10.6 | 5.3 | 2.2 | Villanova final statistics above |
| Al Horford | 2006-07 Florida | 38 | 13.2 | 9.5 | 2.2 | [Florida career table](https://floridagators.com/sports/mens-basketball/roster/al-horford/483) |
| Corey Brewer | 2006-07 Florida | 37 | 13.2 | 4.7 | 2.9 | [Florida career table](https://floridagators.com/sports/mens-basketball/roster/corey-brewer/480) |
| Lee Humphrey | 2006-07 Florida | 40 | 10.3 | 1.3 | 1.3 | [Florida career table](https://floridagators.com/sports/mens-basketball/roster/lee-humphrey/484) |
| Jason Richards | 2007-08 Davidson | 36 | 12.7 | 3.1 | 8.1 | Davidson final statistics above |
| Zach Edey | 2023-24 Purdue | 39 | 25.2 | 12.2 | 2.0 | [Purdue final game log, p2](https://storage.googleapis.com/purduesports-com-prod/2025/06/25/ZIRQDzHRqScgUrx17aOs2D8mrmbwk5ZaHYFZADkF.pdf) |
| Kemba Walker | 2010-11 UConn | 41 | 23.5 | 5.4 | 4.5 | [UConn complete biography, final career table](https://uconnhuskies.com/documents/download/2018/6/14/1888__m_baskbl__Kemba_Walker.pdf) |

### Data edge cases

- Noah made 1 of 1 threes, Edey 1 of 2. Those are true observed percentages, with sample sizes included as `stats.threeAttempts`; the engine must shrink low-sample rates for gameplay. Horford's biography lists 0 of 2 threes, so 0% is a real observation.
- The [Florida 2006-07 review, printed p84](https://floridagators.com/documents/download/2007/11/1/69_review.pdf) disagrees with individual biographies on some fields: Brewer's season minutes are 1,063 in the review and 1,053 in his biography; Horford's 3PA are 3 versus 2. Brewer's MPG remains null. Horford's 0% is unaffected; the catalog retains the career biography's 2 attempts. Noah's review prints 337 rebounds with a mathematically inconsistent 7.4 RPG; the individual biography correctly shows 8.4, which matches 337/40. The newly added columns consistently use the linked individual biographies: Noah 173/285 FG and 101 turnovers, Horford 69 turnovers, and Brewer 90 turnovers. The review instead lists Noah 286 FGA/100 turnovers, Horford 68 turnovers and Brewer 93 turnovers. Brewer's biography prints .478 FG alongside 169/356; the added FG% is calculated as 47.5% from those counts, not copied from that inconsistent printed rate.
- Davis's official Kentucky biography confirms 40 games, 14.2 PPG, 10.4 RPG and 186 blocks. BPG = round(186/40, 1) = 4.7. The other statistical fields remain null because no complete season table was recovered.
- Walker's UConn complete biography supplies the final 2010-11 row: 41 games, 1,543 minutes, 75-of-227 threes, 258-of-315 free throws, 223 rebounds, 184 assists, 7 blocks, 77 steals and 965 points. His [official 2010-11 roster](https://uconnhuskies.com/sports/mens-basketball/roster/kemba-walker/1857) independently confirms jersey 15 and the primary per-game averages.
- Jefferson's nine-game season is a limited sample. No invented availability or injury simulation is attached to it.
- The published rounding convention is one decimal. Examples: Allen APG 127/36 = 3.5, Noah APG 90/40 = 2.3, Green BPG 36/37 = 1.0. Values below 0.05 can display 0.0 even with nonzero totals (Brunson 1 block in 40 games).

## Historical opponent field

The [NCAA official bracket](https://www.ncaa.com/_flysystem/public-s3/files/2024-march-madness-bracket-mens-tournament_0.pdf) was located by web research. Direct page access was robot-blocked. The same official bracket is reproduced on printed page 5 of [GCU's 2024 second-round notes hosted by Alabama](https://rolltide.com/documents/download/2024/3/23/GCU-MBB-Notes-35-NCAAT-ALA.pdf#page=5), whose PDF text was readable. It supplies all original region/seed slots and Selection Sunday win-loss records. The notes include results, but the catalog takes only the printed original records, not the later running records.

The field includes the eventual First Four winners Wagner, Colorado State, Grambling State and Colorado. Their records remain 16-15, 24-10, 20-14 and 24-10 respectively, matching Selection Sunday for consistent model inputs. They are not represented as post-First-Four records. Saint Mary's original West 5 slot is the only removed historical entrant. The game computes its own seeding after inserting the drafted team.

| Region | Historical field in seed order, record |
|---|---|
| East | 1 UConn 31-3; 2 Iowa State 27-7; 3 Illinois 26-8; 4 Auburn 27-7; 5 San Diego State 24-10; 6 BYU 23-10; 7 Washington State 24-9; 8 Florida Atlantic 25-8; 9 Northwestern 21-11; 10 Drake 28-6; 11 Duquesne 24-11; 12 UAB 23-11; 13 Yale 22-9; 14 Morehead State 26-8; 15 South Dakota State 22-12; 16 Stetson 22-12 |
| West | 1 North Carolina 27-7; 2 Arizona 25-8; 3 Baylor 23-10; 4 Alabama 21-11; 5 slot removed; 6 Clemson 21-11; 7 Dayton 24-7; 8 Mississippi State 21-13; 9 Michigan State 19-14; 10 Nevada 26-7; 11 New Mexico 26-9; 12 Grand Canyon 29-4; 13 Charleston 27-7; 14 Colgate 25-9; 15 Long Beach State 21-14; 16 Wagner 16-15 |
| South | 1 Houston 30-4; 2 Marquette 25-9; 3 Kentucky 23-9; 4 Duke 24-8; 5 Wisconsin 22-13; 6 Texas Tech 23-10; 7 Florida 24-11; 8 Nebraska 23-10; 9 Texas A&M 20-14; 10 Colorado 24-10; 11 NC State 22-14; 12 James Madison 31-3; 13 Vermont 28-6; 14 Oakland 23-11; 15 Western Kentucky 22-11; 16 Longwood 21-13 |
| Midwest | 1 Purdue 29-4; 2 Tennessee 24-8; 3 Creighton 23-9; 4 Kansas 22-10; 5 Gonzaga 25-7; 6 South Carolina 26-7; 7 Texas 20-12; 8 Utah State 27-6; 9 TCU 21-12; 10 Colorado State 24-10; 11 Oregon 23-11; 12 McNeese 30-3; 13 Samford 29-5; 14 Akron 24-10; 15 Saint Peter's 19-13; 16 Grambling State 20-14 |

Team PPG, opponent PPG, pace and three-point percentage were not recovered for the entire 63-team field and remain null. No source for advanced efficiency, shot coordinates or lineup history is claimed. Team model strengths based on seed and W/L are estimates. This source bundle cannot support claims of full era normalization, opponent play-style fidelity or calibrated possession prediction.

## Validation

Run `node --test --experimental-test-isolation=none --test-concurrency=1 catalog.test.mjs` inside this directory. The no-isolation option avoids a Windows sandbox child-process restriction (`spawn EPERM`), without skipping any test. Tests check expanded schema, at least 100 distinct identities, meaningful ordinary/bench-player coverage, the price formula, exact approved costs/roles, two affordable valid eight-player drafts, individual scoring identities, seven team-total reconciliations, all 63 unique region/seed slots, source associations, bounded values and explicit preservation of source-sensitive edge cases. These checks catch catalog regressions; the source review above is the evidence for historical accuracy. Deploy both `catalog.js` and its imported sibling `season-tables.js` together.
